from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence



rank_count = 8

# [1] 천단위 콤마 아이템 (평균인원은 소수점 대응)
class S4ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                # 콤마 제거 후 숫자로 변환
                num = float(str(val).replace(',', ''))
                
                # 정수인지 소수인지 판별하여 포맷팅
                if num == int(num):
                    return format(int(num), ",") # 정수는 콤마만
                else:
                    return format(num, ",.2f").rstrip('0').rstrip('.')   # 소수는 소수점 2자리 유지
            except:
                return val
        return super().data(role)

    

# [2] 실시간 우측 정렬 델리게이트
class S4RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 방향키 감지를 위한 이벤트 필터 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 오른쪽 방향키: 커서가 맨 뒤일 때 다음 셀로
            if event.key() == Qt.Key_Right:
                if obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True
            # 왼쪽 방향키: 커서가 맨 앞일 때 이전 셀로
            elif event.key() == Qt.Key_Left:
                if obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True
        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)
            
            # 이동한 셀이 편집 가능(Editable)한 경우 즉시 입력 모드로 전환
            item = table.item(next_idx.row(), next_idx.column())
            if item and (item.flags() & Qt.ItemIsEditable):
                table.edit(next_idx)

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)




        

class Sheet4Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-2) 직급별 평균인원 계산")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(21, 15)
        
        months = [f"{i}월" for i in range(1, 13)]
        headers = ["구분", "직급"] + months + ["평균인원"]
        self.table.setHorizontalHeaderLabels(headers)

        # [1] 우클릭 메뉴 정책 설정 (이게 있어야 메뉴가 뜹니다)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # 스타일시트 적용
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section:horizontal {
                background-color: #f4f4f4; padding: 2px; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; padding-left: 5px; padding-right: 5px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)

        self.table.verticalHeader().setVisible(True)
        self.table.verticalHeader().setFixedWidth(25)
        self.table.verticalHeader().setDefaultSectionSize(26)
        
        self.delegate = S4RightAlignedDelegate(self.table)
        for i in range(2, 15): 
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        # 열 너비 설정
        self.table.setColumnWidth(0, 38)
        self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 70)
        self.table.setColumnWidth(14, 70)

        self.table.itemChanged.connect(self.calculate_s4)
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        
        # [수정] 행 구성 정의 (S5와 동일한 로직 적용)
        sep_row1 = rank_count            # 8
        title_row = sep_row1 + 1         # 9
        data2_start_idx = title_row + 1  # 10
        sep_row2 = data2_start_idx + rank_count # 18
        comment_row = sep_row2 + 1       # 19

        # 전체 행수 설정 (+4는 여유 공간 및 주석 포함)
        self.table.setRowCount((rank_count * 2) + 4)
        self.table.setColumnCount(15)

        ranks = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직", "계"]
        months_headers = [f"{i}월" for i in range(1, 13)]
        full_headers = ["구분", "직급"] + months_headers + ["평균인원"]
        
        bold_font = QFont(); bold_font.setBold(True)

        # 1. 첫 번째 표 (전년도)
        year_item1 = QTableWidgetItem("전\n년\n도")
        year_item1.setTextAlignment(Qt.AlignCenter)
        year_item1.setBackground(QColor(245, 245, 245))
        self.table.setItem(0, 0, year_item1)
        self.table.setSpan(0, 0, rank_count, 1)

        for r in range(rank_count):
            is_last = (r == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[r])
            it_rank.setTextAlignment(Qt.AlignCenter)
            it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집(Editable) 제외
            self.table.setItem(r, 1, it_rank)
            
            for c in range(2, 15):
                it = S4ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                # 계 행(마지막 행)이거나 평균인원(14열)이면 잠금
                if is_last or c == 14:
                    it.setBackground(self.base_sky_blue)
                    if is_last: it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(r, c, it)

        # 2. 중간 구분선 & 제목줄
        self.table.setRowHeight(sep_row1, 15)
        self.table.setRowHeight(title_row, 45)
        for c in range(15):
            # 구분선 셀 생성 및 플래그 설정
            sep_it = QTableWidgetItem("")
            sep_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집(Editable) 제외
            self.table.setItem(sep_row1, c, sep_it)
            
            # 제목줄 셀 생성 및 플래그 설정
            t_it = QTableWidgetItem(full_headers[c])
            t_it.setBackground(QColor(240, 240, 240)); t_it.setFont(bold_font)
            t_it.setTextAlignment(Qt.AlignCenter)
            t_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집(Editable) 제외
            self.table.setItem(title_row, c, t_it)







        # 3. 두 번째 표 (당년도)
        year_item2 = QTableWidgetItem("당\n년\n도")
        year_item2.setTextAlignment(Qt.AlignCenter)
        year_item2.setBackground(QColor(245, 245, 245))
        self.table.setItem(data2_start_idx, 0, year_item2)
        self.table.setSpan(data2_start_idx, 0, rank_count, 1)
        self.table.setRowHeight(data2_start_idx-1, 30)

        for i in range(rank_count):
            curr_r = data2_start_idx + i
            is_last = (i == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[i])
            it_rank.setTextAlignment(Qt.AlignCenter)
            it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집(Editable) 제외            
            self.table.setItem(curr_r, 1, it_rank)

            for c in range(2, 15):
                it = S4ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if is_last or c == 14:
                    it.setBackground(self.base_sky_blue)
                    if is_last: it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(curr_r, c, it)

        # 4. 주석 복구
        self.table.setRowHeight(sep_row2, 15)
        self.table.setRowHeight(comment_row, 60)
        self.table.setSpan(comment_row, 0, 1, 15)
        comment_text = (
            " * 각 직급별 매월 인원은 해당 월말 현재의 인원을 집계함...\n"
            " * 각 직급별 평균인원은 1월부터 12월까지의 인원 총계를 12로 나누어서 구하되 소수점 이하 둘째 자리에서 반올림함."
        )
        c_item = QTableWidgetItem(comment_text)
        c_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(comment_row, 0, c_item)
        
        self.table.blockSignals(False)
        
        
        

        
    def calculate_s4(self, item):
        r, c = item.row(), item.column()
        
        sep_row1 = rank_count
        title_row = sep_row1 + 1
        data2_start = title_row + 1
        
        # 계산 제외: 구분, 직급, 평균인원 열 또는 특수 행
        if c < 2 or c == 14 or r in [sep_row1, title_row]: 
            return 
        
        self.table.blockSignals(True)
        try:
            # 1. 범위 판정
            if r < sep_row1:
                start_row = 0
                last_row = rank_count - 1 # 계
            elif r >= data2_start:
                start_row = data2_start
                last_row = data2_start + rank_count - 1 # 계
            else: return

            '''
            # 2. 해당 행의 가로 평균 계산 (수정된 행만 계산)
            row_sum = sum(self.cell_value(r, col) for col in range(2, 14))
            avg_val = round(row_sum / 12, 2)
            avg_item = self.table.item(r, 14)
            if avg_item: avg_item.setData(Qt.EditRole, avg_val)
            

            # 3. 세로 합계 (해당 월의 계 계산)
            col_sum = sum(self.cell_value(start_row + i, c) for i in range(rank_count - 1))
            sum_item = self.table.item(last_row, c)
            if sum_item: sum_item.setData(Qt.EditRole, round(col_sum, 2))

            # 4. 최종 합계 행의 평균 계산
            total_avg_sum = sum(self.cell_value(start_row + i, 14) for i in range(rank_count - 1))
            total_avg_item = self.table.item(last_row, 14)
            if total_avg_item: total_avg_item.setData(Qt.EditRole, round(total_avg_sum, 2))
            '''



            row_sum = sum(self.cell_value(r, col) for col in range(2, 14))
            avg_val = round(row_sum / 12, 2)
            avg_item = self.table.item(r, 14)
            if avg_item: 
                # [수정] 1.50 -> 1.5로 변환하여 텍스트로 주입
                formatted_avg = format(avg_val, ".2f").rstrip('0').rstrip('.')
                avg_item.setText(formatted_avg)

            # 3. 세로 합계 (해당 월의 계 계산)
            col_sum = sum(self.cell_value(start_row + i, c) for i in range(rank_count - 1))
            sum_item = self.table.item(last_row, c)
            if sum_item: 
                # [수정] 합계도 동일하게 0 제거 로직 적용
                formatted_sum = format(round(col_sum, 2), ".2f").rstrip('0').rstrip('.')
                sum_item.setText(formatted_sum)

            # 4. 최종 합계 행의 평균 계산
            total_avg_sum = sum(self.cell_value(start_row + i, 14) for i in range(rank_count - 1))
            total_avg_item = self.table.item(last_row, 14)
            if total_avg_item: 
                # [수정] 최종 합계 평균도 0 제거
                formatted_total_avg = format(round(total_avg_sum, 2), ".2f").rstrip('0').rstrip('.')
                total_avg_item.setText(formatted_total_avg)






        finally: 
            self.table.blockSignals(False)
            

        



    def cell_value(self, row, col):
        """테이블 아이템의 텍스트를 float으로 안전하게 변환 (모든 시트 공통)"""
        item = self.table.item(row, col)
        if item and item.text().strip():
            try:
                # 콤마 제거 후 숫자로 변환
                return float(item.text().replace(',', ''))
            except ValueError:
                return 0.0
        return 0.0

    def get_data_to7(self):
        """S4의 '당년도' 영역(11~18행) 데이터를 추출하여 S7로 전달"""
        n_rows = rank_count - 1       
        data = [[0.0 for _ in range(12)] for _ in range(n_rows)]
        
        # S4 구조: 당년도 데이터는 11행부터 시작, 1월은 2열부터 시작
        start_row = rank_count + 2
        start_col = 2

        for r in range(n_rows):
            for m in range(12):
                # 공통 cell_value 함수를 사용하여 안전하게 값 추출
                data[r][m] = self.cell_value(start_row + r, start_col + m)
        return data


    def get_avg_data_to8(self):
        """S8의 평균단가 계산을 위해 S4의 14열(평균인원) 데이터 추출 + 로그 출력"""
        n_rows = rank_count - 1
        prev_year = [self.cell_value(r, 14) for r in range(n_rows)]      # 전년도 0~7행
        curr_year = [self.cell_value(rank_count + 2 + r, 14) for r in range(n_rows)] # 당년도 11~18행
        
        return [prev_year, curr_year]
    

            
    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사 (Ctrl+C)")
        paste_action = menu.addAction("붙여넣기 (Ctrl+V)")
        
        # 마우스 위치에 메뉴 띄우기
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        
        if action == copy_action:
            self.copy_selection()
        elif action == paste_action:
            self.paste_selection()

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r = min(r.topRow() for r in selection)
        max_r = max(r.bottomRow() for r in selection)
        min_c = min(r.leftColumn() for r in selection)
        max_c = max(r.rightColumn() for r in selection)
        
        lines = []
        # 제목줄 포함 복사 (선택 범위에 상단 제목이 포함될 경우)
        if min_r == 0:
            headers = [self.table.horizontalHeaderItem(c).text().replace('\n', ' ') for c in range(min_c, max_c + 1)]
            lines.append("\t".join(headers))

        for r in range(min_r, max_r + 1):
            # [수정] 10행(index 9)과 20행(index 19)도 빈 줄로 포함하여 복사
            if r in [rank_count, (rank_count*2)+1]:
                # 해당 범위만큼 빈 탭(\t)을 추가하여 엑셀에서 빈 줄로 인식하게 함
                empty_line = [""] * (max_c - min_c + 1)
                lines.append("\t".join(empty_line))
                continue

            row_data = []
            # 엑셀 수식용 상대 좌표 (전년도는 2행부터, 당년도는 13행부터 시작 가정)
            ex_row = (r + 2) if r <= 8 else (r + 1) # 행 번호에 맞춰 조정

            for c in range(min_c, max_c + 1):
                col_L = chr(ord('A') + c)
                # 수식 복사 로직 (평균 및 계)
                if c == 14 and r not in [rank_count-1, rank_count+1, rank_count*2, (rank_count*2)+2]: # 일반 데이터 행 평균
                    val = f"=AVERAGE(C{ex_row}:N{ex_row})"
                elif (r == rank_count or r == rank_count*2) and c >= 2: # 계 행 합계
                    val = f"=SUM({col_L}{ex_row-8}:{col_L}{ex_row-1})"
                else:
                    it = self.table.item(r, c)
                    # 콤마 제거하고 순수 텍스트만 추출
                    val = it.text().replace(',', '').strip() if it else ""
                row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))

        



    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        self.table.blockSignals(True)
        affected_rows = set()
        affected_cols = set()
        
        # [행 계산 기준] setup_content에서 정의한 인덱스 재확인
        sep_row1 = rank_count           # 9 (인덱스 9)
        title_row = sep_row1 + 1        # 10
        data2_start_idx = title_row + 1 # 11 (당년도 첫 데이터 행)
        
        # 보호할 행 (구분선, 제목줄 등)
        protected_rows = [rank_count, rank_count + 1, (rank_count * 2) + 2] 

        lines = text.splitlines()
        for i, line in enumerate(lines):
            parts = line.split('\t')
            for j, val in enumerate(parts):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    # 14열(평균인원), 0~1열(구분), 제목행 차단
                    if c < 2 or c == 14 or r in protected_rows:
                        continue
                        
                    item = self.table.item(r, c)
                    if item and (item.flags() & Qt.ItemIsEditable):
                        item.setText(val.strip().replace(',', ''))
                        affected_rows.add(r)
                        affected_cols.add(c)
        
        self.table.blockSignals(False)

        # 1. 가로 계산 (각 행별 평균인원 갱신)
        for r_idx in affected_rows:
            # 해당 행의 아무 데이터 셀이나 던짐
            row_trigger = self.table.item(r_idx, 2)
            if row_trigger: self.calculate_s4(row_trigger)

        # 2. 세로 계산 (각 열별 '계' 행 갱신) - 이 부분이 핵심!
        for c_idx in affected_cols:
            # [전년도 계 갱신] 0행(첫 번째 직급)을 던지면 첫 표의 '계'가 계산됨
            prev_trigger = self.table.item(0, c_idx)
            if prev_trigger: self.calculate_s4(prev_trigger)
                
            # [당년도 계 갱신] data2_start_idx(당년도 첫 직급)를 던져야 두 번째 표의 '계'가 계산됨
            # 중요: rank_count + 2 같은 부정확한 숫자 대신 변수를 사용하세요.
            curr_trigger = self.table.item(data2_start_idx, c_idx)
            if curr_trigger:
                self.calculate_s4(curr_trigger)

        # 3. 외부 시트 연동 (S7, S8)
        if hasattr(self, 'main_window') and self.main_window:
            # S8 평균인원 동기화
            if hasattr(self.main_window, 's8'):
                self.main_window.s8.sync_from_s4(self.get_avg_data_to8())
            # S7 데이터 합산 동기화
            if hasattr(self.main_window, 's7') and hasattr(self.main_window, 's6'):
                self.main_window.s7.sync_s7_data(self.get_data_to7(), self.main_window.s6.get_data_to7())
    

    # 키보드 단축키 지원
    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self.copy_selection()
        elif event.matches(QKeySequence.Paste):
            self.paste_selection()
        else:
            super().keyPressEvent(event)
