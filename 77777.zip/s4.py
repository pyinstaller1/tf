from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence


rank_count = 8

class S4ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            try:
                # 빈칸이나 None 처리
                if val is None or str(val).strip() == "":
                    return "0.0"

                num = float(str(val).replace(',', ''))

                if self.column() == 14:
                    return format(num, ",.1f")
                else:
                    return format(num, ",.1f")
            except:
                return "0.0"  # 숫자가 아니면 0.0
        return super().data(role)




            
    

# [2] 실시간 우측 정렬 델리게이트 (엔터 및 방향키 통합)
class S4RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        if parent:
            parent.installEventFilter(self)
            
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 입력 중(에디터 활성화)일 때도 키 감시
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (수정 모드 진입 X)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시에도 단순 선택(Index 변경)만 수행"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)








        

class Sheet4Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent

        global rank_count
        rank_count = len(self.main_window.list_title_04)

        
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-2) 직급별 평균인원 계산")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget((rank_count * 2) + 1, 15)
        
        months = [f"{i}월" for i in range(1, 13)]
        headers = ["구분", "직급"] + months + ["평균인원"]
        self.table.setHorizontalHeaderLabels(headers)

        # [1] 우클릭 메뉴 정책 설정 (이게 있어야 메뉴가 뜹니다)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # 스타일시트 적용
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section:horizontal {
                background-color: #f4f4f4; padding: 2px; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; padding-left: 5px; padding-right: 5px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)

        self.table.verticalHeader().setVisible(True)
        self.table.verticalHeader().setFixedWidth(25)
        self.table.verticalHeader().setDefaultSectionSize(26)
        
        self.delegate = S4RightAlignedDelegate(self.table)
        
        for i in range(2, 15): 
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        # 열 너비 설정
        self.table.setColumnWidth(0, 38)
        self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 70)
        self.table.setColumnWidth(14, 70)

        self.table.itemChanged.connect(self.calculate_s4)
        layout.addWidget(self.table)




    def setup_content(self):
        self.table.blockSignals(True)
        
        # [수정] 행 구성 정의 (S5와 동일한 로직 적용)
        sep_row1 = rank_count            # 8
        title_row = sep_row1 + 1         # 9
        data2_start_idx = title_row + 1  # 10
        sep_row2 = data2_start_idx + rank_count # 18
        comment_row = sep_row2 + 1       # 19

        # 전체 행수 설정 (+4는 여유 공간 및 주석 포함)
        self.table.setRowCount((rank_count * 2) + 4)
        self.table.setColumnCount(15)


        ranks = list(self.main_window.list_title_04)
        # ranks = ["1급", "2급", "3급", "4급", "5급", "6급", "7급", "연구직", "계"]
        months_headers = [f"{i}월" for i in range(1, 13)]
        full_headers = ["구분", "직급"] + months_headers + ["평균인원"]
        
        bold_font = QFont(); bold_font.setBold(True)

        # 1. 첫 번째 표 (전년도)
        year_item1 = QTableWidgetItem("전\n년\n도")
        year_item1.setTextAlignment(Qt.AlignCenter)
        year_item1.setBackground(QColor(245, 245, 245))
        self.table.setItem(0, 0, year_item1)
        self.table.setSpan(0, 0, rank_count, 1)

        for r in range(rank_count):
            is_last = (r == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[r])
            it_rank.setTextAlignment(Qt.AlignCenter)
            it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집(Editable) 제외
            self.table.setItem(r, 1, it_rank)
            
            for c in range(2, 15):
                it = S4ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                # 계 행(마지막 행)이거나 평균인원(14열)이면 잠금
                if is_last or c == 14:
                    it.setBackground(self.base_sky_blue)
                    if is_last: it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(r, c, it)

        # 2. 중간 구분선 & 제목줄
        self.table.setRowHeight(sep_row1, 15)
        self.table.setRowHeight(title_row, 45)
        for c in range(15):
            # 구분선 셀 생성 및 플래그 설정
            sep_it = QTableWidgetItem("")
            sep_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집(Editable) 제외
            self.table.setItem(sep_row1, c, sep_it)
            
            # 제목줄 셀 생성 및 플래그 설정
            t_it = QTableWidgetItem(full_headers[c])
            t_it.setBackground(QColor(240, 240, 240)); t_it.setFont(bold_font)
            t_it.setTextAlignment(Qt.AlignCenter)
            t_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집(Editable) 제외
            self.table.setItem(title_row, c, t_it)







        # 3. 두 번째 표 (당년도)
        year_item2 = QTableWidgetItem("당\n년\n도")
        year_item2.setTextAlignment(Qt.AlignCenter)
        year_item2.setBackground(QColor(245, 245, 245))
        self.table.setItem(data2_start_idx, 0, year_item2)
        self.table.setSpan(data2_start_idx, 0, rank_count, 1)
        self.table.setRowHeight(data2_start_idx-1, 30)

        for i in range(rank_count):
            curr_r = data2_start_idx + i
            is_last = (i == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[i])
            it_rank.setTextAlignment(Qt.AlignCenter)
            it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집(Editable) 제외            
            self.table.setItem(curr_r, 1, it_rank)

            for c in range(2, 15):
                it = S4ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if is_last or c == 14:
                    it.setBackground(self.base_sky_blue)
                    if is_last: it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(curr_r, c, it)

        # 4. 주석 복구
        self.table.setRowHeight(sep_row2, 15)
        self.table.setRowHeight(comment_row, 60)
        self.table.setSpan(comment_row, 0, 1, 15)
        comment_text = (
            " * 각 직급별 매월 인원은 해당 월말 현재의 인원을 집계함...\n"
            " * 각 직급별 평균인원은 1월부터 12월까지의 인원 총계를 12로 나누어서 구하되 소수점 이하 둘째 자리에서 반올림함."
        )
        c_item = QTableWidgetItem(comment_text)
        c_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(comment_row, 0, c_item)
        
        self.table.blockSignals(False)
        
        
        

        
    def calculate_s4(self, item):
        r, c = item.row(), item.column()
        
        # [설정값] 전역변수 rank_count=9 기준
        sep_row1 = rank_count             # 9
        title_row = sep_row1 + 1          # 10
        data2_start = title_row + 1       # 11
        
        # 계산 제외 영역
        if c < 2 or c == 14 or r in [sep_row1, title_row]: 
            return 
        
        self.table.blockSignals(True)
        try:
            # 1. 어느 표인지 판정 및 데이터 행 범위 설정 (계 행 제외)
            if r < sep_row1:
                start_r = 0
                end_r = rank_count - 1  # '계' 행 바로 전까지
                last_r = rank_count - 1 # '계' 행 위치
            else:
                start_r = data2_start
                end_r = data2_start + rank_count - 1 # '계' 행 바로 전까지
                last_r = data2_start + rank_count - 1 # '계' 행 위치

            # 2. 가로 평균 계산 (현재 수정된 행)
            row_sum = 0.0
            for col in range(2, 14):
                val_it = self.table.item(r, col)
                if val_it and val_it.text().strip():
                    row_sum += float(val_it.text().replace(',', ''))
            
            avg_val = round(row_sum / 12, 2)
            it_avg = self.table.item(r, 14)
            if it_avg:
                it_avg.setText(format(avg_val, ".1f"))

            # 3. 세로 합계 계산 (현재 수정된 월의 '계')
            col_sum = 0.0
            for row in range(start_r, end_r): # 데이터 행만 순회
                val_it = self.table.item(row, c)
                if val_it and val_it.text().strip():
                    col_sum += float(val_it.text().replace(',', ''))
            
            it_sum = self.table.item(last_r, c)
            if it_sum:
                it_sum.setText(format(round(col_sum, 2), ".1f"))

            # 4. [수정 포인트] 전체 평균의 합계 (마지막 셀)
            # '평균인원' 열의 데이터 행들만 더해서 '계' 행에 뿌려줌
            total_avg_sum = 0.0
            for row in range(start_r, end_r): # 데이터 행만 순회 (계 행 제외)
                val_it = self.table.item(row, 14)
                if val_it and val_it.text().strip():
                    total_avg_sum += float(val_it.text().replace(',', ''))
            
            it_total = self.table.item(last_r, 14)
            if it_total:
                # 합산된 평균인원을 소수점 2자리로 깔끔하게 표시
                it_total.setText(format(round(total_avg_sum, 1), ".1f"))

        except Exception as e:
            print(f"계산 오류: {e}")
        finally:
            self.table.blockSignals(False)
        



    def cell_value(self, row, col):
        """테이블 아이템의 텍스트를 float으로 안전하게 변환 (모든 시트 공통)"""
        item = self.table.item(row, col)
        if item and item.text().strip():
            try:
                # 콤마 제거 후 숫자로 변환
                return float(item.text().replace(',', ''))
            except ValueError:
                return 0.0
        return 0.0

    def get_data_to7(self):
        """S4의 '당년도' 영역(11~18행) 데이터를 추출하여 S7로 전달"""
        n_rows = rank_count - 1       
        data = [[0.0 for _ in range(12)] for _ in range(n_rows)]
        
        # S4 구조: 당년도 데이터는 11행부터 시작, 1월은 2열부터 시작
        start_row = rank_count + 2
        start_col = 2

        for r in range(n_rows):
            for m in range(12):
                # 공통 cell_value 함수를 사용하여 안전하게 값 추출
                data[r][m] = self.cell_value(start_row + r, start_col + m)
        return data


    def get_avg_data_to8(self):
        """S8의 평균단가 계산을 위해 S4의 14열(평균인원) 데이터 추출 + 로그 출력"""
        n_rows = rank_count - 1
        prev_year = [self.cell_value(r, 14) for r in range(n_rows)]      # 전년도 0~7행
        curr_year = [self.cell_value(rank_count + 2 + r, 14) for r in range(n_rows)] # 당년도 11~18행
        
        return [prev_year, curr_year]
    

            
    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사 (Ctrl+C)")
        paste_action = menu.addAction("붙여넣기 (Ctrl+V)")
        
        # 마우스 위치에 메뉴 띄우기
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        
        if action == copy_action:
            self.copy_selection()
        elif action == paste_action:
            self.paste_selection()

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)

        # rank_count = 9 기준 (데이터 8줄, 계 1줄)
        data_rows_in_table = rank_count - 1   # 8
        sep_row1 = rank_count                 # 9 (전년도 계 행)
        title_row = sep_row1 + 1              # 10
        data2_start_idx = title_row + 1       # 11
        sep_row2 = data2_start_idx + rank_count - 1 # 19 (당년도 계 행)

        lines = []
        for r in range(min_r, max_r + 1):
            # 구분선 및 제목행 처리
            if r == sep_row1 or r == title_row:
                row_data = []
                for c in range(min_c, max_c + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text() if it else "")
                lines.append("\t".join(row_data))
                continue

            row_data = []
            # '계' 행인지 판정 (r=8 또는 r=19)
            is_total_row = (r == sep_row1 - 1) or (r == sep_row2)

            for c in range(min_c, max_c + 1):
                # 1. 가로 평균 (14열)
                if c == 14 and not is_total_row:
                    formula = (
                        "=ROUND(AVERAGE("
                        "INDEX($1:$1048576,ROW(),COLUMN()-12):"
                        "INDEX($1:$1048576,ROW(),COLUMN()-1)"
                        "),1)"
                    )
                    row_data.append(formula)

                # 2. 세로 합계 ('계' 행) - ROW()-8 부터 ROW()-1 까지 본인 표만 합산
                elif is_total_row and 2 <= c <= 14:
                    offset = data_rows_in_table
                    formula = (
                        f"=SUM("
                        f"INDEX($1:$1048576,ROW()-{offset},COLUMN()):"
                        f"INDEX($1:$1048576,ROW()-1,COLUMN())"
                        f")"
                    )
                    row_data.append(formula)

                # 3. 일반 데이터
                else:
                    it = self.table.item(r, c)
                    if it:
                        txt = it.text().replace(',', '').strip()
                        row_data.append(txt)
                    else:
                        row_data.append("")
            
            lines.append("\t".join(row_data))
        
        QApplication.clipboard().setText("\n".join(lines))



    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        self.table.blockSignals(True)
        affected_rows = set()
        affected_cols = set()
        
        # [행 계산 기준] setup_content에서 정의한 인덱스 재확인
        sep_row1 = rank_count           # 9 (인덱스 9)
        title_row = sep_row1 + 1        # 10
        data2_start_idx = title_row + 1 # 11 (당년도 첫 데이터 행)
        
        # 보호할 행 (구분선, 제목줄 등)
        protected_rows = [rank_count, rank_count + 1, (rank_count * 2) + 2] 

        lines = text.splitlines()
        for i, line in enumerate(lines):
            parts = line.split('\t')
            for j, val in enumerate(parts):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    # 14열(평균인원), 0~1열(구분), 제목행 차단
                    if c < 2 or c == 14 or r in protected_rows:
                        continue
                        
                    item = self.table.item(r, c)
                    if item and (item.flags() & Qt.ItemIsEditable):
                        item.setText(val.strip().replace(',', ''))
                        affected_rows.add(r)
                        affected_cols.add(c)
        
        self.table.blockSignals(False)

        # 1. 가로 계산 (각 행별 평균인원 갱신)
        for r_idx in affected_rows:
            # 해당 행의 아무 데이터 셀이나 던짐
            row_trigger = self.table.item(r_idx, 2)
            if row_trigger: self.calculate_s4(row_trigger)

        # 2. 세로 계산 (각 열별 '계' 행 갱신) - 이 부분이 핵심!
        for c_idx in affected_cols:
            # [전년도 계 갱신] 0행(첫 번째 직급)을 던지면 첫 표의 '계'가 계산됨
            prev_trigger = self.table.item(0, c_idx)
            if prev_trigger: self.calculate_s4(prev_trigger)
                
            # [당년도 계 갱신] data2_start_idx(당년도 첫 직급)를 던져야 두 번째 표의 '계'가 계산됨
            # 중요: rank_count + 2 같은 부정확한 숫자 대신 변수를 사용하세요.
            curr_trigger = self.table.item(data2_start_idx, c_idx)
            if curr_trigger:
                self.calculate_s4(curr_trigger)

        # 3. 외부 시트 연동 (S7, S8)
        if hasattr(self, 'main_window') and self.main_window:
            # S8 평균인원 동기화
            if hasattr(self.main_window, 's8'):
                self.main_window.s8.sync_from_s4(self.get_avg_data_to8())
            # S7 데이터 합산 동기화
            if hasattr(self.main_window, 's7') and hasattr(self.main_window, 's6'):
                self.main_window.s7.sync_s7_data(self.get_data_to7(), self.main_window.s6.get_data_to7())
    

    # 키보드 단축키 지원
    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self.copy_selection()
        elif event.matches(QKeySequence.Paste):
            self.paste_selection()
        else:
            super().keyPressEvent(event)





















