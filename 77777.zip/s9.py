from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

rank_count = 9

class S9RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 생성 시 부모(TableWidget)를 이벤트 필터로 등록 (평소 상태 감시)
        if parent:
            parent.installEventFilter(self)
            
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 입력 중(에디터 활성화)일 때도 키 감시를 위해 필터 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (데이터 저장 보장)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # 데이터를 모델에 반영하기 위해 setCurrentIndex 사용
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나, 커서가 텍스트 맨 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나, 커서가 텍스트 맨 앞일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 인덱스만 변경 (이동 후 자동 편집 제거)"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class S9ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "":
                return ""
            try:
                num = float(str(val).replace(',', ''))

                # ⭐ 평균정원(14열)은 항상 소수 2자리
                if self.column() == 14:
                    return format(num, ",.1f")

                # 나머지 열은 정수 우선
                if num == int(num):
                    return format(int(num), ",")
                else:
                    return format(num, ",.1f").rstrip('0').rstrip('.')
            except:
                return val
        return super().data(role)

class Sheet9Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent


        global rank_count
        rank_count = len(self.main_window.list_title_09)
        
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-6) 가. 초임직급 정원")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        # [수정] rank_count=9 대응: (9*2) + 4 = 22행
        self.table = QTableWidget(((rank_count * 2) + 4), 15) 
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["평균정원"]
        self.table.setHorizontalHeaderLabels(headers)

        # 제목바 및 구분선 스타일 (기존 시트와 동일하게 유지)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section:horizontal {
                background-color: #f4f4f4; padding: 2px; 
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; padding-left: 5px; padding-right: 5px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)


        self.table.verticalHeader().setFixedWidth(25)
        self.table.verticalHeader().setDefaultSectionSize(26)

        self.delegate = S9RightAlignedDelegate(self.table)
        for i in range(2, 15):
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 50)
        self.table.setColumnWidth(14, 70)

        self.table.itemChanged.connect(self.calculate_s9)
        layout.addWidget(self.table)

        

    def setup_content(self):
        # 1. 초기화 및 행/열 크기 설정
        self.table.blockSignals(True)
        
        # 전체 행 수: (직급수 * 2) + 중간제목(1) + 구분선(2) + 주석(1) = 22행 (rank_count 9 기준)
        total_rows = (rank_count * 2) + 4
        self.table.setRowCount(total_rows)
        self.table.setColumnCount(15)

        # 직급 리스트 정의

        ranks_ref = list(self.main_window.list_title_09)
        # ranks_ref.insert(-1, '기능직')

        
        # ranks_ref = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직", "기능직", "계"]
        display_ranks = ranks_ref[:rank_count-1] + ["계"]

        for r in range(total_rows):
            # --- [A] 특수 행 판정 (구분선, 제목줄, 주석) ---
            if r in [rank_count, rank_count + 1, total_rows - 2, total_rows - 1]:
                for c in range(15):
                    if r == rank_count + 1:  # 중간 제목줄 (편집 불가)
                        titles = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["평균정원"]
                        item = QTableWidgetItem(titles[c])
                        item.setTextAlignment(Qt.AlignCenter)
                        item.setBackground(QColor(244, 244, 244))
                        f = item.font(); f.setBold(True); item.setFont(f)
                        # 중요: 편집 권한 제거
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        
                    elif r == total_rows - 1: # 맨 마지막 주석 (편집 불가)
                        item = QTableWidgetItem("평균정원: 나.초임직급 인건비 효과 계산에 반영" if c == 0 else "")
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        
                    else: # 구분선 (선택 불가)
                        item = QTableWidgetItem("")
                        item.setFlags(Qt.NoItemFlags) # 클릭 및 포커스 차단
                        item.setForeground(Qt.transparent)
                    
                    self.table.setItem(r, c, item)
                
                # 주석 셀 병합
                if r == total_rows - 1:
                    self.table.setSpan(r, 0, 1, 15)
                continue

            # --- [B] 데이터 영역 (전년도 / 당년도) ---
            for c in range(15):
                item = S9ThousandSeparatorItem("0")
                
                # 합계 행(계) 위치 판정
                is_sum = (r == rank_count - 1 or r == total_rows - 3)

                # [정렬 설정] S7과 동일하게: 0,1열 가운데 / 나머지 우측
                if c < 2:
                    item.setTextAlignment(Qt.AlignCenter)
                else:
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

                # 배경색 및 폰트 스타일
                if c == 1 or is_sum or c == 14:
                    item.setBackground(self.base_sky_blue)
                    if is_sum or c == 14:
                        f = item.font(); f.setBold(True); item.setFont(f)

                # 구분(전년도/당년도) 및 직급 텍스트 입력
                if c == 0: # 0열: 구분
                    item.setBackground(QColor(245, 245, 245))
                    if r == 0: item.setText("당년도")
                    elif r == rank_count + 2: item.setText("전년도")
                elif c == 1: # 1열: 직급
                    idx = r if r < rank_count else r - (rank_count + 2)
                    if 0 <= idx < len(display_ranks):
                        item.setText(display_ranks[idx])
                
                # 편집 권한 설정: 실제 입력 데이터(2~13열)이고 계 행이 아닐 때만 Editable
                if 2 <= c <= 13 and not is_sum:
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                else:
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                
                self.table.setItem(r, c, item)

        # 3. 마무리 (병합 및 행 높이)
        if rank_count > 1:
            self.table.setSpan(0, 0, rank_count, 1)          
            self.table.setSpan(rank_count + 2, 0, rank_count, 1) 
        
        self.table.setSpan(self.table.rowCount() - 1, 0, 1, 15)

        self.table.setRowHeight(rank_count, 10)          
        self.table.setRowHeight(self.table.rowCount() - 2, 10)
        
        self.table.blockSignals(False)











        

    def calculate_s9(self, item):
        if item is None: return
        row, col = item.row(), item.column()
        
        # 1. 기준 좌표 계산 (rank_count 기반)
        sep_row1 = rank_count           # 첫 번째 구분선
        title_row = rank_count + 1      # 중간 제목줄
        data2_start = rank_count + 2    # 당년도 데이터 시작
        total_rows = self.table.rowCount()
        
        prev_sum_row = rank_count - 1   # 전년도 '계' 행 (6번)
        curr_sum_row = total_rows - 3   # 당년도 '계' 행 (15번)

        # 2. [중요] 계산을 수행하면 안 되는 행들 (여기에 고정 숫자가 있으면 안 됩니다)
        # 구분선, 제목줄, 주석줄, 그리고 '계' 줄 자체를 수정했을 때는 계산하지 않음
        invalid_rows = [sep_row1, title_row, total_rows - 2, total_rows - 1, prev_sum_row, curr_sum_row]
        if col < 2 or col == 14 or row in invalid_rows:
            return 
        
        self.table.blockSignals(True)
        try:
            # 3. 데이터 영역 판별 및 범위 설정
            if 0 <= row < prev_sum_row:
                data_range = range(0, prev_sum_row)
                sum_row = prev_sum_row
            elif data2_start <= row < curr_sum_row:
                data_range = range(data2_start, curr_sum_row)
                sum_row = curr_sum_row
            else:
                return

            # --- A. 행 계산 (가로 평균) ---
            row_sum = sum(self.cell_val(row, c) for c in range(2, 14))
            # 평균정원(14열) 입력
            self.table.item(row, 14).setData(Qt.EditRole, round((row_sum / 12) + 0.000001, 1))


            # --- B. 열 계산 (세로 합계) ---
            # 현재 수정된 열(col)의 합계
            col_total = sum(self.cell_val(r, col) for r in data_range)
            self.table.item(sum_row, col).setData(Qt.EditRole, int(col_total))

            # --- C. [핵심] 평균정원 열(14열)의 세로 합계 ---
            # 각 직급별로 계산된 14열의 값들을 모두 더해 '계' 줄의 14열에 입력
            total_avg = sum(self.cell_val(r, 14) for r in data_range)

            # self.table.item(sum_row, 14).setData(Qt.EditRole, round((row_sum / 12) + 0.000001, 1))

            self.table.item(sum_row, 14).setData(Qt.EditRole, round(total_avg + 0.000001, 1))






            

        except Exception as e:
            print(f"S9 계산 오류: {e}")
        finally:
            self.table.blockSignals(False)

    def cell_val(self, r, c):
        """셀의 값을 float으로 변환하여 반환"""
        it = self.table.item(r, c)
        if not it: return 0.0
        val = str(it.data(Qt.EditRole)).replace(',', '').strip()
        
        try:
            return float(val) if val else 0.0
        except:
            return 0.0



    def get_data_to10(self):
        """
        S10 시트로 보낼 평균정원 데이터를 추출합니다.
        rank_count (순수 직급 + 계 행 포함) 전체를 추출하여 데이터 불일치를 방지합니다.
        """
        prev_year_data = []
        curr_year_data = []

        # 당년도 시작행: 전년도(rank_count) + 구분선(1) + 제목줄(1) = rank_count + 2
        data2_start = rank_count + 2 

        # [수정] rank_count 전체를 반복하여 마지막 직급과 '계' 행까지 모두 담습니다.
        for i in range(rank_count):
            # 1. 전년도 데이터 추출 (14열: 평균정원)
            it_p = self.table.item(i, 14)
            val_p = it_p.text().replace(',', '') if it_p and it_p.text() else "0"
            try:
                prev_year_data.append(float(val_p))
            except:
                prev_year_data.append(0.0)

            # 2. 당년도 데이터 추출 (data2_start부터 시작)
            it_c = self.table.item(data2_start + i, 14)
            val_c = it_c.text().replace(',', '') if it_c and it_c.text() else "0"
            try:
                curr_year_data.append(float(val_c))
            except:
                curr_year_data.append(0.0)

        # S10의 sync_from_s9에서 인자로 받을 리스트 구조 [prev, curr] 반환
        return [curr_year_data, prev_year_data]



    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        # [인덱스 기준 정의]
        y1_sum_row = rank_count - 1       # 전년도 계 행
        data2_start = rank_count + 2      # 당년도 시작 행
        y2_sum_row = data2_start + rank_count - 1 # 당년도 계 행
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []

        # 1. 헤더 복사
        if min_r == 0:
            h_row = [self.table.horizontalHeaderItem(c).text().replace('\n', ' ') if self.table.horizontalHeaderItem(c) else "" for c in range(min_c, max_c + 1)]
            lines.append("\t".join(h_row))

        for r in range(min_r, max_r + 1):
            # 구분선, 제목줄 등 텍스트 행
            if r in [rank_count, rank_count + 1, y2_sum_row + 1, y2_sum_row + 2]:
                row_data = []
                for c in range(min_c, max_c + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data))
                continue

            row_data = []
            for c in range(min_c, max_c + 1):
                
                # --- [INDEX 수식 핵심 로직] ---
                
                # 1. 가로 평균 (인덱스 14: 평균인원)
                if c == 14 and r not in [y1_sum_row, y2_sum_row]:
                    # 현재 셀 기준 왼쪽 12번째(1월)부터 왼쪽 1번째(12월)까지 평균
                    formula = (
                        "=ROUND(AVERAGE("
                        "INDEX($1:$1048576, ROW(), COLUMN()-12):"
                        "INDEX($1:$1048576, ROW(), COLUMN()-1)"
                        "), 1)"
                    )
                    row_data.append(formula)

                # 2. 전년도 세로 합계 (y1_sum_row)
                elif r == y1_sum_row and 2 <= c <= 14:
                    # 현재 행 기준 위로 (rank_count-1)개 행부터 바로 위 행까지 합계
                    offset = rank_count - 1
                    formula = (
                        f"=SUM("
                        f"INDEX($1:$1048576, ROW()-{offset}, COLUMN()):"
                        f"INDEX($1:$1048576, ROW()-1, COLUMN())"
                        f")"
                    )
                    row_data.append(formula)

                # 3. 당년도 세로 합계 (y2_sum_row)
                elif r == y2_sum_row and 2 <= c <= 14:
                    # 현재 행 기준 위로 (rank_count-1)개 행부터 바로 위 행까지 합계
                    offset = rank_count - 1
                    formula = (
                        f"=SUM("
                        f"INDEX($1:$1048576, ROW()-{offset}, COLUMN()):"
                        f"INDEX($1:$1048576, ROW()-1, COLUMN())"
                        f")"
                    )
                    row_data.append(formula)
                
                # 4. 일반 데이터
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
                    
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))



        

    def paste_selection(self):
        txt = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not txt or not curr: return
        
        self.table.blockSignals(True)
        lines = txt.splitlines()
        start_r, start_c = curr.row(), curr.column()
        
        affected_rows = set()
        for i, line in enumerate(lines):
            for j, val in enumerate(line.split('\t')):
                r, c = start_r + i, start_c + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and c >= 2 and (it.flags() & Qt.ItemIsEditable):
                        clean_val = val.strip().replace(',', '')
                        it.setData(Qt.EditRole, clean_val or "0")
                        affected_rows.add(r)
        
        self.table.blockSignals(False)
        if not affected_rows: return

        # 1. S9 내부 계산 (가로/세로 합계 갱신)
        for row in affected_rows:
            it = self.table.item(row, 2)
            if it: self.calculate_s9(it)

        for col in range(2, 15):
            t_item = self.table.item(0, col)
            if t_item: self.calculate_s9(t_item)
            data2_start = rank_count + 2
            if data2_start < self.table.rowCount():
                b_item = self.table.item(data2_start, col)
                if b_item: self.calculate_s9(b_item)

        # 2. [핵심] 연쇄 전송 로직 (S9 -> S10 -> S2)
        if hasattr(self, 'main_window') and self.main_window:
            s10 = getattr(self.main_window, 's10', None)
            s2 = getattr(self.main_window, 's2', None)
            
            if s10:
                # S9 데이터를 S10으로 동기화
                data = self.get_data_to10() 
                s10.sync_from_s9(data)
                
                # S10 내부 계산 실행 (시그널이 차단된 상태일 수 있으므로 직접 호출)
                s10.calculate_s10() 
                
                # S10 계산 결과를 S2(을)로 최종 전송
                if s2:
                    s2.sync_eul_from_s10(s10.get_eul_to_s2())

                    

    # 복사/붙여넣기 로직 (S11 수정사항 완벽 반영)
    def show_context_menu(self, pos):
        menu = QMenu()
        cp = menu.addAction("복사 (Ctrl+C)")
        ps = menu.addAction("붙여넣기 (Ctrl+V)")
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if act == cp: self.copy_selection()
        elif act == ps: self.paste_selection()
        

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
