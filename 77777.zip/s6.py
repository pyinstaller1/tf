from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

rank_count = 8

class S6RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 테이블 자체의 키 이벤트(평소 상태)를 감시하기 위해 필터 설치
        if parent:
            parent.installEventFilter(self)
            
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 입력 중(에디터 활성화)일 때 키 이벤트를 가로채기 위해 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택 유지)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # 데이터를 모델에 저장하기 위해 setCurrentIndex 사용
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나, 커서가 텍스트 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나, 커서가 텍스트 시작일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 단순 인덱스 변경만 수행"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

                


class S6ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.ForegroundRole:
            val = super().data(Qt.EditRole)
            try:
                if val is not None and float(str(val).replace(',', '')) < 0:
                    return QColor(Qt.red)
            except:
                pass
            return super().data(role) # 음수가 아니면 기본 색상


        
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "":
                return ""
            try:
                num = float(str(val).replace(',', ''))
                return format(num, ",.1f")   # 🔥 항상 소수 2자리
            except:
                return val
        return super().data(role)


class Sheet6Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        # 구성: 데이터(7행) + 구분선(1행) + 주석(1행) = 총 9행
        # 열 구성: 구분(0), 직급(1), 1~12월(2~13) = 총 14열
        self.table = QTableWidget(9, 14)
        
        months = [f"{i}월" for i in range(1, 13)]
        headers = ["구분", "직급"] + months
        self.table.setHorizontalHeaderLabels(headers)

        # [복구] 우클릭 메뉴 정책 설정 및 연결
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.verticalHeader().setFixedWidth(25)
        title = QLabel("나. 근속승진")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0; font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertical { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
        """)

        self.delegate = S6RightAlignedDelegate(self.table)
        for i in range(2, 14): self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        # 너비 설정
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 70)

        self.table.itemChanged.connect(self.calculate_s6)
        layout.addWidget(self.table)




            

    def setup_content(self):
        self.table.blockSignals(True)
        
        # 1. 직급 리스트 정의 (rank_count=9 기준: 0~7행 데이터, 8행 계)
        self.ranks = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직", "계"]
        
        # 2. 행 인덱스 동적 설정
        sum_row_idx = rank_count - 1      # 8행 (계)
        separator_idx = rank_count        # 9행 (구분선)
        comment_idx = rank_count + 1      # 10행 (주석)
        
        # 전체 행 수 설정 (데이터+합계 9행 + 구분선 1행 + 주석 1행 = 총 11행)
        self.table.setRowCount(comment_idx + 1)
        
        comment_text = (
            "\n * 직급별 누적차가 음수인 직급의 경우 해당 누적차(양수)를 기재하며, 그 이하 직급의 경우에는 해당 누적차(음수)를 기재함.\n\n"
            "   예시 1) 특정월의 4직급의 누적차가 –2인 경우 해당월의 4직급 란에는 2를 기재하고, 5급직 란에는 –2를 기재함.\n"
            "   예시 2) 특정월의 3직급의 누적차가 –3이고, 4직급의 누적차가 –2인 경우\n              3직급 란에는 3을 기재하고, 4직급 란에 -1."
        )

        
        for r in range(self.table.rowCount()):
            for c in range(14):
                if r == separator_idx: # --- 구분선 영역 ---
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags)
                    item.setBackground(Qt.white)
                    
                elif r == comment_idx: # --- 주석 영역 ---
                    item = QTableWidgetItem(comment_text if c == 0 else "")
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    # 주석 폰트 설정 (필요시)
                    if c == 0:
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignTop)
                
                else: # --- 데이터 및 합계 영역 (0~8행) ---
                    item = S6ThousandSeparatorItem("0")
                    # 정렬: 구분/직급(중앙), 데이터(우측)
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)
                    
                    # (1) S5 연동 데이터 영역 (0~7행, 2~13열) -> 노란색, 수정불가
                    if 2 <= c <= 13 and 0 <= r < sum_row_idx:
                        item.setBackground(QColor(255, 255, 225))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    
                    # (2) '계' 행 (8행) -> 하늘색, 수정불가, 굵게
                    elif r == sum_row_idx:
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if c >= 2: # 숫자 부분만 굵게
                            font = item.font()
                            font.setBold(True)
                            item.setFont(font)
                    
                    # (3) 직급열 (1열) -> 하늘색
                    if c == 1:
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)                        
                        if r < len(self.ranks):
                            item.setText(self.ranks[r])
                    
                    # (4) 구분열 (0열) -> 회색조
                    if c == 0:
                        item.setBackground(QColor(245, 245, 245))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r == 0:
                            item.setText("당년도")

                self.table.setItem(r, c, item)

        # 3. 테이블 레이아웃 마무리 (병합 등)
        # 당년도(0열)를 데이터+합계 행(0~8행)만큼 병합
        self.table.setSpan(0, 0, rank_count, 1) 
        # 주석 행 병합
        self.table.setSpan(comment_idx, 0, 1, 14)
        
        # 행 높이 조절
        self.table.setRowHeight(separator_idx, 10)  # 구분선은 얇게
        self.table.setRowHeight(comment_idx, 100)   # 주석은 넓게
        
        self.table.blockSignals(False)

        










    def calculate_s6(self, item=None):
        """S6 계산: 마지막 데이터 행(별도직군) 값을 '계' 행으로 복사"""
        
        # 행 인덱스 동적 설정
        sum_row = rank_count - 1      # 8행 (계)
        data_last_row = rank_count - 2 # 7행 (별도직군)

        if item is None:
            # 전체 계산 시 (초기화 또는 데이터 로드 시)
            cols = range(2, 14)
        else:
            row, col = item.row(), item.column()
            # 1. 계산 범위 체크: 0~7행 데이터 수정 시에만 작동
            # 2. '계' 행(8행)이나 그 아래(구분선, 주석) 수정 시에는 무시
            if col < 2 or col > 13 or row >= sum_row: 
                return
            cols = [col]

        self.table.blockSignals(True)
        try:
            for c in cols:
                # 데이터 마지막 행(별도직군)의 값을 읽어서
                target_val = self.cell_value(data_last_row, c)
                # '계' 행의 아이템에 입력
                sum_item = self.table.item(sum_row, c)
                if sum_item:
                    sum_item.setData(Qt.EditRole, round(target_val, 2))

        except Exception as e:
            print(f"S6 Calc Error: {e}")
        finally:
            self.table.blockSignals(False)




    def cell_value(self, row, col):
        """테이블 아이템의 텍스트를 float으로 안전하게 변환"""
        item = self.table.item(row, col)
        if item and item.text().strip():
            try:
                # 콤마 제거 후 숫자로 변환
                return float(item.text().replace(',', ''))
            except ValueError:
                return 0.0
        return 0.0















    def sync_from_s5(self, s5_data):
        """
        S5에서 온 데이터 크기에 맞춰 자동으로 상위 직급 차감 로직을 수행합니다.
        (데이터가 몇 행이든 상관없이 순차적으로 차감하며 독립 계산)
        """
        if not s5_data:
            return

        self.table.blockSignals(True)
        
        try:
            # 1. S5에서 넘어온 데이터의 실제 행/열 수 파악
            data_rows = len(s5_data)
            data_cols = len(s5_data[0]) if data_rows > 0 else 0

            # 2. 월별 루프 (컬럼)
            for m in range(data_cols):
                target_col = 2 + m
                previous_raw_val = 0.0  # 매 월 시작 시 상위 직급 값 0으로 리셋
                
                # 3. 직급별 루프 (행) - 넘어온 데이터 행 수만큼만 정확히 반복
                for r in range(data_rows):
                    # 현재 직급의 S5 원본 누적차
                    current_raw_val = float(s5_data[r][m])
                    
                    # [로직] 현재 누적차 - 상위 누적차
                    # 예: 3급(-3)이 3으로 왔을 때 3-0=3, 4급(-2)이 2로 왔을 때 2-3=-1
                    calculated_val = current_raw_val - previous_raw_val

                    rank_name = self.ranks[r] 
                    if rank_name in ["5급", "6급", "연구직"]:
                        calculated_val = 0
                    
                    # 테이블의 해당 셀에 값 입력
                    it = self.table.item(r, target_col)
                    if it:
                        it.setData(Qt.EditRole, round(calculated_val, 2))

                    
                    # 현재 원본값을 다음 행 계산을 위한 '이전값'으로 저장
                    previous_raw_val = current_raw_val

            # 테이블 전체 합계(계) 갱신
            self.calculate_s6()

        except Exception as e:
            print(f"S6 데이터 동기화 오류: {e}")
        finally:
            self.table.blockSignals(False)

        # S7 연계를 위한 트리거
        first_item = self.table.item(0, 2)
        if first_item:
            self.table.itemChanged.emit(first_item)



























    def get_data_to7(self):
        """S7로 데이터를 보낼 때: 0~7행(데이터 영역)만 추출"""
        # rank_count=9 기준, 데이터는 8행이므로 rank_count-1
        num_data_rows = rank_count - 1 
        data = [[0.0 for _ in range(12)] for _ in range(num_data_rows)]
        
        for m in range(12):
            col_idx = 2 + m  # 1월(2) ~ 12월(13)
            for r in range(num_data_rows):
                # 기존 cell_value 함수를 사용하여 0~7행 값 수집
                data[r][m] = self.cell_value(r, col_idx)
        return data




        

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        # 행 인덱스 동적 설정
        sum_row_idx = rank_count - 1      # 8행 (계)
        separator_idx = rank_count        # 9행 (구분선)
        
        lines = []

        # 1. 헤더 복사 (선택 영역에 첫 행이 포함될 때)
        if min_r == 0:
            header_row = []
            for c in range(min_c, max_c + 1):
                h_item = self.table.horizontalHeaderItem(c)
                header_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(header_row))
        
        # 2. 데이터행 복사
        for r in range(min_r, max_r + 1):
            # 구분선(9행)인 경우 빈 줄 처리
            if r == separator_idx:
                lines.append("\t".join([""] * (max_c - min_c + 1)))
                continue
                
            row_data = []
            for c in range(min_c, max_c + 1):
                # '계' 행(8행) 복사 시 엑셀 SUM 수식으로 변환
                if r == sum_row_idx and c >= 2:
                    col_letter = chr(65 + c) # A, B, C...
                    # 엑셀 기준: 헤더가 1행이므로 데이터는 2행부터 rank_count행까지입니다.
                    # 예: rank_count가 9라면 =SUM(C2:C9) -> 10행이 합계가 됨
                    excel_data_end = rank_count
                    row_data.append(f"=SUM({col_letter}2:{col_letter}{excel_data_end})")
                
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    # 엑셀 오작동 방지용 접두사
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))
        





    def paste_selection(self):
        txt = QApplication.clipboard().text(); curr = self.table.currentItem()
        if not txt or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(txt.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable): it.setText(val.strip())
        self.table.blockSignals(False); self.calculate_s6(curr)



    def show_context_menu(self, pos):
        menu = QMenu(); cp = menu.addAction("복사 (Ctrl+C)"); ps = menu.addAction("붙여넣기 (Ctrl+V)")
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if act == cp: self.copy_selection()
        elif act == ps: self.paste_selection()


    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self.copy_selection()
        elif event.matches(QKeySequence.Paste):
            self.paste_selection()
        else:
            super().keyPressEvent(event)
