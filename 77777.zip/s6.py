from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence
import json
import os

rank_count = 8

class S6RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 테이블 자체의 키 이벤트(평소 상태)를 감시하기 위해 필터 설치
        if parent:
            parent.installEventFilter(self)
            
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 입력 중(에디터 활성화)일 때 키 이벤트를 가로채기 위해 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택 유지)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # 데이터를 모델에 저장하기 위해 setCurrentIndex 사용
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나, 커서가 텍스트 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나, 커서가 텍스트 시작일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 단순 인덱스 변경만 수행"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

                


class S6ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.ForegroundRole:
            val = super().data(Qt.EditRole)
            try:
                if val is not None and float(str(val).replace(',', '')) < 0:
                    return QColor(Qt.red)
            except:
                pass
            return super().data(role) # 음수가 아니면 기본 색상


        
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "":
                return ""
            try:
                num = float(str(val).replace(',', ''))
                return format(num, ",.2f")   # 🔥 항상 소수 2자리
            except:
                return val
        return super().data(role)


class Sheet6Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.main_window = parent

        global rank_count
        rank_count = len(self.main_window.list_title_06)
        ranks = self.main_window.list_title_06

        global combo_rank
        
        ranks = self.main_window.list_title_06
        cnt_1 = 0
        for item in ranks:
            if item.startswith('1'):
                break
            cnt_1 += 1

        combo_rank = cnt_1 + 4


        
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        # 구성: 데이터(7행) + 구분선(1행) + 주석(1행) = 총 9행
        # 열 구성: 구분(0), 직급(1), 1~12월(2~13) = 총 14열
        self.table = QTableWidget(rank_count+1, 14)
        
        months = [f"{i}월" for i in range(1, 13)]
        headers = ["구분", "직급"] + months
        self.table.setHorizontalHeaderLabels(headers)

        # [복구] 우클릭 메뉴 정책 설정 및 연결
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.verticalHeader().setFixedWidth(25)


        




        # --- 제목, 하한선 문구, 콤보박스 레이아웃 ---
        title_hbox = QHBoxLayout()
        title_hbox.setContentsMargins(5, 5, 5, 5) 
        
        # 1. 메인 제목
        title_label = QLabel("(3-3) 나. 근속승진")
        title_label.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        title_hbox.addWidget(title_label)
        
        # 제목과 문구 사이 간격 (50px)
        title_hbox.addSpacing(50)

        layout.addLayout(title_hbox)
        


        # [수정] 정규식 경고 해결 (r'\d') 및 직급 필터링 로직 강화
        import re
        all_ranks = list(self.main_window.list_title_05)

        # 숫자가 포함된 직급(1급, 2급...)만 추출
        numeric_ranks = [r for r in all_ranks if re.search(r'\d', r)]
        
        if len(numeric_ranks) >= 2:
            ranks_subset = numeric_ranks[2:] if len(numeric_ranks) > 2 else [numeric_ranks[2]]
        else:
            # 숫자 직급이 너무 적으면 그냥 있는 거라도 보여줌
            ranks_subset = numeric_ranks

        # 3. 슬림한 콤보박스 설정
        self.combo = QComboBox()
        self.combo.addItems(ranks_subset)
        self.combo.setFixedWidth(51)






        saved_idx = self.load_combo_index()
        
        if saved_idx < self.combo.count():
            self.combo.setCurrentIndex(saved_idx)

        self.combo.hide()



        '''        
        title_hbox.addWidget(self.combo)
        limit_txt_label = QLabel("부터 근속승진 가능합니다.")
        limit_txt_label.setFont(QFont("Malgun Gothic", 10))
        title_hbox.addWidget(limit_txt_label)  
        # 오른쪽 여백을 밀어주어 위치 고정
        title_hbox.addStretch(1) 
        layout.addLayout(title_hbox)
        '''


        global combo_rank


        # import re
        # combo_rank = int(re.findall(r'\d+', self.combo.currentText())[0])
        combo_rank = int(numeric_ranks[len(numeric_ranks)-1][0])


        self.combo.currentIndexChanged.connect(self.on_combo_changed)

      

        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0; font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertical { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
        """)

        self.delegate = S6RightAlignedDelegate(self.table)
        for i in range(2, 14): self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        # 너비 설정
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 70)

        self.table.itemChanged.connect(self.calculate_s6)
        layout.addWidget(self.table)




            

    def setup_content(self):
        self.table.blockSignals(True)
        
        # 1. 직급 리스트 정의 (rank_count=9 기준: 0~7행 데이터, 8행 계)
        # self.ranks = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직", "계"]
        self.ranks = list(self.main_window.list_title_06)
        
        # 2. 행 인덱스 동적 설정
        sum_row_idx = rank_count - 1      # 8행 (계)
        separator_idx = rank_count        # 9행 (구분선)
        comment_idx = rank_count + 1      # 10행 (주석)
        
        # 전체 행 수 설정 (데이터+합계 9행 + 구분선 1행 + 주석 1행 = 총 11행)
        self.table.setRowCount(comment_idx + 1)
        
        comment_text = (
            "\n * 직급별 누적차가 음수인 직급의 경우 해당 누적차(양수)를 기재하며, 그 이하 직급의 경우에는 해당 누적차(음수)를 기재함.\n\n"
            "   예시 1) 특정월의 4직급의 누적차가 –2인 경우 해당월의 4직급 란에는 2를 기재하고, 5급직 란에는 –2를 기재함.\n"
            "   예시 2) 특정월의 3직급의 누적차가 –3이고, 4직급의 누적차가 –2인 경우\n              3직급 란에는 3을 기재하고, 4직급 란에 -1."
        )

        
        # for r in range(self.table.rowCount()):

        for r in range(rank_count):  
            for c in range(14):
                if r == separator_idx: # --- 구분선 영역 ---
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags)
                    item.setBackground(Qt.white)
                    
                elif r == comment_idx: # --- 주석 영역 ---
                    item = QTableWidgetItem(comment_text if c == 0 else "")
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    # 주석 폰트 설정 (필요시)
                    if c == 0:
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignTop)
                
                else: # --- 데이터 및 합계 영역 (0~8행) ---
                    item = S6ThousandSeparatorItem("0")
                    # 정렬: 구분/직급(중앙), 데이터(우측)
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)
                    
                    # (1) S5 연동 데이터 영역 (0~7행, 2~13열) -> 노란색, 수정불가
                    if 2 <= c <= 13 and 0 <= r < sum_row_idx:
                        item.setBackground(QColor(255, 255, 225))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    
                    # (2) '계' 행 (8행) -> 하늘색, 수정불가, 굵게
                    elif r == sum_row_idx:
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if c >= 2: # 숫자 부분만 굵게
                            font = item.font()
                            font.setBold(True)
                            item.setFont(font)
                    
                    # (3) 직급열 (1열) -> 하늘색
                    if c == 1:
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)                        
                        if r < len(self.ranks):
                            item.setText(self.ranks[r])
                    
                    # (4) 구분열 (0열) -> 회색조
                    if c == 0:
                        item.setBackground(QColor(245, 245, 245))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r == 0:
                            item.setText("당년도")

                self.table.setItem(r, c, item)

        # 3. 테이블 레이아웃 마무리 (병합 등)
        # 당년도(0열)를 데이터+합계 행(0~8행)만큼 병합
        self.table.setSpan(0, 0, rank_count, 1) 
        # 주석 행 병합
        self.table.setSpan(comment_idx, 0, 1, 14)
        
        # 행 높이 조절
        self.table.setRowHeight(separator_idx, 10)  # 구분선은 얇게
        self.table.setRowHeight(comment_idx, 100)   # 주석은 넓게
        
        self.table.blockSignals(False)

        










    def calculate_s6(self, item=None):

        import math

        for c in range(2, 14):
            total_sum = 0
            for r in range(rank_count-1):
                total_sum += self.cell_value(r, c)

            total_sum_item = self.table.item(rank_count-1, c)
            if total_sum_item:
                total_sum_item.setData(Qt.EditRole, round(total_sum + math.copysign(0.00001, total_sum), 2))
                        
                font = total_sum_item.font()
                font.setBold(True)
                total_sum_item.setFont(font)

        return



    

        global combo_rank
        
        # 행 인덱스 동적 설정
        sum_row = rank_count - 1      # 8행 (계)
        data_last_row = rank_count - 2 # 7행 (별도직군)

        if item is None:
            # 전체 계산 시 (초기화 또는 데이터 로드 시)
            cols = range(2, 14)
        else:
            row, col = item.row(), item.column()
            # 1. 계산 범위 체크: 0~7행 데이터 수정 시에만 작동
            # 2. '계' 행(8행)이나 그 아래(구분선, 주석) 수정 시에는 무시
            if col < 2 or col > 13 or row >= sum_row: 
                return
            cols = [col]

        self.table.blockSignals(True)


        ranks = self.main_window.list_title_05
        cnt_g = sum(1 for rank in ranks if rank.endswith("급"))

        cnt_1 = 0
        for item in ranks:
            if item.startswith('1'):
                break
            cnt_1 += 1


        try:
            for c in cols:
                v_sum = 0.0


                # for r in range(combo_rank-1):
                for r in range(cnt_1, combo_rank-1):
                    v_sum += self.cell_value(r, c)
                sum_item = self.table.item(combo_rank-1, c)
                if sum_item:
                    sum_item.setData(Qt.EditRole, round(v_sum + math.copysign(0.00001, v_sum), 2)*(-1))




                for r in range(combo_rank, cnt_g):                    
                    normal_item = self.table.item(r, c)
                    normal_item.setData(Qt.EditRole, 0)




                total_sum = 0
                for r in range(rank_count-1):


                    total_sum += self.cell_value(r, c)

                total_sum_item = self.table.item(sum_row, c)
                if total_sum_item:
                    total_sum_item.setData(Qt.EditRole, round(total_sum + math.copysign(0.00001, total_sum), 2))
                    
                    font = total_sum_item.font()
                    font.setBold(True)
                    total_sum_item.setFont(font)



        except Exception as e:
            print(f"S6 Calc Error: {e}")
        finally:
            self.table.blockSignals(False)




    def cell_value(self, row, col):
        """테이블 아이템의 텍스트를 float으로 안전하게 변환"""
        item = self.table.item(row, col)
        if item and item.text().strip():
            try:
                # 콤마 제거 후 숫자로 변환
                return float(item.text().replace(',', ''))
            except ValueError:
                return 0.0
        return 0.0















    def sync_from_s5(self, s5_data):
        
        if not s5_data:
            return

        self.table.blockSignals(True)

        import re

        
        try:

            data_rows = len(s5_data)   # (3-3)가. 누적차 행 수
            data_cols = len(s5_data[0]) if data_rows > 0 else 0      # (3-3)가. 누적차 열 수

            ranks = self.main_window.list_title_06
            cnt_g = sum(1 for rank in ranks if rank.endswith("급"))    # 1급~6급의 행 수 => 6

            global combo_rank
            combo_rank = int(re.findall(r'\d+', self.combo.currentText())[0])   # 콤보박스 선택 값 (심평원은 3급이므로 3)

            cnt_1 = 0     # 심평원 이외 기관은 1급부터 시작하므로 1급 INDEX 는 0
            for item in ranks:
                if item.startswith('1'):
                    break
                cnt_1 += 1    # 심평원은 1급 위에 위원들이 있으므로 1급 INDEX 는 4

            combo_rank += cnt_1   # 콤보 3급의 인덱스: 3(콤보값) + 4(위원들) = 7

            import math
            
            for m in range(2, data_cols+2):   # 1월부터 12월까지   (1월 앞에 당년도, 직급 열이 있으므로 1월 m 인덱스는 2부터)

                sum_0 = 0.0

                if s5_data[0][m-2] < 0:
                    self.table.item(0, m).setData(Qt.EditRole, round(s5_data[0][m-2]*(-1), 2))
                else:
                    self.table.item(0, m).setData(Qt.EditRole, round(0, 2))



                # s5_data[r-1][m-2]: 바로위 누적차
                # s5_data[r][m-2]: 현직급 누적차

                for r in range(1, combo_rank):   # 소장 ~ 6급
                    if s5_data[r-1][m-2] < 0 and s5_data[r][m-2] < 0:
                        self.table.item(r, m).setData(Qt.EditRole, round(s5_data[r-1][m-2] - s5_data[r][m-2], 2))
                    else:
                        if s5_data[r-1][m-2] < 0 and s5_data[r][m-2] >= 0:
                            self.table.item(r, m).setData(Qt.EditRole, round(s5_data[r-1][m-2], 2))
                        else:
                            if s5_data[r-1][m-2] >= 0 and s5_data[r][m-2] < 0:
                                self.table.item(r, m).setData(Qt.EditRole, round(s5_data[r][m-2] * (-1), 2))
                            else:
                                self.table.item(r, m).setData(Qt.EditRole, round(0, 2))
                            

                for r in range(combo_rank, cnt_1 + cnt_g):   # combo+1~n급
                    self.table.item(r, m).setData(Qt.EditRole, round(0, 2))

                for r in range(cnt_1 + cnt_g, data_rows):   # 별도직군
                    self.table.item(r, m).setData(Qt.EditRole, str(float(s5_data[r][m-2] * (-1))) if s5_data[r][m-2] < 0 else '0.00'  )








            self.calculate_s6()



        except Exception as e:
            print(f"S6 데이터 동기화 오류: {e}")
        finally:
            self.table.blockSignals(False)

        # S7 연계를 위한 트리거
        first_item = self.table.item(0, 2)
        if first_item:
            self.table.itemChanged.emit(first_item)




























    def get_data_to7(self):
        """S7로 데이터를 보낼 때: 0~7행(데이터 영역)만 추출"""
        # rank_count=9 기준, 데이터는 8행이므로 rank_count-1
        num_data_rows = rank_count - 1 
        data = [[0.0 for _ in range(12)] for _ in range(num_data_rows)]
        
        for m in range(12):
            col_idx = 2 + m  # 1월(2) ~ 12월(13)
            for r in range(num_data_rows):
                # 기존 cell_value 함수를 사용하여 0~7행 값 수집
                data[r][m] = self.cell_value(r, col_idx)
        return data


    def on_combo_changed(self):
        global combo_rank
        import re


        ranks = self.main_window.list_title_05

        cnt_1 = 0
        for item in ranks:
            if item.startswith('1'):
                break
            cnt_1 += 1



        
        # 1. 파일에 현재 선택된 인덱스 저장
        self.save_combo_index(self.combo.currentIndex())
        
        # 2. 전역 변수 업데이트
        try:
            combo_rank = int(re.findall(r'\d+', self.combo.currentText())[0]) # + cnt_1
        except:
            combo_rank = 4 + cnt_1 # 예외 발생 시 기본값

        # 3. S5 연동 및 계산 (기존 로직)
        s5 = self.main_window.s5
        if s5:
            s5.calculate_s5(s5.table.item(0, 2))
            self.sync_from_s5(s5.get_data_for_s6())

























    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        # 행 인덱스 동적 설정
        sum_row_idx = rank_count - 1      # 8행 (계)
        separator_idx = rank_count        # 9행 (구분선)
        
        lines = []

        # 1. 헤더 복사 (선택 영역에 첫 행이 포함될 때)
        if min_r == 0:
            header_row = []
            for c in range(min_c, max_c + 1):
                h_item = self.table.horizontalHeaderItem(c)
                header_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(header_row))
        
        # 2. 데이터행 복사
        for r in range(min_r, max_r + 1):
            # 구분선(9행)인 경우 빈 줄 처리
            if r == separator_idx:
                lines.append("\t".join([""] * (max_c - min_c + 1)))
                continue
                
            row_data = []
            for c in range(min_c, max_c + 1):
                # '계' 행(8행) 복사 시 엑셀 SUM 수식으로 변환
                if r == sum_row_idx and c >= 2:
                    col_letter = chr(65 + c) # A, B, C...
                    # 엑셀 기준: 헤더가 1행이므로 데이터는 2행부터 rank_count행까지입니다.
                    # 예: rank_count가 9라면 =SUM(C2:C9) -> 10행이 합계가 됨
                    excel_data_end = rank_count
                    row_data.append(f"=SUM({col_letter}2:{col_letter}{excel_data_end})")
                
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    # 엑셀 오작동 방지용 접두사
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))
        
    def paste_selection(self):
        txt = QApplication.clipboard().text(); curr = self.table.currentItem()
        if not txt or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(txt.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable): it.setText(val.strip())
        self.table.blockSignals(False); self.calculate_s6(curr)


    def save_combo_index(self, index):

        if not os.path.exists('run'):
            os.makedirs('run')
        
        """콤보박스 인덱스를 파일에 저장"""
        data = {'s6_combo_index': index}
        with open('run/config_s6.json', 'w', encoding='utf-8') as f:
            json.dump(data, f)

    def load_combo_index(self):
        """파일에서 인덱스를 불러옴 (파일이 없으면 0 반환)"""
        if os.path.exists('run/config_s6.json'):
            try:
                with open('run/config_s6.json', 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('s6_combo_index', 0)
            except:
                return 0
        return 0







    def show_context_menu(self, pos):
        menu = QMenu(); cp = menu.addAction("복사 (Ctrl+C)"); ps = menu.addAction("붙여넣기 (Ctrl+V)")
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if act == cp: self.copy_selection()
        elif act == ps: self.paste_selection()


    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self.copy_selection()
        elif event.matches(QKeySequence.Paste):
            self.paste_selection()
        else:
            super().keyPressEvent(event)
