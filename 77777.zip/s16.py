from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont

# [1] 천단위 콤마 및 소수점 처리 아이템
class S16ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val or val == "" or val == "0": return "0"
            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                # 최종 지표 행(41)은 소수점 2자리 표시
                if self.row() == 41:
                    return format(num, ",.2f")
                return format(int(num), ",")
            except: return val
        return super().data(role)

# [2] 실시간 입력 델리게이트 (자동 계산 행 보호)
class S16RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        # 보호할 행들 (소계 1~11번, 합계 ▶, 결과 ■, 지표 ◎)
        # 0(1번소계), 4(계), 5(2번소계), 8(계), 9(3번소계), 12(계), 
        # 16(7번소계), 21(계), 22(8번소계), 25(계), 26(9번소계), 29(계), 
        # 30(10번소계), 33(계), 34(11번소계), 37(계), 39(일반관리비), 41(지표)
        protected_rows = [0, 4, 5, 8, 9, 12, 16, 21, 22, 25, 26, 29, 30, 33, 34, 37, 39, 41]
        
        # 13(4번), 14(5번), 15(6번) 행은 하위 항목이 없으므로 입력 허용 (15번 시트의 1, 7번과 동일 로직)
        if index.column() == 0 or index.row() in protected_rows:
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet16Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.header_gray = QColor(240, 240, 240)
        self.very_light_gray = QColor(252, 252, 252)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        title = QLabel("hwp 30페이지: (6) 일반관리비 관리 지표의 점수계산을 위한 Template(2)_준정부기관")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(42, 4)
        self.table.setHorizontalHeaderLabels(["구분", "2025", "2024", "2023"])
        self.table.setColumnWidth(0, 450)
        for i in range(1, 4): self.table.setColumnWidth(i, 130)

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section { background-color: #f4f4f4; font-weight: bold; border: 1px solid #d0d0d0; }
        """)

        self.delegate = S16RightAlignedDelegate(self.table)
        for i in range(1, 4): self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        self.table.itemClicked.connect(self.handle_help_popup)
        self.table.itemChanged.connect(self.calculate_totals)
        layout.addWidget(self.table)

        # 하단 주석 보존
        footer_note = QLabel(
            "<font color='#555555'>"
            "<b>&lt;주1&gt;</b> 인건비집계를 위한 template상의 (가)에 기입된 금액을 옮겨 적음 (hwp 7페이지)<br>"
            "<b>&lt;주3&gt;</b> 잡급, 무기계약직의 일반급여 ㈆과 무기계약직급여 ㈈을 합한 금액 (hwp 7페이지)"
            "</font>"
        )
        footer_note.setStyleSheet("margin-top: 5px; padding: 5px; background-color: #fcfcfc; border: 1px solid #eeeeee;")
        layout.addWidget(footer_note)

    def setup_content(self):
        self.table.blockSignals(True)
        rows = [
            "1. 사업비와 판관비(또는 경비)", "  a. 직접사업비<주1>", "  b. 사업비성 경비<주1>", "  c. 판관비(또는 경비)", "▶ 사업비와 판관비 계: (A) = a+b+c",
            "2. 사업비 중 제외항목 <주2>", "  d. 직접사업비", "  e. 사업비성 경비", "▶ 제외항목 총계: (B) = d+e",
            "3. 비정규직 인건비 등 <주3>", "  f. 비정규직 인건비 등 총계", "  g. 비정규직 특수건강진단비", "▶ 차감 비정규직 인건비 등: (C) = f-g",
            "4. 비상임이사 인건비(D)<주4>", "5. 인상률 제외 인건비(E) <주5>", "6. 사내근로복지기금 집행액(F) <주6>",
            "7. 감가상각비", "  h. 사업비로 처리된 유형자산 감가상각비", "  i. 사업비로 처리된 무형자산 감가상각비", "  j. 판관비로 처리된 유형자산 감가상각비", "  k. 판관비로 처리된 무형자산 감가상각비", "▶ 감가상각비 총계: (G) = h+i+j+k",
            "8. 교육훈련비 <주7>", "  l. 사업비로 처리된 교육훈련비", "  m. 판관비로 처리된 교육훈련비", "▶ 교육훈련비 총계: (H) = l+m",
            "9. 연구비 및 경상개발비 <주7>", "  n. 사업비로 처리된 연구비", "  o. 판관비로 처리된 연구비", "▶ 연구비 총계: (I) = n+o",
            "10. 세금과공과 <주7, 8>", "  p. 사업비 세금과공과", "  q. 판관비 세금과공과", "▶ 세금과공과 총계: (J) = p+q",
            "11. 수선유지비 <주7, 9>", "  r. 사업비 수선유지비", "  s. 판관비 수선유지비", "▶ 수선유지비 총계: (K) = r+s",
            "12. 직장어린이집 설치비용(L) <주7, 10>", "■ 일반관리비: (M)=(A)-(B)+(C)+(D)+(E)+(F)-(G)-(H)-(I)-(J)-(K)-(L)",
            "매출액 (N)", "◎ 일반관리비 관리 지표 = (M)/(N)"
        ]

        for r, text in enumerate(rows):
            # [A] 하위 항목이 있는 소계(1,2,3,7,8,9,10,11) 및 특수기호 행 판별
            is_subtotal = (any(text.strip().startswith(f"{i}.") for i in [1, 2, 3, 7, 8, 9, 10, 11]) or 
                           any(m in text for m in ["▶", "■", "◎"]))
            
            # [B] 단독 대분류(4, 5, 6, 12번) 판별 -> 제목만 굵게 하고 입력은 열어둠
            is_bold_only = any(text.strip().startswith(f"{i}.") for i in [4, 5, 6, 12])

            # 구분열(0열) 아이템 설정
            item_a = QTableWidgetItem(text)
            item_a.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            
            # 굵은 글씨 적용 (소계 및 단독 대분류 공통)
            if is_subtotal or is_bold_only:
                font = item_a.font()
                font.setBold(True)
                item_a.setFont(font)
                item_a.setBackground(self.header_gray) # 제목칸은 회색
            else:
                item_a.setBackground(self.very_light_gray)
            self.table.setItem(r, 0, item_a)

            # 데이터열(1~3열) 아이템 설정
            for c in range(1, 4):
                item = S16ThousandSeparatorItem("0")
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                
                if is_subtotal:
                    # 소계는 파란색 배경 + 입력 금지
                    item.setBackground(self.base_sky_blue)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    # 단독 대분류(4,5,6,12) 및 일반 항목은 흰색 배경 + 입력 허용
                    item.setBackground(QColor(255, 255, 255))
                self.table.setItem(r, c, item)
        self.table.blockSignals(False)

        

    def calculate_totals(self, item):
        col = item.column()
        if col == 0: return  # 구분열은 계산 안 함
        self.table.blockSignals(True)
        try:
            def gv(r): # 값 가져오기 편의 함수
                it = self.table.item(r, col)
                return float(it.text().replace(',', '')) if it and it.text() else 0.0
            def sv(r, val): # 값 세팅하기 편의 함수
                self.table.item(r, col).setText(str(int(val)))

            # --- 각 대분류 소계 및 ▶ 합계 행 계산 ---
            vA = gv(1)+gv(2)+gv(3); sv(0, vA); sv(4, vA)      # 1번 소계/합계
            vB = gv(6)+gv(7); sv(5, vB); sv(8, vB)            # 2번 소계/합계
            vC = gv(10)-gv(11); sv(9, vC); sv(12, vC)         # 3번 소계/합계
            vG = gv(17)+gv(18)+gv(19)+gv(20); sv(16, vG); sv(21, vG) # 7번 소계/합계
            vH = gv(23)+gv(24); sv(22, vH); sv(25, vH)        # 8번 소계/합계
            vI = gv(27)+gv(28); sv(26, vI); sv(29, vI)        # 9번 소계/합계
            vJ = gv(31)+gv(32); sv(30, vJ); sv(33, vJ)        # 10번 소계/합계
            vK = gv(35)+gv(36); sv(34, vK); sv(37, vK)        # 11번 소계/합계

            # --- 최종 일반관리비 (M) 계산 ---
            # 공식: (A)-(B)+(C)+(D)+(E)+(F)-(G)-(H)-(I)-(J)-(K)-(L)
            # D: 13행, E: 14행, F: 15행, L: 38행 (모두 사용자가 직접 입력한 값)
            vM = (vA - vB + vC + 
                  gv(13) + gv(14) + gv(15) - 
                  vG - vH - vI - vJ - vK - gv(38))
            sv(39, vM) # ■ 일반관리비 행 업데이트
            
            # --- ◎ 지표 계산 ---
            vN = gv(40) # 매출액
            if vN != 0:
                # 지표 행(41)에 결과값 세팅 (천단위 콤마 및 소수점은 Item에서 처리)
                self.table.item(41, col).setText(str(vM / vN))
            else:
                self.table.item(41, col).setText("0")
                
        except Exception as e:
            print(f"Error in calculation: {e}")
        finally:
            self.table.blockSignals(False)




            
    # --- 기존 기능 보존 (복사/붙여넣기/도움말) ---
    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사")
        paste_action = menu.addAction("붙여넣기")
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action: self.copy_selection()
        elif action == paste_action: self.paste_selection()

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []
        for r in range(min_r, max_r + 1):
            row_data = [self.table.item(r, c).text() if self.table.item(r, c) else "" for c in range(min_c, max_c + 1)]
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        clipboard = QApplication.clipboard().text()
        if not clipboard: return
        rows = clipboard.split('\n')
        curr = self.table.currentItem()
        if not curr: return
        self.table.blockSignals(True)
        protected_rows = [4, 8, 12, 21, 25, 29, 33, 37, 39, 41]
        for i, row_text in enumerate(rows):
            if not row_text.strip(): continue
            cols = row_text.split('\t')
            for j, col_text in enumerate(cols):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    if c >= 1 and r not in protected_rows:
                        item = self.table.item(r, c)
                        if item: item.setData(Qt.EditRole, col_text.strip().replace(',', ''))
        self.table.blockSignals(False)
        self.calculate_totals(curr)

    def handle_help_popup(self, item):
        if item.column() != 0: return
        helps = {
            1: "<b><주1></b> 인건비집계를 위한 template상의 (가)에 기입된 금액을 옮겨 적음.",
            5: "<b><주2></b> 인건비집계를 위한 template상의 (다)에 기입된 금액을 옮겨 적음.",
            9: "<b><주3></b> 잡급 및 무기계약직 일반급여와 무기계약직급여의 합.",
            13: "<b><주4></b> 비상임이사 인건비 금액을 기입.",
            14: "<b><주5></b> 인상률 산정에서 제외되는 인건비 금액 기입."
        }
        row = item.row()
        if row in helps:
            QMessageBox.information(self, "항목 상세 설명", f"<b>[{item.text()}]</b><br><br>{helps[row]}")

    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier:
            if event.key() == Qt.Key_C: self.copy_selection()
            elif event.key() == Qt.Key_V: self.paste_selection()
        else: super().keyPressEvent(event)
