from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QPen
import re

rank_count = 8

class S14ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or val == "" or val == "n/a": 
                return val
            
            try:
                # 콤마 제거 후 숫자로 변환
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                
                # [수정된 부분] 아이템 자체의 column() 메서드를 사용합니다.
                col = self.column()
                
                # 인원 관련 열 (1:전년평균, 2:당년평균, 3:증감)
                if col in [1, 2, 3]:
                    return format(num, ",.1f")  # 1 -> "1.0", 0 -> "0.0"
                
                # 그 외 열(단가, 효과 등)은 정수로 표시
                return format(int(num), ",")
                
            except (ValueError, TypeError):
                return val
                
        return super().data(role)

class Sheet14Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent

        global rank_count
        rank_count = len(self.main_window.list_title_14)


        
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        title = QLabel("(3-5) 라. 별도직군의 승진시기 차이에 따른 인건비 효과")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(rank_count + 2, 8)
        
        headers = [
            "직급", 
            "전년도\n미승진자\n평균인원(A)", "당년도\n미승진자\n평균인원(B)", "증감\n(C)=(B)-(A)",
            "전년도\n승진전\n평균단가(D)", "전년도\n승진후\n평균단가(E)", "증감\n(F)=(E)-(D)",
            "인건비 효과\n(C) × (F)"
        ]
        self.table.setHorizontalHeaderLabels(headers)
        self.table.horizontalHeader().setFixedHeight(70)
        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.verticalHeader().setFixedWidth(25)

        self.setup_content()
        
        self.table.setColumnWidth(0, 70)
        for i in range(1, 7): self.table.setColumnWidth(i, 95)
        self.table.setColumnWidth(7, 130)

        self.table.itemChanged.connect(self.calculate_s14)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        layout.addWidget(self.table)



        

    def setup_content(self):
        self.table.blockSignals(True)
        ranks = self.main_window.list_title_14 
        
        # 색상 정의
        self.base_yellow = QColor(255, 255, 225) # 외부 데이터 유입 (A, B, D, E)
        
        for r in range(rank_count + 2):
            for c in range(8):
                if r < rank_count:
                    default_val = "0.0" if c in [1, 2, 3] else "0"
                    item = S14ThousandSeparatorItem(default_val) if c > 0 else QTableWidgetItem(ranks[r])
                    
                    # [권한 및 색상 설정]
                    # 1. 하늘색: 직급(0), 자동계산(3, 6, 7), 합계행(rank_count-1)
                    if c == 0 or c in [3, 6, 7] or r == rank_count - 1:
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 입력 불가
                        if r == rank_count - 1:
                            f = item.font(); f.setBold(True); item.setFont(f)
                            
                    # 2. 노란색: 외부 데이터 수신 열 (1, 2, 4, 5)
                    elif c in [1, 2, 4, 5]:
                        item.setBackground(self.base_yellow)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 입력 불가 (잠금)
                    
                    # 정렬 설정
                    item.setTextAlignment(Qt.AlignCenter if c == 0 else Qt.AlignRight | Qt.AlignVCenter)
                
                else:
                    # 빈 줄 및 주석 영역
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags)
                    item.setBackground(Qt.white)
                
                self.table.setItem(r, c, item)

        self.table.setSpan(rank_count, 0, 1, 8)
        self.table.setSpan(rank_count + 1, 0, 1, 8)
        self.table.blockSignals(False)

                                                   

    def s_round(self, value, digits=1):
        """Decimal을 이용한 정확한 사사오입 함수"""
        from decimal import Decimal, ROUND_HALF_UP
        try:
            # 부동소수점 오차 방지를 위해 문자열로 변환 후 Decimal 처리
            d_val = Decimal(str(value))
            # digits만큼 소수점 포맷 생성 (예: 1 -> '0.1', 2 -> '0.01')
            exp = Decimal('1.' + '0' * digits).quantize(Decimal('1.' + '0' * digits)) # 지수 설정용
            # 실제로는 아래와 같이 간단히 처리 가능
            return float(d_val.quantize(Decimal(f"1.{'0' * digits}"), rounding=ROUND_HALF_UP))
        except:
            return value

    def calculate_s14(self, item=None):
        # [수정] 필터링 조건을 제거하거나 완화하여 외부 호출 시에도 무조건 계산되게 합니다.
        # if item: ... (기존의 리턴 조건 삭제)

        self.table.blockSignals(True)
        try:
            def gv(row, col):
                it = self.table.item(row, col)
                # 아이템이 없거나 텍스트가 비어있으면 0.0 반환
                if not it: return 0.0
                val_str = it.text().strip().replace(',', '')
                if not val_str or val_str == "n/a": return 0.0
                try: return float(val_str)
                except: return 0.0

            # 1. 모든 데이터 행(직급별 행) 가로 계산
            # '계' 행을 제외한 데이터 행만 순회 (rank_count-1까지)
            for r in range(rank_count - 1):
                # (C) 증감 = (B) - (A)
                vC = self.s_round(gv(r, 2) - gv(r, 1), 1)
                self.table.item(r, 3).setData(Qt.EditRole, f"{vC:.1f}")

                # (F) 단가 증감 = (E) - (D)
                vF = int(gv(r, 5) - gv(r, 4))
                self.table.item(r, 6).setData(Qt.EditRole, str(vF))

                # 인건비 효과 = (C) * (F)
                vEff = int(vC * vF)
                self.table.item(r, 7).setData(Qt.EditRole, str(vEff))

            # 2. 세로 합계 계산 (A~G열 전체)
            for col_sum in range(1, 8):
                total = sum(gv(i, col_sum) for i in range(rank_count - 1))
                
                target_item = self.table.item(rank_count - 1, col_sum)
                if not target_item: continue # 안전장치
                
                if col_sum in [1, 2, 3]: # 인원 관련 (A, B, C)
                    val = self.s_round(total, 1)
                    target_item.setData(Qt.EditRole, f"{val:.1f}")
                else: # 단가 및 효과
                    target_item.setData(Qt.EditRole, str(int(total)))
                
        except Exception as e:
            print(f"S14 계산 오류: {e}")
        finally:
            self.table.blockSignals(False)

    def get_from_s13(self, s13_avg_data):
        """
        S13에서 계산된 평균인원 데이터를 받아 (A), (B)열에 자동 입력
        s13_avg_data = {"prev": [값, 값...], "curr": [값, 값...]}
        """
        if not s13_avg_data: return
        
        self.table.blockSignals(True)
        try:
            prev_list = s13_avg_data.get("prev", [])
            curr_list = s13_avg_data.get("curr", [])
            
            for i in range(rank_count - 1):
                # 전년도 평균인원 (A) - 1열
                if i < len(prev_list):
                    val_p = self.s_round(prev_list[i], 1)
                    self.table.item(i, 2).setData(Qt.EditRole, f"{val_p:.1f}")
                
                # 당년도 평균인원 (B) - 2열
                if i < len(curr_list):
                    val_c = self.s_round(curr_list[i], 1)
                    self.table.item(i, 1).setData(Qt.EditRole, f"{val_c:.1f}")
            
        finally:
            self.table.blockSignals(False)
            self.calculate_s14() # 입력 후 전체 재계산


    def get_from_s8(self, s8_prices):
        """
        S8로부터 원 단위 단가를 받아 백만원 단위 정수로 자동 입력
        """
        if not s8_prices: return
        
        self.table.blockSignals(True)
        try:
            for i in range(rank_count - 1):
                # 1. 승진 후 평균단가 (E열: 5번)
                if i < len(s8_prices):
                    # 원 단위를 백만원 단위로 변환 후 반올림 (예: 7,523,404 -> 8)
                    price_after = round(s8_prices[i] / 1000000)
                    self.table.item(i, 5).setData(Qt.EditRole, str(int(price_after)))
                
                # 2. 승진 전 평균단가 (D열: 4번)
                if i + 1 < len(s8_prices):
                    price_before = round(s8_prices[i+1] / 1000000)
                    self.table.item(i, 4).setData(Qt.EditRole, str(int(price_before)))
                else:
                    self.table.item(i, 4).setData(Qt.EditRole, "0")
                    
        finally:
            self.table.blockSignals(False)
            self.calculate_s14()


















    def get_excel_col(self, n):
        res = ""; n += 1
        while n > 0: n, rem = divmod(n - 1, 26); res = chr(65 + rem) + res
        return res

    def copy_selection(self):
        ranges = self.table.selectedRanges()
        if not ranges: return
        r0, r1 = min(r.topRow() for r in ranges), max(r.bottomRow() for r in ranges)
        c0, c1 = min(r.leftColumn() for r in ranges), max(r.rightColumn() for r in ranges)
        lines = []

        # [1] 헤더 복사
        if r0 == 0:
            h_row = [self.table.horizontalHeaderItem(c).text().replace('\n', ' ') for c in range(c0, c1 + 1)]
            lines.append("\t".join(h_row))

        for r in range(r0, r1 + 1):
            # [2] 빈 줄(구분선) 건너뛰기 - rank_count + 1 위치
            if r == rank_count + 1: continue
            
            row_data = []
            # 엑셀 행 번호: 헤더가 1행이므로 실제 데이터는 r + 2 (단, r은 0부터 시작)
            xl_r = r + 2 
            
            for c in range(c0, c1 + 1):
                # [3] 주석 행 처리 (rank_count + 2)
                if r == rank_count + 2:
                    it = self.table.item(r, 0)
                    val = it.text().replace('\n', ' ') if it else ""
                    row_data.append(val if c == c0 else "")
                    continue

                # [4] 데이터 및 수식 처리
                it = self.table.item(r, c)
                val = it.text().replace(',', '').replace('\n', ' ') if it else ""
                
                # 가로 계산 수식 직결 (데이터 행 범위: r < rank_count)
                if r < rank_count:
                    if c == 3: val = f"={self.get_excel_col(2)}{xl_r}-{self.get_excel_col(1)}{xl_r}" # (C)=(B)-(A)
                    elif c == 6: val = f"={self.get_excel_col(5)}{xl_r}-{self.get_excel_col(4)}{xl_r}" # (F)=(E)-(D)
                    elif c == 7: val = f"={self.get_excel_col(3)}{xl_r}*{self.get_excel_col(6)}{xl_r}" # (C)*(F)
                
                # 세로 합계 수식 직결 (합계 행: r == rank_count)
                elif r == rank_count and c in [1, 2, 3, 7]:
                    col_let = self.get_excel_col(c)
                    # 합계 범위: 2행(시작)부터 rank_count+1행(끝)까지
                    val = f"=SUM({col_let}2:{col_let}{rank_count + 1})"
                
                row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))



    def paste_selection(self):
        clipboard = QApplication.clipboard().text().strip()
        if not clipboard: return
        
        rows = clipboard.split('\n')
        curr_r = self.table.currentRow()
        curr_c = self.table.currentColumn()
        
        self.table.blockSignals(True)
        for i, row_str in enumerate(rows):
            r = curr_r + i
            # rank_count(합계행) 이상으로는 붙여넣지 않음 (데이터 영역 보호)
            if r >= rank_count: break 
            
            cols = row_str.split('\t')
            for j, val in enumerate(cols):
                c = curr_c + j
                if c >= 8: break
                
                # 직급명(0)과 계산열(3, 6, 7)은 수동 입력 및 붙여넣기 금지
                if c in [0, 3, 6, 7]: continue
                
                clean_val = val.strip().replace(',', '')
                if clean_val:
                    try:
                        # 엑셀 수식(=SUM 등)이 포함되어 있으면 무시하고 숫자만 추출
                        if not clean_val.startswith('='):
                            self.table.item(r, c).setText(clean_val)
                    except: continue
        
        self.table.blockSignals(False)
        # 붙여넣기 완료 후 합계 자동 갱신 트리거
        self.calculate_s14(self.table.item(curr_r, 1) if self.table.item(curr_r, 1) else self.table.item(0, 1))




















    
    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사 (Ctrl+C)")
        paste_action = menu.addAction("붙여넣기 (Ctrl+V)")
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action: self.copy_selection()
        elif action == paste_action: self.paste_selection()
