from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QCursor, QPen


rank_count = 7


class S3SymbolDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        # 기본 내용(숫자/텍스트) 먼저 그리기
        super().paint(painter, option, index)
        
        painter.save()
        # 마지막 줄(8행), 마지막 열(5열)에만 "갑" 그리기
        if index.row() == rank_count and index.column() == 5:
            # 1. 펜 설정 (약간 더 진하게)
            painter.setPen(QPen(QColor(40, 40, 40))) 
            
            # 2. 폰트 설정 (기존 9pt에서 18pt로 2배 확대)
            font = painter.font()
            font.setFamily("맑은 고딕")
            font.setPointSize(15) 
            font.setBold(True) # 크기가 커지니 굵게 해야 더 잘 보입니다
            painter.setFont(font)
            
            # 3. 위치 조정 (adjusted: 왼쪽여백, 위쪽여백, 오른쪽여백, 아래쪽여백)
            # 위쪽 여백을 5 정도로 주어 너무 위로 붙지 않게 조절했습니다.
            painter.drawText(option.rect.adjusted(rank_count, -3, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(갑)")
            
        painter.restore()



class S3ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "":
                return "0.0" if self.column() in (1,2,3) else "0"

            try:
                num = float(str(val).replace(',', ''))

                # 0 처리
                if num == 0:
                    return "0.0" if self.column() in (1,2,3) else "0"

                # A,B,C : 소수 2자리
                if self.column() in (1,2,3):
                    return format(num, ",.1f")

                # D,E : 정수
                if self.column() in (4,5):
                    return format(int(num), ",")

            except:
                return str(val)

        return super().data(role)








    

# [2] 실시간 우측 정렬 및 포맷팅 델리게이트 (s3용 통합 버전)
class S3RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 생성 시 부모(TableWidget)에 이벤트 필터 설치 (평소 상태 감시)
        if parent:
            parent.installEventFilter(self)

    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        
        # 실시간 콤마 포맷팅 연결
        editor.textChanged.connect(lambda text: self.format_text(editor, text))
        
        # 입력 중(에디터 활성화)일 때 키 감시용 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택, 데이터 저장 보장)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # setCurrentIndex를 호출해야 작성 중인 데이터가 반영됩니다.
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나(테이블), 커서가 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나(테이블), 커서가 앞일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 인덱스만 변경 (자동 편집 제거)"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def format_text(self, editor, text):
        clean = text.replace(',', '')
        if not clean or clean == "-": return
        try:
            formatted = format(int(float(clean)), ",")
            if text != formatted:
                pos = editor.cursorPosition()
                old_len = len(text)
                editor.blockSignals(True)
                editor.setText(formatted)
                editor.setCursorPosition(pos + (len(formatted) - old_len))
                editor.blockSignals(False)
        except: pass

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

        







        
class Sheet3Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.very_light_gray = QColor(252, 252, 252)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        # title = QLabel("(3-1) 증원소요 인건비 계산")

        # layout.setSpacing(0)  # [추가] 위젯 사이의 간격을 0으로 설정하여 완전히 붙임
        title = QLabel()







        title.setContentsMargins(0, 0, 0, 0)  # 위젯 외부 여백 제거
        title.setFixedHeight(45)              # 필요시 높이 고정 (더 줄이려면 숫자 조절)

        # HTML 내용: cellspacing/cellpadding 0으로 테이블 전체 여백 제거

    
        title.setText(
            '<table width="100%" style="border:none;">'
            '  <tr>'
            '    <td align="left" style="border:none;" width="338"; cellspacing="0" cellpadding="0" margin:0; padding:0;>(3-1) 증원소요 인건비 계산</td>'
            '    <td style="border:none; font-size: 8pt; font-weight: normal;">'
            '       <table > <tr> <td>전년도인원(A) = (3-3)다.증원 전년도평균인원</td> </tr> <tr> <td>당년도인원(B) = (3-3)다.증원 당년도평균인원</td> </tr> <tr> <td>전년도평균단가(D) = (3-4)직급별 전년도평균단가</td> </tr>  </table>'
            '    </td>'
            '  </tr>'
            '</table>'
        )




        
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        # [수정] 총 11행: 데이터(0~7), 합계(8), 빈줄(9), 주석(10)
        self.table = QTableWidget(rank_count + 3, 6)
        
        headers = [
            "직급\n<주1>", "전년도\n인원\n(A)", "당년도\n인원\n(B)", 
            "인원 증감\n(C)=(B)-(A)\n<주2>", "전년도의\n평균단가\n(D) <주3>", "증원소요 인건비\n(C) × (D)"
        ]
        self.table.setHorizontalHeaderLabels(headers)
        self.table.verticalHeader().setFixedWidth(25)
        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;
            }
        """)

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        self.delegate = S3RightAlignedDelegate(self.table)
        self.symbol_delegate = S3SymbolDelegate(self.table)
        
        for i in range(1, 6):
            self.table.setItemDelegateForColumn(i, self.delegate)

        # 8행(합계)에만 "(갑)" 표시 델리게이트 적용
        self.table.setItemDelegateForRow(rank_count, self.symbol_delegate)

        self.setup_content()
        
        self.table.setColumnWidth(0, 70)
        self.table.setColumnWidth(1, 75)
        self.table.setColumnWidth(2, 75) 
        self.table.setColumnWidth(3, 85) 
        self.table.setColumnWidth(4, 95) 
        self.table.setColumnWidth(5, 150)

        self.table.verticalHeader().setDefaultSectionSize(26)

        note_row_idx = rank_count + 2
        self.table.verticalHeader().setSectionResizeMode(note_row_idx, QHeaderView.Fixed)
        self.table.setRowHeight(note_row_idx, 380) # 주석 행 높이

        
        
        self.table.itemChanged.connect(self.calculate_s3)
        self.table.itemClicked.connect(self.handle_click)
        
        layout.addWidget(self.table)



    def handle_click(self, item):
        row, col = item.row(), item.column()
        
        title = ""
        desc = ""
        
        # [1] 마지막 합계 행 (8행) - 모든 열 클릭 시 설명 출력

        if col == 0: # 특히 '갑'이 있는 마지막 칸
            title = "직급 "
            desc = ("<b>&lt;주1&gt;</b><br>"
                    "직급은 모든 직원을 대상으로 하여 구분하되,<br>잡급(정원에 포함하지 않는 비정규직에 대한 인건비) 및 무기계약직은 그 대상에 포함하지 않음.")
        
        if row == rank_count:
            if col == 5: # 특히 '갑'이 있는 마지막 칸
                title = "증원소요 인건비 합계 (갑)"
                desc = ("<b>[산식]</b><br>"
                        "직급별 '인원 증감(D)'과 '전년도 평균단가(E)'를 곱한 금액의 총합계입니다.<br><br>"
                        "※ 이 금액 <b>(갑)</b>은 이전 Sheet(9p인상률점수)의 <b>'증원소요 인건비'</b> 항목에 자동 반영됩니다.")
                

                
            elif col not in [0, 5]:
                title = "항목별 총합계"
                desc = "해당 열의 직급별 데이터를 모두 합산한 결과값입니다."

        # [2] 일반 데이터 행 (0~7행) 중 A, D, F열만 허용
        elif row < rank_count:
            
            # D열 (index 3): 인원 증감 (자동계산)
            if col == 3:
                title = "인원 증감 (D) <주2>"
                desc = "<b><주2></b> 당년도 정원(C) - 전년도 정원(B) 산식에 의해 자동으로 계산되는 칸입니다."
            
            # F열 (index 5): 증원소요 인건비 (자동계산)
            elif col == 5:
                title = "증원소요 인건비 (F)"
                desc = "<b>[산식] 인원 증감(D) × 전년도 평균단가(E)</b><br>해당 직급의 증원에 따른 인건비 소요액을 자동으로 계산합니다."

        # 메시지 박스 출력 (위 조건에 해당하여 desc가 생성된 경우만)
        if desc:
            msg = QMessageBox(self)
            msg.setWindowTitle("항목 상세 설명")
            msg.setText(f"<div style='font-family: 맑은 고딕; font-size: 10pt;'>"
                        f"<b style='color: #0056b3;'>[{title}]</b><br><br>{desc}</div>")
            msg.setStandardButtons(QMessageBox.Ok)
            msg.exec_()
        



    def setup_content(self):
        self.table.blockSignals(True)
        ranks = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직"]

        # 옅은 노란색 정의 (Light Yellow)
        self.received_yellow = QColor(255, 255, 225)
        
        for r in range(rank_count+3): # 11행까지 생성
            for c in range(6):
                # 기본적으로 숫자가 들어가는 칸은 콤마 아이템 적용
                item = S3ThousandSeparatorItem("0") if c >= 1 else QTableWidgetItem("")
                
                # [1] 데이터 행 (0~7행)
                if r < rank_count:
                    if c in [0, 3, 5]: # 자동계산 및 제목 칸 (하늘색)
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if c == 0:
                            item.setText(ranks[r] if r < len(ranks) else "")
                            item.setTextAlignment(Qt.AlignCenter)
                        else:
                            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                            
                    elif c in [1, 2, 4]: # [추가] S7에서 받는 칸 (옅은 노란색 + 입력불가)
                        item.setBackground(self.received_yellow)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 수정 권한 제거
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                        
                    else: # [수정] 순수 입력 가능 칸 (E열 - 평균단가만 남음)
                        item.setBackground(Qt.white)
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

                # [2] 합계 행 (8행)
                elif r == rank_count:
                    item.setBackground(self.base_sky_blue)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    if c == 0:
                        item.setText("계")
                        item.setFont(QFont("맑은 고딕", 9, QFont.Bold))
                        item.setTextAlignment(Qt.AlignCenter)
                    else:
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)                       
                # [3] 빈 줄 (9행)
                elif r == rank_count+1:
                    item.setFlags(Qt.NoItemFlags) # 선택/수정 불가
                    item.setBackground(Qt.white)

                # [4] 주석 행 (10행)
                elif r == rank_count+2:
                    if c == 0:
                        # 1. QLabel 생성 (HTML 태그 사용 가능)
                        note_text = """
                        <div style='line-height: 140%;'>
                            마지막 셀 <b><font size=6>(갑)</font></b> 은 (3)총인건비인상률 &lt;주23&gt; 의 2025년도 셀에 자동 반영.<br><br>
                            
                            <b>&lt;주1&gt;</b><br>
                            직급은 모든 직원을 대상으로 하여 구분하되,<br>
                            잡급(정원에 포함하지 않는 비정규직에 대한 인건비) 및 무기계약직은 그 대상에 포함하지 않음.<br><br>
                            
                            <b>&lt;주2&gt;</b><br>
                            당년도 및 전년도 각 직급별 인원은 (3-3)의 “다. 증원소요인건비 대상 인원”을 기재함.<br><br>
                            
                            <b>&lt;주3&gt;</b><br>
                            전년도의 평균단가는 (3-4)직급별 평균단가 계산을 위한 Template에서 계산된 전년도 평균단가임.<br>
                            (별도직군의 경우 평균단가는 기재하지 않음)<br>
                            다만, 인상률 위반 기관의 경우 증원소요인건비 계산시 전년도 직급별 평균단가는 전년도 실집행액 인건비가 아닌 위반하지 않았을 경우 직급별 인건비를 기준으로 계산함. 
                            
                        </div>
                        """

                        note_label = QLabel(note_text)



                        
                        # 2. 스타일 설정 (글꼴, 자동 줄바꿈, 정렬)
                        note_label.setFont(QFont("맑은 고딕", 9))
                        note_label.setWordWrap(True) # 자동 줄바꿈 필수!
                        note_label.setAlignment(Qt.AlignLeft | Qt.AlignTop) # 왼쪽 상단 정렬
                        note_label.setStyleSheet("background-color: white; padding: 5px; border: none;")
                        
                        # 3. 셀에 위젯으로 박기
                        self.table.setCellWidget(r, 0, note_label)
                    
                    # 주석 칸은 아이템 자체는 빈 걸로 채워둠 (배경색 등 관리용)
                    item.setFlags(Qt.ItemIsEnabled)
                    item.setBackground(Qt.white)

                self.table.setItem(r, c, item)

        # --- 셀 병합 및 높이 조정 ---
        # 9행 (빈 줄) 병합 및 높이
        self.table.setSpan(rank_count+1, 0, 1, 6)
        self.table.setRowHeight(rank_count+1, 15)

        # 10행 (주석) 병합 및 높이
        self.table.setSpan(rank_count+2, 0, 1, 6)


        self.table.blockSignals(False)








    def calculate_s3(self, item):
        if item is None:
            for r in range(rank_count):
                it = self.table.item(r, 1)
                if it: self.calculate_s3(it)
            return

        row, col = item.row(), item.column()
        # 데이터 입력 행 (0~8행) 내에서 작동
        if col not in [1, 2, 4] or row >= rank_count: 
            return  
        
        # "... ..." 줄(인덱스 6)은 가로 계산에서 제외
        rank_name_item = self.table.item(row, 0)
        if rank_name_item and rank_name_item.text() == "... ...":
            return

        self.table.blockSignals(True)
        try:
            def gv(r, c):
                it = self.table.item(r, c)
                name_it = self.table.item(r, 0)
                # 합산 시 중략(... ...) 줄과 계 줄은 0 처리 (순수 데이터만 합산하기 위함)
                if name_it and (name_it.text() == "... ..." or name_it.text() == "계"):
                    return 0.0
                txt = it.text().replace(',', '') if it else ""
                try: return float(txt) if txt else 0.0
                except: return 0.0
            
            # 1. 개별 행 가로 계산
            vA, vB = gv(row, 1), gv(row, 2)
            vC = round(vB - vA, 2)
            it_c = self.table.item(row, 3)
            if it_c: it_c.setData(Qt.EditRole, vC)

            vD = int(round(gv(row, 4), 0))   # 평균단가 = 정수
            vCost = vC * vD

            it_cost = self.table.item(row, 5)
            if it_cost: it_cost.setData(Qt.EditRole, int(round(vCost, 0)))
            
            # 2. 모든 열 세로 합계 계산 (1열 ~ 5열 전체)
            final_sum_row = rank_count   # "계" 줄 인덱스 고정
            
            # 합산 범위: 별도직군(7행) 전까지 (0~6행 합산)
            rows_to_sum = rank_count # 0부터 rank_count-1까지 합산
            
            for c_sum in range(1, 6): # 1, 2, 3, 4, 5열 모두 합산
                total = sum(gv(r, c_sum) for r in range(rows_to_sum))
                it_total = self.table.item(final_sum_row, c_sum)
                if it_total:
                    if c_sum in [1, 2, 3]:          # 인원 관련만 소수
                        it_total.setData(Qt.EditRole, round(total, 2))
                    elif c_sum in [4, 5]:           # 평균단가, 인건비는 정수
                        it_total.setData(Qt.EditRole, int(round(total, 0)))

        except Exception:
            pass
        finally: 
            self.table.blockSignals(False)
            # S2 연동용 (계 행의 최종 금액)
            trigger_item = self.table.item(rank_count, 5)
            if trigger_item:
                self.table.itemChanged.emit(trigger_item)










            


    def sync_from_s7(self, s7_data):
        """
        Sheet7에서 추출한 [(전년1, 당년1), ... (전년8, 당년8)] 데이터를 
        S3의 A열(1열), B열(2열)에 숫자로 반영
        """
        self.table.blockSignals(True) # 대량 데이터 입력 시 렉 방지
        try:
            for r, (prev_val, curr_val) in enumerate(s7_data):
                if r >= rank_count: break # 8직급까지만 반영
                
                # 1열(전년도)과 2열(당년도) 아이템 가져오기
                it_prev = self.table.item(r, 1)
                it_curr = self.table.item(r, 2)
                

                if it_prev: it_prev.setData(Qt.EditRole, float(prev_val))
                if it_curr: it_curr.setData(Qt.EditRole, float(curr_val))

            
            # 데이터 주입 후, 각 행에 대해 기존 calculate_s3가 하던 계산을 수동으로 트리거
            # blockSignals 상태이므로 직접 호출이 필요함
            for r in range(rank_count):
                # 1열이 바뀌었다고 가정하고 계산 함수 호출
                dummy_item = self.table.item(r, 1)
                self.calculate_s3(dummy_item)
                
        finally:
            self.table.blockSignals(False)
            # 마지막으로 합계 갱신을 위해 한번 더 호출
            self.calculate_s3(self.table.item(0, 1))


    # [추가] S8에서 데이터를 받아오는 함수
    def sync_unit_price_from_s8(self, s8_data):
        self.table.blockSignals(True)
        try:
            for r, price in enumerate(s8_data):
                if r < rank_count:
                    it = self.table.item(r, 4) # 4열: 평균단가
                    if it:
                        it.setData(Qt.EditRole, price)
            # 데이터 수신 후 전체 재계산
            self.calculate_s3(None)
        finally:
            self.table.blockSignals(False)



    def get_gab_to_s2(self):
        """S2 연동을 위해 증원소요 인건비 (갑) 데이터 추출"""
        it = self.table.item(rank_count, 5)
        if it:
            val_str = it.text().replace(',', '')
            val = float(val_str) if val_str else 0.0
            return val
        return 0.0

















    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []

        # 1. 헤더 복사
        if min_r == 0:
            headers = [self.table.horizontalHeaderItem(c).text().replace('\n', ' ') 
                       if self.table.horizontalHeaderItem(c) else f"열{c}" for c in range(min_c, max_c + 1)]
            lines.append("\t".join(headers))

        for r in range(min_r, max_r + 1):
            # rank_count(7) + 합계(1) 까지만 복사 (빈줄/주석 제외)
            if r > rank_count: continue 
            
            row_data = []
            for c in range(min_c, max_c + 1):
                # --- [A. 데이터 행: 0 ~ 6행] ---
                if r < rank_count:
                    if c == 3: # 인원 증감(C) = B - A
                        formula = "=INDEX($1:$1048576, ROW(), COLUMN()-1)-INDEX($1:$1048576, ROW(), COLUMN()-2)"
                        row_data.append(formula)
                    elif c == 5: # 인건비(F) = C * E (3번열 * 4번열)
                        # 엑셀 기준: 현재(5열)에서 왼쪽으로 2칸(C), 1칸(E) 곱함
                        formula = "=INDEX($1:$1048576, ROW(), COLUMN()-2)*INDEX($1:$1048576, ROW(), COLUMN()-1)"
                        row_data.append(formula)
                    else:
                        # 0(직급), 1(전년), 2(당년), 4(평균단가)는 값 복사
                        it = self.table.item(r, c)
                        val = it.text().replace(',', '').strip() if it else ""
                        if val.startswith(('=', '+')): val = "'" + val
                        row_data.append(val)

                # --- [B. 계 줄: 7행 (모든 숫자 열 SUM)] ---
                elif r == rank_count:
                    if c in [1, 2, 3, 4, 5]:
                        # rank_count(7)만큼 위로 올라가서 합계 시작
                        formula = (
                            f"=SUM("
                            f"INDEX($1:$1048576, ROW()-{rank_count}, COLUMN()):"
                            f"INDEX($1:$1048576, ROW()-1, COLUMN())"
                            f")"
                        )
                        row_data.append(formula)
                    else:
                        # 0번 '계' 텍스트 등
                        it = self.table.item(r, c)
                        val = it.text().replace(',', '').strip() if it else ""
                        row_data.append(val)
            
            if row_data:
                lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))
















        







    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사 (Ctrl+C)")
        paste_action = menu.addAction("붙여넣기 (Ctrl+V)")
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action: self.copy_selection()
        elif action == paste_action: self.paste_selection()







    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        r_s, c_s = curr.row(), curr.column()
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = r_s + i, c_s + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    item = self.table.item(r, c)
                    if item and (item.flags() & Qt.ItemIsEditable):
                        item.setText(val.strip().replace(',', ''))
        self.table.blockSignals(False)
        self.calculate_s3(self.table.item(0, 1))


    '''
    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C: self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V: self.paste_selection()
        else: super().keyPressEvent(event)
    '''
    



    def keyPressEvent(self, event):
        # 1. 복사/붙여넣기
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C: 
            self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V: 
            self.paste_selection()

        # 2. 엔터 키를 누르면 아래 셀로 이동 (중복 제거됨)
        elif event.key() in [Qt.Key_Return, Qt.Key_Enter]:
            curr = self.table.currentIndex()
            next_row = curr.row() + 1
            if next_row < self.table.rowCount():
                # 현재 열은 유지하고 행만 +1 해서 이동
                self.table.setCurrentCell(next_row, curr.column())

        # 3. 그 외 기본 키 이벤트 (방향키 등)
        else: 
            super().keyPressEvent(event)













        
