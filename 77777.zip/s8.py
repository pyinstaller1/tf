from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

rank_count = 8

# [1] S8 전용 우측 정렬 델리게이트
class S8RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 키 이벤트를 감지하기 위해 이벤트 필터 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 오른쪽 방향키
            if event.key() == Qt.Key_Right:
                # 커서가 글자 맨 뒤에 있을 때 이동
                if obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True # 이벤트 전파 중단
            
            # 2. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 커서가 글자 맨 앞에 있을 때 이동
                if obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True # 이벤트 전파 중단
                    
        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """셀 이동 및 자동 편집 모드 진입 로직"""
        table = self.parent()
        curr_idx = table.currentIndex()
        
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        next_idx = table.model().index(curr_idx.row(), next_col)
        
        if next_idx.isValid():
            # 1. 다음 셀로 선택 위치 변경
            table.setCurrentIndex(next_idx)
            
            # 2. 수정 가능한 셀인지 확인 (S8의 14, 15열이나 합계 행 등 제외)
            item = table.item(next_idx.row(), next_idx.column())
            if item and (item.flags() & Qt.ItemIsEditable):
                # 수정 가능하면 즉시 입력 모드 시작
                table.edit(next_idx)

    def setModelData(self, editor, model, index):
        # 쉼표 제거 후 데이터 저장 (기존 로직 유지)
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)
        

# [2] S8 전용 천단위 콤마 아이템
class S8ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                if num == int(num): return format(int(num), ",")
                else: return format(num, ",.2f").rstrip('0').rstrip('.')
            except: return val
        return super().data(role)

class Sheet8Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.from_s4 = None
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-4) 직급별 평균단가 계산")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)        

        # 열 구성: 구분(0), 직급(1), 1~12월(2-13), 인건비총계(14), 직급별평균단가(15)
        self.table = QTableWidget(18, 16)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # [수정] 행 높이를 25px로 압축 (가장 슬림한 표준)
        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.verticalHeader().setFixedWidth(25)

        # 스타일 시트 (스크롤바 강조 및 여백 최소화)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertial { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar::handle:vertical:hover { background: #555555; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            QScrollBar::handle:horizontal:hover { background: #555555; }
            QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
        """)

        # [수정] 제목줄 1줄로 고정 (줄바꿈 제거)
        headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["인건비 총계", "직급별 평균단가"]
        self.table.setHorizontalHeaderLabels(headers)

        self.delegate = S8RightAlignedDelegate(self.table)
        for i in range(2, 16):
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        # 너비 설정
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 100)
        self.table.setColumnWidth(14, 120); self.table.setColumnWidth(15, 120)

        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Fixed)
        self.table.blockSignals(False)

        self.table.itemChanged.connect(self.calculate_s8)
        layout.addWidget(self.table)





    def setup_content(self):
        self.table.blockSignals(True)
        
        # [핵심] 다른 시트와 동일한 행 구성 정의
        sep_row1 = rank_count            # 9 (if rank_count=9)
        title_row = sep_row1 + 1         # 10
        data2_start_idx = title_row + 1  # 11
        sep_row2 = data2_start_idx + rank_count # 20
        comment_row = sep_row2 + 1       # 21

        # 전체 행수 설정 (+4: 전년도, 당년도, 제목줄, 구분선, 주석 포함)
        self.table.setRowCount((rank_count * 2) + 4)
        self.table.setColumnCount(16)

        # 직급 리스트 (사용자 지침 반영)
        ranks = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직", "계"]
        full_headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["인건비 총계", "직급별 평균단가"]
        
        bold_font = QFont(); bold_font.setBold(True)

        # --- [첫 번째 표: 전년도] ---
        year_item1 = QTableWidgetItem("전\n년\n도")
        year_item1.setTextAlignment(Qt.AlignCenter); year_item1.setBackground(QColor(245, 245, 245))
        self.table.setItem(0, 0, year_item1)
        self.table.setSpan(0, 0, rank_count, 1)

        for r in range(rank_count):
            is_last = (r == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[r])
            it_rank.setTextAlignment(Qt.AlignCenter); it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(r, 1, it_rank)
            
            for c in range(2, 16):
                it = S8ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                # 계 행(is_last), 인건비총계(14), 평균단가(15)는 잠금 및 배경색
                if is_last or c == 14:
                    it.setBackground(self.base_sky_blue)
                    if is_last: it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                elif c == 15: # 평균단가 열 (노란색 강조)
                    it.setBackground(QColor(255, 255, 225))
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(r, c, it)

        # --- [중간 구분선 & 제목줄] ---
        self.table.setRowHeight(sep_row1, 15)
        self.table.setRowHeight(title_row, 45)

        for c in range(16):
            # 1. 구분선 아이템 생성 및 플래그 설정
            sep_it = QTableWidgetItem("")
            sep_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 키보드 입력 차단
            self.table.setItem(sep_row1, c, sep_it) 
            
            # 2. 제목줄 아이템 (이미 잘 되어 있는 부분)
            t_it = QTableWidgetItem(full_headers[c])
            t_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 키보드 입력 차단
            t_it.setBackground(QColor(240, 240, 240))
            t_it.setFont(bold_font)
            t_it.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(title_row, c, t_it)

        # --- [두 번째 표: 당년도] ---
        year_item2 = QTableWidgetItem("당\n년\n도")
        year_item2.setTextAlignment(Qt.AlignCenter); year_item2.setBackground(QColor(245, 245, 245))
        self.table.setItem(data2_start_idx, 0, year_item2)
        self.table.setSpan(data2_start_idx, 0, rank_count, 1)
        self.table.setRowHeight(data2_start_idx-1, 30)


        for c in range(16):
            # 1. 구분선 아이템 생성 및 플래그 설정
            sep_it = QTableWidgetItem("")
            sep_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 키보드 입력 차단
            self.table.setItem(sep_row1, c, sep_it) 
            
            # 2. 제목줄 아이템 (이미 잘 되어 있는 부분)
            t_it = QTableWidgetItem(full_headers[c])
            t_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 키보드 입력 차단



        for i in range(rank_count):
            curr_r = data2_start_idx + i
            is_last = (i == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[i])
            it_rank.setTextAlignment(Qt.AlignCenter); it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(curr_r, 1, it_rank)

            for c in range(2, 16):
                it = S8ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if is_last or c == 14:
                    it.setBackground(self.base_sky_blue)
                    if is_last: it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                elif c == 15:
                    it.setBackground(QColor(255, 255, 225))
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(curr_r, c, it)

        # --- [주석 마무리] ---
        self.table.setRowHeight(sep_row2, 15)
        self.table.setRowHeight(comment_row, 80)
        self.table.setSpan(comment_row, 0, 1, 16)
        note = (
            " * 전년도와 당년도 평균단가(인건비 총계 ÷ 12)를 계산하여 인상률 차등적용이 적절하게 이루어졌는지를 확인함.\n"
            " * 각 직급별로 매월 지급된 인건비를 해당 월에 기입함.\n"
            " * 직급별 평균단가는 1월부터 12월까지의 인건비 합계금액을 12로 나누어서 구함."
        )
        c_item = QTableWidgetItem(note)
        c_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(comment_row, 0, c_item)
        
        self.table.blockSignals(False)











    def calculate_s8(self, item):
        if item is None: return
        r, c = item.row(), item.column()
        
        sep_row1 = rank_count           # 9
        title_row = sep_row1 + 1        # 10
        data2_start = title_row + 1     # 11
        last_y1 = rank_count - 1        # 8 (계 행)
        last_y2 = data2_start + rank_count - 1 # 19 (계 행)

        # [수정] 구분선과 제목줄만 피하고, '계' 행(last_y1, last_y2)은 계산 로직을 타야 합니다.
        if r in [sep_row1, title_row]: return 

        self.table.blockSignals(True)
        try:
            # 1. 범위 설정
            if r <= last_y1:
                start_r, last_r = 0, last_y1
                manpower_list = self.from_s4[0] if self.from_s4 else None
            else:
                start_r, last_r = data2_start, last_y2
                manpower_list = self.from_s4[1] if self.from_s4 else None

            # 2. 가로 총계 및 개인 평균단가 (데이터 행인 경우에만 수행)
            if r != last_r:
                row_sum = sum(self.cell_value(r, col) for col in range(2, 14))
                item14 = self.table.item(r, 14)
                if item14: item14.setData(Qt.EditRole, int(row_sum))
                
                if manpower_list and (r - start_r) < len(manpower_list):
                    man = manpower_list[r - start_r]
                    price = row_sum / man if man > 0 else 0.0
                    it15 = self.table.item(r, 15)
                    if it15: it15.setText(format(int(round(price)), ",d"))

            # 3. 세로 합계 계산 (데이터 행이 수정되면 해당 열의 '계'를 갱신)
            # col이 데이터 영역(2~14)일 때 수행
            if 2 <= c <= 14:
                col_total = sum(self.cell_value(start_r + i, c) for i in range(rank_count - 1))
                sum_cell = self.table.item(last_r, c)
                if sum_cell: sum_cell.setData(Qt.EditRole, int(col_total))

            # 4. '계' 행의 가로 총계 및 전체 평균단가 재계산
            total_sum_cost = sum(self.cell_value(last_r, col) for col in range(2, 14))
            it14_sum = self.table.item(last_r, 14)
            if it14_sum: it14_sum.setData(Qt.EditRole, int(total_sum_cost))

            if manpower_list:
                total_man = manpower_list[-1]
                avg_total_price = total_sum_cost / total_man if total_man > 0 else 0.0
                sum_it15 = self.table.item(last_r, 15)
                if sum_it15: sum_it15.setText(format(int(round(avg_total_price)), ",d"))

        finally:
            self.table.blockSignals(False)

            

    def cell_value(self, row, col):
        """테이블 아이템의 텍스트를 float으로 안전하게 변환"""
        item = self.table.item(row, col)
        if item and item.text().strip():
            try:
                # 콤마 제거 후 숫자로 변환
                return float(item.text().replace(',', ''))
            except ValueError:
                return 0.0
        return 0.0

            
    def sync_from_s4(self, s4_data):
        """MainWindow를 통해 S4의 평균인원 데이터를 주입받고 S8 전체를 재계산"""
        if not s4_data: return
        
        self.from_s4 = s4_data  # [전년도리스트, 당년도리스트]
        self.table.blockSignals(True)
        
        sep_row1 = rank_count          # 전년도 '계' 행
        data2_start = sep_row1 + 2     # 당년도 첫 번째 데이터 행
        
        try:
            # 1. 모든 데이터 행(전년도 + 당년도)에 대해 평균단가(15열) 계산
            target_rows = list(range(rank_count)) + list(range(data2_start, data2_start + rank_count))
            
            for r in target_rows:
                manpower = 0.0
                if r < sep_row1: # 전년도
                    if r < len(self.from_s4[0]): manpower = self.from_s4[0][r]
                else: # 당년도
                    idx = r - data2_start
                    if idx < len(self.from_s4[1]): manpower = self.from_s4[1][idx]
                
                cost = self.cell_value(r, 14) # 총계(14열)
                unit_price = cost / manpower if manpower > 0 else 0.0
                
                item = self.table.item(r, 15)
                if item:
                    item.setText(format(int(round(unit_price)), ","))

            # 2. [중요] 단가가 바뀌었으므로 '계' 행들을 다시 계산하기 위해 로직 트리거
            # 단순히 텍스트만 바꾸는 게 아니라, calculate_s8을 직접 호출하여 합계를 갱신합니다.
            self.table.blockSignals(False) # 계산 함수 내부의 신호를 위해 잠시 해제
            
            # 전년도 계 계산 트리거
            it_prev = self.table.item(0, 2)
            if it_prev: self.calculate_s8(it_prev)
            
            # 당년도 계 계산 트리거
            it_curr = self.table.item(data2_start, 2)
            if it_curr: self.calculate_s8(it_curr)
            
        except Exception as e:
            print(f"S8 Sync Error: {e}")
        finally:
            self.table.blockSignals(False)




                

    def get_unit_price_to3(self):
        """S3 연동을 위해 전년도 '순수 직급별' 평균단가(15열) 추출 (계 제외)"""
        data = []
        # rank_count - 1 만큼 반복하여 '계' 행은 제외하고 추출
        for i in range(rank_count - 1): 
            it = self.table.item(i, 15)
            val = float(it.text().replace(',', '')) if it and it.text() else 0.0
            data.append(val)
        return data

    def get_unit_price_to10(self):
        """S10 연동을 위해 전년도 '순수 직급별' 평균단가(15열) 추출 (계 제외)"""
        # get_unit_price_to3와 동일한 로직으로 rank_count 대응
        data = []
        for i in range(rank_count - 1):
            it = self.table.item(i, 15)
            val = float(it.text().replace(',', '')) if it and it.text() else 0.0
            data.append(val)
        return data





    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        # [핵심] 좌표 변수 정의
        sep_row1 = rank_count
        title_row = sep_row1 + 1
        data2_start = title_row + 1
        sep_row2 = data2_start + rank_count
        comment_row = sep_row2 + 1

        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []

        # 1. 제목줄 복사 (표 최상단 0행 포함 시)
        if min_r == 0:
            h_row = []
            for c in range(min_c, max_c + 1):
                h_item = self.table.horizontalHeaderItem(c)
                h_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(h_row))

        for r in range(min_r, max_r + 1):
            # 2. 특수 행 처리 (구분선, 중간제목, 주석)
            if r in [sep_row1, title_row, sep_row2]:
                row_data = []
                for c in range(min_c, max_c + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data))
                continue

            if r == comment_row:
                it = self.table.item(r, 0)
                val = it.text().strip() if it else ""
                lines.append(val + "\t" * (max_c - min_c))
                continue
                
            # 3. 데이터 행 및 수식 처리
            row_data = []
            ex_r = r + 2 # 엑셀 행 번호 보정 (1-based + 헤더1줄)

            for c in range(min_c, max_c + 1):
                col_let = chr(65 + c)
                # 데이터 영역 판정
                is_y1_data = (0 <= r < rank_count - 1)
                is_y2_data = (data2_start <= r < data2_start + rank_count - 1)
                is_sum_row = (r == rank_count - 1 or r == data2_start + rank_count - 1)

                # 가로 총계 (인건비 총계 - 14열)
                if (is_y1_data or is_y2_data or is_sum_row) and c == 14:
                    row_data.append(f"=SUM(C{ex_r}:N{ex_r})")

                # 전년도 세로 합계 (15열 제외 2~14열)
                elif r == rank_count - 1 and 2 <= c <= 14:
                    row_data.append(f"=SUM({col_let}2:{col_let}{rank_count})")

                # 당년도 세로 합계 (15열 제외 2~14열)
                elif r == data2_start + rank_count - 1 and 2 <= c <= 14:
                    start_ex = data2_start + 2
                    end_ex = data2_start + rank_count
                    row_data.append(f"=SUM({col_let}{start_ex}:{col_let}{end_ex})")
                
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        txt = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not txt or not curr: return
        
        self.table.blockSignals(True)
        affected_cells = [] # 수정된 셀 좌표 저장

        sep_row1 = rank_count
        title_row = sep_row1 + 1
        data2_start = title_row + 1
        sep_row2 = data2_start + rank_count
        protected_rows = [sep_row1, title_row, sep_row2]

        try:
            for i, line in enumerate(txt.splitlines()):
                if any(h in line for h in ["구분", "직급", "월"]): continue
                for j, val in enumerate(line.split('\t')):
                    r, c = curr.row() + i, curr.column() + j
                    if r < self.table.rowCount() and c < self.table.columnCount():
                        # 직급열, 보호행, 수식열(14,15)은 붙여넣기 제외
                        if c < 2 or r in protected_rows or c >= 14: continue
                        
                        it = self.table.item(r, c)
                        if it and (it.flags() & Qt.ItemIsEditable):
                            clean_val = val.strip().replace(',', '')
                            try:
                                num_val = int(float(clean_val or 0))
                                it.setData(Qt.EditRole, num_val)
                                affected_cells.append((r, c))
                            except: pass
        finally:
            self.table.blockSignals(False)
            
            # [핵심] 수정된 모든 열에 대해 계산 실행
            processed_cols = set()
            for r, c in affected_cells:
                if (r, c) not in processed_cols: # 열 단위로 한 번씩만 트리거
                    self.calculate_s8(self.table.item(r, c))
            
            # S10 연동 시그널
            for r in range(rank_count):
                target_item = self.table.item(r, 15)
                if target_item: self.table.itemChanged.emit(target_item)
                    
                    

    def show_context_menu(self, pos):
        menu = QMenu()
        cp = menu.addAction("복사 (Ctrl+C)"); ps = menu.addAction("붙여넣기 (Ctrl+V)")
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if act == cp: self.copy_selection()
        elif act == ps: self.paste_selection()

        

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
