from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QKeySequence, QFont

rank_count = 8


class s5RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        editor.installEventFilter(self) # 이벤트 필터 설치
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            if event.key() == Qt.Key_Right:
                # 커서가 글자 맨 끝에 있을 때 오른쪽 키를 누르면
                if obj.cursorPosition() == len(obj.text()):
                    # 현재 테이블 위젯을 찾아 다음 셀로 강제 이동
                    table = self.parent()
                    if isinstance(table, QAbstractItemView):
                        # 현재 인덱스의 다음 열(Column)로 이동
                        next_index = table.model().index(table.currentIndex().row(), table.currentIndex().column() + 1)
                        if next_index.isValid():
                            table.setCurrentIndex(next_index)
                            table.edit(next_index) # 이동 후 바로 입력 모드 유지
                    return True # 에디터가 이 키를 처리했음을 알림 (커서 이동 방지)

            elif event.key() == Qt.Key_Left:
                # 커서가 맨 앞에 있을 때 왼쪽 키를 누르면
                if obj.cursorPosition() == 0:
                    table = self.parent()
                    if isinstance(table, QAbstractItemView):
                        prev_index = table.model().index(table.currentIndex().row(), table.currentIndex().column() - 1)
                        if prev_index.isValid():
                            table.setCurrentIndex(prev_index)
                            table.edit(prev_index)
                    return True
        return super().eventFilter(obj, event)

    def setModelData(self, editor, model, index):
        model.setData(index, editor.text().replace(',', ''), Qt.EditRole)


class s5ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                num = float(str(val).replace(',', ''))
                # 정수면 콤마만, 소수면 소수점 2자리까지
                return format(int(num), ",") if num == int(num) else format(num, ",.2f").rstrip('0').rstrip('.')
            except: return val
        return super().data(role)

class Sheet5Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-3) 근속승진 및 증원소요인건비 대상 인원의 파악")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        self.table = QTableWidget(18, 26)
        self.setup_style()
        self.setup_headers()
        self.setup_content()

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        delegate = s5RightAlignedDelegate(self.table)
        for c in range(2, 26):
            self.table.setItemDelegateForColumn(c, delegate)

        self.table.itemChanged.connect(self.calculate_s5)
        layout.addWidget(self.table)

    def setup_style(self):
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.verticalHeader().setFixedWidth(25)

        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            
            /* 헤더 스타일 */
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;
            }

            /* 가로 스크롤바 스타일 개선 */
            QScrollBar:horizontal {
                border: 1px solid #d0d0d0;
                background: #f0f0f0;
                height: 12px;
                margin: 0px 0px 0px 0px;
            }
            QScrollBar::handle:horizontal {
                background: #bcbcbc; /* 스크롤 핸들 색상 (진한 회색) */
                min-width: 20px;
                border-radius: 5px;
            }
            QScrollBar::handle:horizontal:hover {
                background: #a0a0a0; /* 마우스 올렸을 때 더 진하게 */
            }

            /* 세로 스크롤바 스타일 개선 */
            QScrollBar:vertical {
                border: 1px solid #d0d0d0;
                background: #f0f0f0;
                width: 12px;
                margin: 0px 0px 0px 0px;
            }
            QScrollBar::handle:vertical {
                background: #bcbcbc;
                min-height: 20px;
                border-radius: 5px;
            }
            QScrollBar::handle:vertical:hover {
                background: #a0a0a0;
            }
            
            /* 스크롤바 상하단 화살표 제거 (더 깔끔하게) */
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                width: 0px; height: 0px;
            }
            
        """)



    def setup_headers(self):
        h_labels = ["구분", "직급"]
        for m in range(1, 7):
            for sub in ["정원", "현원", "복직자", "누적차"]:
                h_labels.append(f"{m}월\n{sub}")
        self.table.setHorizontalHeaderLabels(h_labels)
        self.table.horizontalHeader().setFixedHeight(45)
        
        self.table.setColumnWidth(0, 30) 
        self.table.setColumnWidth(1, 60)
        for c in range(2, 26): self.table.setColumnWidth(c, 70)

    def setup_content(self):
        self.table.blockSignals(True)
        
        # 1. 다른 시트와 동일한 행수 계산 방식 (9*2 + 3 = 21행)
        # 전년도(rank_count) + 구분선(1) + 헤더(1) + 당년도(rank_count) + 주석(1)
        self.table.setRowCount((rank_count * 2) + 4)
        self.table.setColumnCount(26)

        # 2. 직급 리스트 명시적 선언 (유지보수 시 이 부분만 수정)
        ranks = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직", "계"]
        
        # 3. 행 위치 변수 (다른 시트와 동일 로직)
        sep_row1 = rank_count            # 9
        title_row = sep_row1 + 1         # 10
        data2_start_idx = title_row + 1  # 11
        sep_row2 = data2_start_idx + rank_count # 20
        comment_row = sep_row2 + 1       # 21

        bold_font = QFont(); bold_font.setBold(True)

        # --- [첫 번째 표 생성] ---
        year_item1 = QTableWidgetItem("전\n년\n도") # S5 성격에 맞게 '전년도' 또는 '당년도'
        year_item1.setTextAlignment(Qt.AlignCenter)
        year_item1.setBackground(QColor(245, 245, 245))
        self.table.setItem(0, 0, year_item1)
        self.table.setSpan(0, 0, rank_count, 1)

        for r in range(rank_count):
            is_last = (r == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[r])
            it_rank.setTextAlignment(Qt.AlignCenter)
            it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # Editable 제외
            self.table.setItem(r, 1, it_rank)




            for c in range(2, 26):
                it = s5ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                # 계 행이거나 누적차 열이면 강조 및 잠금
                if is_last or (c - 2) % 4 == 3:
                    it.setBackground(self.base_sky_blue); it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(r, c, it)

        # --- [중간 구분선 & 제목줄] ---
        self.table.setRowHeight(sep_row1, 15)
        self.table.setRowHeight(title_row, 45)
        for c in range(26):
            self.table.setItem(sep_row1, c, QTableWidgetItem("")) # 구분선
            
            t_it = QTableWidgetItem()
            t_it.setBackground(QColor(240, 240, 240)); t_it.setFont(bold_font); t_it.setTextAlignment(Qt.AlignCenter)
            if c == 0: t_it.setText("구분")
            elif c == 1: t_it.setText("직급")
            else:
                m = 7 + (c - 2) // 4
                sub = ["정원", "현원", "복직자", "누적차"][(c - 2) % 4]
                t_it.setText(f"{m}월\n{sub}")
            self.table.setItem(title_row, c, t_it)

        # --- [두 번째 표 생성] ---
        year_item2 = QTableWidgetItem("당\n년\n도")
        year_item2.setTextAlignment(Qt.AlignCenter)
        year_item2.setBackground(QColor(245, 245, 245))
        self.table.setItem(data2_start_idx, 0, year_item2)
        self.table.setSpan(data2_start_idx, 0, rank_count, 1)

        for i in range(rank_count):
            curr_r = data2_start_idx + i
            is_last = (i == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[i])
            it_rank.setTextAlignment(Qt.AlignCenter)
            it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # Editable 제외

            self.table.setItem(curr_r, 1, it_rank)

            for c in range(2, 26):
                it = s5ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if is_last or (c - 2) % 4 == 3:
                    it.setBackground(self.base_sky_blue); it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(curr_r, c, it)


        self.table.setRowHeight(sep_row2, 15)
        for c in range(26): 
            self.table.setItem(sep_row2, c, QTableWidgetItem(""))

        comment_row = sep_row2 + 1 
        self.table.setRowHeight(comment_row, 60) 
        self.table.setSpan(comment_row, 0, 1, 26)
        
        comment_text = (
            " * 누적차는 정원의 누적에서 현원의 누적을 차감한 후 복직자의 누적을 가산한 것임.\n"
            "   (이 때 누적은 최상위 직급의 인원부터 해당 직급의 인원까지 순차적으로 합산한 인원임).\n"
            "   누적차가 음수인 경우 근속승진을 의미함."
        )
        comment_it = QTableWidgetItem(comment_text)
        comment_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        # 텍스트가 여러 줄이므로 수직/수평 정렬 조절 (필요 시)
        comment_it.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter) 
        self.table.setItem(comment_row, 0, comment_it)
        
        self.table.blockSignals(False)
        


    def calculate_s5(self, item):
        r, c = item.row(), item.column()
        
        # 1. setup_content와 동일한 좌표 기준 (rank_count 기반)
        sep_row1 = rank_count            # 9
        title_row = sep_row1 + 1         # 10
        data2_start = title_row + 1      # 11
        
        # 입력 제외 대상: 구분 열, 누적차 열, 구분선 행, 제목줄 행
        if c < 2 or (c - 2) % 4 == 3 or r in [sep_row1, title_row]: 
            return 
        
        self.table.blockSignals(True)
        try:
            month_base = 2 + ((c - 2) // 4) * 4
            
            # 2. 현재 수정 중인 표의 영역 설정
            if r < sep_row1:
                # 표 1 (0 ~ 8행)
                start_row = 0
                last_row = rank_count - 1  # index 8 ('계' 행)
            elif r >= data2_start:
                # 표 2 (11 ~ 19행)
                start_row = data2_start
                last_row = data2_start + rank_count - 1 # index 19 ('계' 행)
            else:
                return

            # 3. 각 직급별 누적차 계산 (계 행 제외)
            # range(start_row, last_row) -> 0~7 또는 11~18 (별도직군까지만 계산)
            for row in range(start_row, last_row):
                acc = 0
                for rr in range(start_row, row + 1):
                    val_jung = self.cell_value(rr, month_base)
                    val_hyun = self.cell_value(rr, month_base + 1)
                    val_bok = self.cell_value(rr, month_base + 2)
                    acc += (val_jung - val_hyun + val_bok)
                
                diff_it = self.table.item(row, month_base + 3)
                if diff_it:
                    diff_it.setData(Qt.EditRole, float(acc)) 
                    diff_it.setForeground(QColor("red") if acc < 0 else QColor("black"))
            
            # 4. '계' 행에 세로 합계 입력 (정원, 현원, 복직자)
            # 데이터 행(rank_count-1 개)의 합을 구함
            for off in range(3):
                col_idx = month_base + off
                v_sum = 0
                for i in range(rank_count - 1): # 0~7직급 + 별도직군까지 합산
                    v_sum += self.cell_value(start_row + i, col_idx)
                
                sum_item = self.table.item(last_row, col_idx) # 여기가 진짜 '계' 행
                if sum_item:
                    sum_item.setData(Qt.EditRole, float(v_sum))
                
            # 5. 누적차 '계' (마지막 데이터 행인 '별도직군'의 누적차를 복사)
            # index: last_row - 1 은 '별도직군' 행
            last_diff_val = self.cell_value(last_row - 1, month_base + 3)
            total_diff_item = self.table.item(last_row, month_base + 3) # 여기가 진짜 '계' 행
            
            if total_diff_item:
                total_diff_item.setData(Qt.EditRole, float(last_diff_val))
                # 색상 동기화
                target_it = self.table.item(last_row - 1, month_base + 3)
                if target_it:
                    total_diff_item.setForeground(target_it.foreground())
            
        finally: 
            self.table.blockSignals(False)
            
        









    def get_data_for_s6(self):
        data_rows_count = rank_count - 1
        result = [[0 for _ in range(12)] for _ in range(data_rows_count)]

        sep_row1 = rank_count
        title_row = sep_row1 + 1
        data2_start_idx = title_row + 1

        for m in range(12):
            start_row = data2_start_idx if m >= 6 else 0
            month_block_idx = m % 6
            col = 2 + (month_block_idx * 4) + 3  # 누적차 열

            for r in range(data_rows_count):
                it = self.table.item(start_row + r, col)
                try:
                    acc = int(it.text().replace(',', '')) if it else 0
                except Exception:
                    acc = 0

                # 🔥 핵심: 음수 → 절댓값, 양수 → 0
                result[r][m] = abs(acc) if acc < 0 else 0

        return result





































    def cell_value(self, r, c):
        """콤마 제거 후 안전하게 float 변환 (에러 방지)"""
        it = self.table.item(r, c)
        if not it: 
            return 0.0
        
        txt = it.text().replace(',', '').strip()
        if not txt: 
            return 0.0
            
        try: 
            return float(txt)
        except ValueError: 
            return 0.0

        



    def copy_selection(self):
        ranges = self.table.selectedRanges()
        if not ranges: return
        r0, r1 = min(r.topRow() for r in ranges), max(r.bottomRow() for r in ranges)
        c0, c1 = min(r.leftColumn() for r in ranges), max(r.rightColumn() for r in ranges)
        
        # --- 기준 위치 동적 계산 ---
        num_ranks = rank_count # 9
        sep_row1 = num_ranks    # 9
        title_row = sep_row1 + 1 # 10
        data2_start_idx = title_row + 1 # 11
        sep_row2 = data2_start_idx + num_ranks # 20
        comment_row = sep_row2 + 1 # 21
        
        invalid_rows = [sep_row1, title_row, sep_row2, comment_row]
        lines = []

        # 1. 가로 헤더 복사 (0행이 포함된 경우)
        if r0 == 0:
            header_row = []
            for c in range(c0, c1 + 1):
                h_item = self.table.horizontalHeaderItem(c)
                header_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(header_row))

        # 2. 본문 복사
        for r in range(r0, r1 + 1):
            row_data = []
            # 특수 행(구분선, 제목줄, 주석) 처리
            if r in invalid_rows:
                for c in range(c0, c1 + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data))
                continue

            # --- 데이터 행 계산 로직 ---
            is_first_table = r < sep_row1
            # 각 표의 마지막 줄이 '계' 행
            is_total_row = (r == sep_row1 - 1) or (r == sep_row2 - 1)
            
            # 엑셀은 1부터 시작하고, 헤더가 1행을 차지하므로 표의 첫 데이터행은 2행부터 시작
            excel_r = r + 2 
            
            # 엑셀 수식용 데이터 시작/끝 행번호 (SUM 범위용)
            if is_first_table:
                data_excel_start = 2
                data_excel_end = sep_row1 + 1 # '계' 행 바로 전까지 (엑셀 번호 기준)
            else:
                data_excel_start = data2_start_idx + 2
                data_excel_end = sep_row2 + 1

            for c in range(c0, c1 + 1):
                it = self.table.item(r, c)
                col_let = self.col_letter(c)
                
                # A. 누적차 열 수식 (정원 - 현원 + 복직자 누계)
                if c >= 2 and (c-2)%4 == 3 and not is_total_row:
                    m_base = 2 + ((c-2)//4)*4
                    # 엑셀 수식: =SUM(정원$시작:정원현재) - SUM(현원$시작:현원현재) + SUM(복직$시작:복직현재)
                    f_st = data_excel_start
                    formula = (f"=SUM({self.col_letter(m_base)}${f_st}:{self.col_letter(m_base)}{excel_r})-"
                               f"SUM({self.col_letter(m_base+1)}${f_st}:{self.col_letter(m_base+1)}{excel_r})+"
                               f"SUM({self.col_letter(m_base+2)}${f_st}:{self.col_letter(m_base+2)}{excel_r})")
                    row_data.append(formula)
                
                # B. '계' 행 수식
                elif is_total_row and c >= 2:
                    if (c-2)%4 == 3: 
                        # 누적차 계는 바로 윗 셀(별도직군 누계) 복사
                        row_data.append(f"={col_let}{excel_r-1}")
                    else: 
                        # 정원, 현원, 복직자는 세로 합계
                        row_data.append(f"=SUM({col_let}{data_excel_start}:{col_let}{excel_r-1})")
                
                # C. 일반 텍스트 및 숫자
                else:
                    txt = it.text().replace(',', '').replace('\n', ' ') if it else ""
                    # 엑셀에서 수식으로 오인되지 않게 처리
                    val = "'" + txt if txt.startswith(('-', '+', '=')) else txt
                    row_data.append(val)
            
            lines.append("\t".join(row_data))

        QApplication.clipboard().setText("\n".join(lines))

    def col_letter(self, n):
        """숫자 인덱스를 엑셀 열 문자(A, B, C...)로 변환"""
        res = ""
        while n >= 0:
            res = chr(n % 26 + 65) + res
            n = n // 26 - 1
        return res

        


        

    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
            
        self.table.blockSignals(True)
        affected_rows = set()
        affected_cols = set()

        # [기준 인덱스 설정] rank_count = 9 기준
        sep_row1 = rank_count           # 9
        title_row = sep_row1 + 1        # 10
        data2_start = title_row + 1     # 11
        sep_row2 = data2_start + rank_count # 20
        comment_row = sep_row2 + 1      # 21
        
        # 보호해야 할 행 리스트 (절대 값이 들어가면 안되는 곳)
        protected_rows = [sep_row1, title_row, sep_row2, comment_row]

        for i, line in enumerate(text.splitlines()):
            # 헤더 텍스트가 포함된 줄은 스킵
            if any(h in line for h in ["월", "정원", "현원", "복직", "직급", "구분"]): 
                continue
                
            cells = line.split('\t')
            for j, val in enumerate(cells):
                r, c = curr.row() + i, curr.column() + j
                
                if r < self.table.rowCount() and c < self.table.columnCount():
                    # --- [핵심 보호 로직] ---
                    # 1. 구분/직급 열 보호(0,1)
                    # 2. 누적차 열 보호(c-2 % 4 == 3)
                    # 3. 특수 행 보호(구분선, 제목줄 등)
                    if c < 2 or (c - 2) % 4 == 3 or r in protected_rows:
                        continue
                        
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable):
                        # 수식 기호(=) 제거 후 순수 숫자만 입력
                        clean_val = val.split('=')[-1] if '=' in val else val
                        it.setText(clean_val.strip())
                        affected_rows.add(r)
                        affected_cols.add(c)
                            
        self.table.blockSignals(False) 
        
        # --- [계산 트리거] ---
        if affected_rows and affected_cols:
            target_months = set()
            for col in affected_cols:
                if col >= 2:
                    target_months.add((col - 2) // 4)

            has_upper = any(r < sep_row1 for r in affected_rows)
            has_lower = any(r >= data2_start for r in affected_rows)

            for m_idx in sorted(list(target_months)):
                col_to_trigger = 2 + (m_idx * 4)
                # 첫 번째 표 합계 계산
                if has_upper:
                    upper_it = self.table.item(0, col_to_trigger)
                    if upper_it: self.calculate_s5(upper_it)
                # 두 번째 표 합계 계산 (data2_start인 11행을 정확히 타격)
                if has_lower:
                    lower_it = self.table.item(data2_start, col_to_trigger)
                    if lower_it: self.calculate_s5(lower_it)

            # 외부 연동을 위한 신호 발생
            first_affected_item = self.table.item(min(affected_rows), min(affected_cols))
            if first_affected_item:
                self.table.itemChanged.emit(first_affected_item)

                
                    

    def show_context_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #c0c0c0;
            }
            QMenu::item {
                padding: 6px 25px;
                color: black;
            }
            QMenu::item:selected {
                background-color: #5fa8f5;
                color: white;
            }
        """)

        menu.addAction("복사", self.copy_selection)
        menu.addAction("붙여넣기", self.paste_selection)
        menu.exec_(self.table.viewport().mapToGlobal(pos))

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
