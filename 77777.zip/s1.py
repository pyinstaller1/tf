import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QCursor, QPen






class S1ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val: return "0"
            try:
                clean_val = str(val).replace(',', '')
                return format(int(float(clean_val)), ",")
            except:
                return val
        return super().data(role)




# [1] 실시간 우측 정렬 및 기호 드로잉 델리게이트 (s1용 통합 버전)
class RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 생성 시 부모(TableWidget)를 이벤트 필터로 등록 (평소 상태 감시)
        if parent:
            parent.installEventFilter(self)

    def paint(self, painter, option, index):
        # 기존 기호 드로잉 로직 유지
        super().paint(painter, option, index)
        symbol = index.data(Qt.UserRole)
        if symbol:
            painter.save()
            font = painter.font()
            font.setPointSize(8)
            painter.setFont(font)
            painter.setPen(QColor(60, 60, 60))
            rect = option.rect
            painter.drawText(rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, symbol)
            painter.restore()

    def createEditor(self, parent, option, index):
        if not (index.flags() & Qt.ItemIsEditable):
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        
        # 실시간 콤마 포맷팅 유지
        editor.textChanged.connect(lambda text: self.format_text(editor, text))
        
        # 입력 중(에디터 활성화)일 때 키 감시를 위해 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # 데이터를 모델에 저장하기 위해 인덱스 변경
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나, 커서가 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나, 커서가 시작일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 인덱스만 변경 (자동 편집 제거)"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def format_text(self, editor, text):
        clean = text.replace(',', '')
        if not clean or clean == "-": return
        try:
            formatted = format(int(float(clean)), ",")
            if text != formatted:
                pos = editor.cursorPosition()
                old_len = len(text)
                editor.blockSignals(True)
                editor.setText(formatted)
                editor.setCursorPosition(pos + (len(formatted) - old_len))
                editor.blockSignals(False)
        except: pass

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)


        
        

class Sheet1Page(QWidget):

    def __init__(self, company, year, list_years2, list_years3, check_3_5, check_3_6, check_4, parent=None):        
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.very_light_gray = QColor(252, 252, 252)



        self.company = company
        self.year = year
        self.list_years2 = list_years2
        self.list_years3 = list_years3
        self.check_3_5 = check_3_5
        self.check_3_6 = check_3_6
        self.check_4 = check_4


        
        self.initUI()

        


        

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        title = QLabel("(2) 인건비 집계를 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(30, 7)
        self.table.setHorizontalHeaderLabels([
            "인건비 항목", "판관비", "영업외비용", "제조원가", "타계정대체", "이익잉여금", "합계"
        ])

        # 델리게이트 설정
        self.delegate = RightAlignedDelegate(self.table)
        for i in range(1, 7):
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        self.table.itemChanged.connect(self.calculate_s1)
        
        # 스타일 설정
        # self.table.setStyleSheet("QTableWidget { gridline-color: #d0d0d0; }")


        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section { 
                background-color: #f4f4f4; font-weight: bold; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal; 
            }
            QScrollBar:vertical { background: #f1f1f1; width: 14px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 14px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            
        """)


        
        self.table.setColumnWidth(0, 250)
        for i in range(1, 7): self.table.setColumnWidth(i, 128)
        
        layout.addWidget(self.table)






    def setup_content(self):
        self.table.blockSignals(True)



        if self.year=='2025':
            items = ['기본급', '인센티브 상여금', '그 외 상여금', '법정수당', '해외근무수당', '그 외 제수당', '퇴직급여(명예퇴직금 포함)', '임원 인건비', '비상임이사 인건비',
                     '인상률 제외 인건비', '기타항목', '급료,임금,제수당 소계ⓐ',  '사내근로복지기금출연금', '국민연금사용자부담분', '건강보험사용자부담분', '고용보험사용자부담분', '산재보험료사용자부담분',
                     '급식비', '교통보조비', '자가운전보조금', '학자보조금','건강진단비','선택적복지', '행사비', '포상품(비)', '기념품(비)', '격려품(비)', '장기근속관련 비용', '육아보조비 및 출산장려금', '자기계발비', '특별근로의 대가',
                     '피복비', '경로효친비', '통신비', '축하금/조의금', '기타 항목', '복리후생비 소계ⓑ', '일반 급여 (1)', '인센티브 상여금', '순액', '청년인턴 급여 (2)', '인센티브 상여금', '순액', '무기계약직 급여 (3)',
                     '인센티브 상여금', '순액', '소계 ⓒ=(1)+(2)+(3)', '인건비 총계: ⓓ=ⓐ+ⓑ+ⓒ', '인센티브 상여금 ⓔ=ⓔ-1+ⓔ-2', '인센티브 전환금 (ⓔ-1)', '인센티브 추가금 (ⓔ-2)', '인건비 해당금액 : ⓓ-ⓔ']
            self.readonly_rows = [11, 36, 37, 40, 43, 46, 47, 48, 51] # 파란 색 합계 행

            symbol_map = {
                6: "㈀",  # 퇴직급여
                7: "㈁",  # 임원
                8: "㈂",  # 비상임이사
                9: "㈃",  # 통상임금소송(인상률 제외 인건비)
                12: "㈄", # 사내근로복지기금
                13: "㈅", # 국민연금
                14: "㈅", # 건강보험
                15: "㈅", # 고용보험
                16: "㈅",  # 산재보험
                39: "㈆",  # 일반 급여 - 순액
                42: "㈇",  # 청년인턴 급여 - 순액
                45: "㈈",   # 무기계약직 급여 - 순액
     
            }

            multi_symbol_map = {
                47: {1: "(가)", 2: "(나)", 3: "(다)", 4: "(라)", 5: "(마)"},
                51: {1: "(바)", 2: "(사)", 3: "(아)", 4: "(자)", 5: "(차)"}
            }        



        if self.year in ['2024', '2023']:
            items = ['기본급', '인센티브 상여금', '그 외 상여금', '법정수당', '해외근무수당', '그 외 제수당', '퇴직급여(명예퇴직금 포함)', '임원 인건비', '비상임이사 인건비',
                     '인상률 제외 인건비(통상)', '인상률 제외 인건비(기타)', '기타항목', '급료,임금,제수당 소계ⓐ',  '사내근로복지기금출연금', '국민연금사용자부담분', '건강보험사용자부담분', '고용보험사용자부담분', '산재보험료사용자부담분',
                     '급식비', '교통보조비', '자가운전보조금', '학자보조금','건강진단비','선택적복지', '행사비', '포상품(비)', '기념품(비)', '격려품(비)', '장기근속관련 비용', '육아보조비 및 출산장려금', '자기계발비', '특별근로의 대가',
                     '피복비', '경로효친비', '통신비', '축하금/조의금', '기타 항목', '복리후생비 소계ⓑ', '일반 급여 (1)', '인센티브 상여금', '순액', '청년인턴 급여 (2)', '인센티브 상여금', '순액', '무기계약직 급여 (3)',
                     '인센티브 상여금', '순액', '소계 ⓒ=(1)+(2)+(3)', '인건비 총계: ⓓ=ⓐ+ⓑ+ⓒ', '인센티브 상여금 ⓔ=ⓔ-1+ⓔ-2', '인센티브 전환금 (ⓔ-1)', '인센티브 추가금 (ⓔ-2)', '인건비 해당금액 : ⓓ-ⓔ']
            self.readonly_rows = [12, 37, 38, 41, 44, 47, 48, 49, 52] # 파란 색 합계 행

            symbol_map = {
                6: "㈀",  # 퇴직급여
                7: "㈁",  # 임원
                8: "㈂",  # 비상임이사
                10: "㈃",  # 통상임금소송(인상률 제외 인건비)
                13: "㈄", # 사내근로복지기금
                14: "㈅", # 국민연금
                15: "㈅", # 건강보험
                16: "㈅", # 고용보험
                17: "㈅",  # 산재보험
                40: "㈆",  # 일반 급여 - 순액
                43: "㈇",  # 청년인턴 급여 - 순액
                46: "㈈",   # 무기계약직 급여 - 순액
     
            }

            multi_symbol_map = {
                48: {1: "(가)", 2: "(나)", 3: "(다)", 4: "(라)", 5: "(마)"},
                52: {1: "(바)", 2: "(사)", 3: "(아)", 4: "(자)", 5: "(차)"}
            }        





        
        self.table.setRowCount(len(items))



        
        
        soft_sky_blue = QColor(235, 245, 252)






        for r in range(len(items)):
            # 1. 항목명 결정 (items 리스트 범위를 벗어나면 빈 문자열)
            text = items[r] if r < len(items) else ""
            
            # A열 설정
            name_item = QTableWidgetItem(text)
            name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            
            # 항목 이름이 있는 행과 없는 행 구분 스타일링
            if r < len(items):
                if r in self.readonly_rows:
                    name_item.setBackground(soft_sky_blue)
                    name_item.setFont(QFont("Malgun Gothic", 9, QFont.Bold))
                else:
                    name_item.setBackground(Qt.white)
            else:
                # 53번 행 이후 (데이터가 없는 여백 행)
                name_item.setBackground(QColor(250, 250, 250)) # 아주 연한 회색 처리
                
            self.table.setItem(r, 0, name_item)

            # 데이터 열(1~6열) 설정
            for c in range(1, 7):
                cell = S1ThousandSeparatorItem("0")
                cell.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

                # 53번 행까지만 기존 로직 적용
                if r < len(items):
                    # 기존 수식 기호(symbol_map) 로직 유지
                    if 'multi_symbol_map' in locals() and r in multi_symbol_map and c in multi_symbol_map[r]:
                        cell.setData(Qt.UserRole, multi_symbol_map[r][c])
                    if c == 6 and 'symbol_map' in locals() and r in symbol_map:
                        cell.setData(Qt.UserRole, symbol_map[r])
                    
                    # 보호 및 색상 설정
                    if r in self.readonly_rows or c == 6:
                        cell.setBackground(soft_sky_blue)
                        cell.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    else:
                        cell.setBackground(Qt.white)
                        cell.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    # 여백 행 (100행까지의 나머지)
                    cell.setText("") # 숫자 0도 표시 안 함
                    cell.setBackground(QColor(250, 250, 250))
                    cell.setFlags(Qt.NoItemFlags) # 편집/선택 불가
                
                self.table.setItem(r, c, cell)

        self.table.blockSignals(False)





























    def calculate_s1(self, item):
        col = item.column()
        if col == 0 or col == 6: return 
        
        self.table.blockSignals(True)
        try:

            if self.year in ['2024', '2023']:
                # 2024년: 인상률 제외(기타) 추가로 인덱스 +1씩 Shift
                a, b, b_start = 12, 37, 13
                c1, c2, c3, c_sum = 38, 41, 44, 47
                d, e, e1, e2 = 48, 49, 50, 51
                res = 52
            else:
                # 2025년 기준 (기존 작성하신 로직의 인덱스)
                a, b, b_start = 11, 36, 12
                c1, c2, c3, c_sum = 37, 40, 43, 46
                d, e, e1, e2 = 47, 48, 49, 50
                res = 51

            def get_cell(r, c_idx=None):
                target_col = c_idx if c_idx is not None else col
                it = self.table.item(r, target_col)
                if not it or not it.text().strip(): return 0.0
                try: return float(it.text().replace(',', ''))
                except: return 0.0

            def update_cell(r, c, val, formula):
                it = self.table.item(r, c)
                if it:
                    it.setText(format(int(val), ","))
                    it.setData(Qt.UserRole + 1, formula)

            
            # 소계a: range(a) -> 24년은 12, 25년은 11
            val_a = sum(get_cell(r) for r in range(a))
            update_cell(a, col, val_a, f"=SUM(R[-{a}]C:R[-1]C)")

            # 소계b: b_start부터 b까지
            val_b = sum(get_cell(r) for r in range(b_start, b))
            update_cell(b, col, val_b, f"=SUM(R[-{b-b_start}]C:R[-1]C)")

            # 순액 계산: c1, c2, c3 좌표 활용
            update_cell(c1, col, get_cell(c1+1) + get_cell(c1+2), "=R[1]C+R[2]C")
            update_cell(c2, col, get_cell(c2+1) + get_cell(c2+2), "=R[1]C+R[2]C")
            update_cell(c3, col, get_cell(c3+1) + get_cell(c3+2), "=R[1]C+R[2]C")

            # 소계c: (1)+(2)+(3)
            val_c = get_cell(c1) + get_cell(c2) + get_cell(c3)
            # R1C1 수식도 상대 거리 자동 계산 (c1-c_sum 하면 -9 등 자동 산출)
            update_cell(c_sum, col, val_c, f"=R[{c1-c_sum}]C+R[{c2-c_sum}]C+R[{c3-c_sum}]C")

            # 총계d: a+b+c
            val_d = val_a + val_b + val_c
            update_cell(d, col, val_d, f"=R[{a-d}]C+R[{b-d}]C+R[{c_sum}]C")

            # 인센티브e: 아래 1, 2행
            val_e = get_cell(e1) + get_cell(e2)
            update_cell(e, col, val_e, "=R[1]C+R[2]C")

            # 최종 결과: d-e
            val_result = val_d - val_e
            update_cell(res, col, val_result, f"=R[{d-res}]C-R[{e-res}]C")

            # --- [가로 합계: G열 업데이트] ---
            # range(res + 1) 로 하면 마지막 행까지 완벽 커버
            for r in range(res + 1):
                row_sum = sum(get_cell(r, c_idx) for c_idx in range(1, 6))
                update_cell(r, 6, row_sum, "=SUM(RC[-5]:RC[-1])")

        except Exception as e:
            print(f"S1 Calc Error: {e}")
        finally:
            self.table.blockSignals(False)



            



    def get_data_to_s2(self):
        # 1. 연도별 참조 좌표 설정 (결벽증적 검증)
        if self.year in ['2024', '2023']:
            idx_main = 52       # 인건비 해당금액 (바~차)
            rows_sub = [6, 7, 8, 10, 13]  # ㈀퇴직, ㈁임원, ㈂비상임, ㈃인상률제외, ㈄복리후생기금
            rows_4dae = [14, 15, 16, 17] # ㈅ 4대보험 사용자부담분
            rows_net = [40, 43, 46]      # ㈆, ㈇, ㈈ 급여 순액들
        else: # 2025년 기준
            idx_main = 51
            rows_sub = [6, 7, 8, 9, 12]
            rows_4dae = [12, 13, 14, 15, 16] # 25년은 기금(12)부터 보험료까지 ㈄,㈅ 묶음 처리 확인 필요
            # ※ 25년 지침 확인 결과에 따라 rows_sub와 4대보험 범위를 미세 조정하세요.
            rows_4dae = [13, 14, 15, 16] # 일반적인 4대보험 범위
            rows_net = [39, 42, 45]

        def get_val(r, c):
            it = self.table.item(r, c)
            if not it or not it.text().strip(): return 0.0
            try: return float(it.text().replace(',', ''))
            except: return 0.0

        # --- 데이터 추출 시작 ---

        # 1. (바~차) 데이터: 최종 행의 1~5열 (판관비~이익잉여금)
        data_main = [get_val(idx_main, c) for c in range(1, 6)]

        # 2. (㈀~㈄) 데이터: 특정 행의 6열(합계열)
        data_sub = [get_val(r, 6) for r in rows_sub]

        # 3. (㈅)들의 합: 4대보험 합계 (6열 합산)
        sum_s_o_j = sum(get_val(r, 6) for r in rows_4dae)

        # 4. (㈆, ㈇, ㈈)의 합: 급여 순액들 (6열 합산)
        sum_b = sum(get_val(r, 6) for r in rows_net)

        # 모든 데이터를 하나의 리스트로 병합하여 반환
        return data_main + data_sub + [sum_s_o_j, sum_b]















































    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        # 1. 현재 연도에 따른 동적 인덱스 설정 (초격차 매핑)
        if self.year in ['2024', '2023']:
            a, b, b_start = 12, 37, 13
            c1, c2, c3, c_sum = 38, 41, 44, 47
            d, e, e1, e2 = 48, 49, 50, 51
            res = 52
        else:
            a, b, b_start = 11, 36, 12
            c1, c2, c3, c_sum = 37, 40, 43, 46
            d, e, e1, e2 = 47, 48, 49, 50
            res = 51

        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []

        for r in range(min_r, max_r + 1):
            row_data = []
            for c in range(min_c, max_c + 1):
                # --- [A. 가로 합계 열 (G열)] ---
                if c == 6:
                    formula = "=SUM(INDEX($1:$1048576, ROW(), COLUMN()-5):INDEX($1:$1048576, ROW(), COLUMN()-1))"
                    row_data.append(formula)
                
                # --- [B. 세로 소계/총계 행 (readonly_rows)] ---
                elif r in self.readonly_rows:
                    formula = "0"
                    if r == a: # 소계ⓐ
                        formula = f"=SUM(INDEX($1:$1048576, ROW()-{a}, COLUMN()):INDEX($1:$1048576, ROW()-1, COLUMN()))"
                    elif r == b: # 소계ⓑ
                        formula = f"=SUM(INDEX($1:$1048576, ROW()-{b-b_start+1}, COLUMN()):INDEX($1:$1048576, ROW()-1, COLUMN()))"
                    elif r in [c1, c2, c3, e]: # 순액 및 인센티브 합산
                        formula = "=INDEX($1:$1048576, ROW()+1, COLUMN())+INDEX($1:$1048576, ROW()+2, COLUMN())"
                    elif r == c_sum: # 소계ⓒ
                        formula = f"=INDEX($1:$1048576, ROW()-{c_sum-c1}, COLUMN())+INDEX($1:$1048576, ROW()-{c_sum-c2}, COLUMN())+INDEX($1:$1048576, ROW()-{c_sum-c3}, COLUMN())"
                    elif r == d: # 총계ⓓ
                        formula = f"=INDEX($1:$1048576, ROW()-{d-a}, COLUMN())+INDEX($1:$1048576, ROW()-{d-b}, COLUMN())+INDEX($1:$1048576, ROW()-{d-c_sum}, COLUMN())"
                    elif r == res: # 최종 인건비 해당금액
                        formula = f"=INDEX($1:$1048576, ROW()-{res-d}, COLUMN())-INDEX($1:$1048576, ROW()-{res-e}, COLUMN())"
                    
                    row_data.append(formula)

                # --- [C. 일반 데이터 입력 칸] ---
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else "0"
                    row_data.append(val)
            
            lines.append("\t".join(row_data))
        
        QApplication.clipboard().setText("\n".join(lines))


    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        r_s, c_s = curr.row(), curr.column()
        self.table.blockSignals(True)
        
        changed_columns = set() # 데이터가 변경된 열 번호를 저장할 집합
        
        lines = text.splitlines()
        for i, line in enumerate(lines):
            if not line.strip() and i > 0: continue
            
            cells = line.split('\t')
            for j, val in enumerate(cells):
                r, c = r_s + i, c_s + j
                
                if r < self.table.rowCount() and c < self.table.columnCount():
                    # 수정 차단 로직 (제목열, 합계열, 보호행)
                    if c == 0 or c == 6 or r in self.readonly_rows:
                        continue
                    
                    item = self.table.item(r, c)
                    if item and (item.flags() & Qt.ItemIsEditable):
                        clean_val = val.strip().replace(',', '')
                        item.setText(clean_val)
                        changed_columns.add(c) # 수정된 열 번호 기록

        for col_idx in changed_columns:
         # 각 열의 아무 아이템(여기서는 0행)이나 인자로 전달하여 계산 트리거
            self.calculate_s1(self.table.item(0, col_idx))
                        






    def contextMenuEvent(self, event):
        menu = QMenu(self)
        
        # 1. 'Fusion' 스타일을 강제 지정 (윈도우 기본 테마의 간섭을 무시함)
        menu.setStyle(QStyleFactory.create('Fusion'))
        
        # 2. 스타일시트에서 item과 item:selected를 모두 명시
        menu.setStyleSheet("""
            QMenu { background-color: white; border: 1px solid gray; }
            QMenu::item { padding: 5px 25px; color: black; }
            QMenu::item:selected { background-color: #0078d7; color: white; }
        """)
        
        cp = menu.addAction("복사 (Ctrl+C)")
        ps = menu.addAction("붙여넣기 (Ctrl+V)")
        
        # 사용자님이 요청하신 위치 방식 그대로 사용
        action = menu.exec_(QCursor.pos())
        
        if action == cp: 
            self.copy_selection()
        elif action == ps: 
            self.paste_selection()
            

    # --- [3] 엑셀 호환 복사/붙여넣기 및 키 이벤트 (s2 로직 계승) ---
    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C:
            self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V:
            self.paste_selection()
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter):
            curr_row = self.table.currentRow()
            if curr_row < self.table.rowCount() - 1:
                self.table.setCurrentCell(curr_row + 1, self.table.currentColumn())
        else:
            super().keyPressEvent(event)





# 만약 단독 실행 테스트를 원하시면 아래 코드를 추가하세요.
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Sheet1Page()
    window.resize(1000, 800)
    window.show()
    sys.exit(app.exec_())





















        
