from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont

class ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val or val == "n/a": return val
            try:
                clean_val = str(val).replace(',', '')
                # 인원이나 금액 모두 기본은 정수 콤마 표시
                return format(int(float(clean_val)), ",")
            except: return val
        return super().data(role)

class RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        # 보호 행: 제외합계(6), 기준보수(7), 총보수(8), 가중평균(13, 14)은 자동 계산
        protected = [6, 7, 8, 13, 14]
        if index.row() in protected or index.column() == 0:
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet18Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.target_light_blue = QColor(247, 250, 255)
        self.very_light_gray = QColor(252, 252, 252)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        title = QLabel("4. 기준보수")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        # 15개 항목 행
        self.table = QTableWidget(15, 2)
        self.table.setHorizontalHeaderLabels(["구분", "금액"])
        
        # 스타일 지침: 타이틀 바 및 구분선 스타일 통일
        self.table.verticalHeader().setFixedWidth(25)
        self.table.setColumnWidth(0, 450)
        self.table.setColumnWidth(1, 200)
        
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section { 
                background-color: #f4f4f4; font-weight: bold; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal; 
            }
        """)

        self.delegate = RightAlignedDelegate(self.table)
        self.table.setItemDelegateForColumn(1, self.delegate)

        self.setup_content()
        self.table.itemClicked.connect(self.handle_help_popup)
        self.table.itemChanged.connect(self.calculate_totals)
        
        layout.addWidget(self.table)

        # 주석 하단 추가 (요청하신 내용 100% 반영)
        footer_note = QLabel(
            "<font color='#555555'>"
            "<b>&lt;주1&gt;</b> 급료,임금,제수당 (가)와 제외항목은 (2)인건비 집계를 위한 Template 상의 각 항목과 일치하여야 함. (hwp 7페이지)<br>"
            "<b>&lt;주2&gt;</b> 예산운용지침상 한도를 초과하여 집행한 인센티브상여금은 제외함.<br>"
            "<b>&lt;주3&gt;</b> 법정수당은 법률을 근거로 지급하는 수당으로, 시간외근로수당 등을 포함함<br>"
            "<b>&lt;주4&gt;</b> 2025년도 연간 누적 총인원(사)는 (3-2)직급별 평균인원 계산을 위한 Template의 당년도 월별 인원(계)의 합계와 일치하여야 함.<br>"
            "<b>&lt;주8&gt;</b> 직무급 제도 도입 이후 기간의 누적 총인원(아)은 직무급 제도를 전직원에게 도입한 시점이 속한 달 이후 기간의 월별 인원(계)의 합계 (hwp 15페이지)"
            "</font>"
        )
        footer_note.setStyleSheet("margin-top: 5px; padding: 8px; background-color: #fcfcfc; border: 1px solid #eeeeee; line-height: 140%;")
        layout.addWidget(footer_note)

    def setup_content(self):
        self.table.blockSignals(True)
        rows = [
            "급료,임금,제수당 (가) <주1>", "제외항목 (인센티브 상여금) (라) <주2>", "제외항목 (법정수당) (마) <주3>",
            "제외항목 (퇴직급여)", "제외항목 (임원 인건비)", "제외항목 (비상임이사 인건비)",
            "▶ 제외항목 합계 (나)", "■ 기준보수(다) = (가) - (나)", "■ 총보수(바) = (다) + (라) + (마)",
            "2025년도 연간 누적 총인원(사) <주4>", "직무급 제도 도입 시점 (일부직원)", "직무급 제도 도입 시점 (전직원)",
            "직무급 제도 도입 이후 기간의 누적 총인원(아) <주8>", "◎ 가중평균 기준보수 ⓑ = (다) X (아) / (사)", "◎ 가중평균 총보수 ⓓ = (바) X (아) / (사)"
        ]

        for r, text in enumerate(rows):
            item_a = QTableWidgetItem(text)
            item_a.setBackground(self.very_light_gray)
            item_a.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            if any(mark in text for mark in ["▶", "■", "◎"]):
                item_a.setBackground(self.base_sky_blue)
                item_a.setFont(QFont("Malgun Gothic", 9, QFont.Bold))
            self.table.setItem(r, 0, item_a)

            # 도입 시점 텍스트 입력 칸(10, 11행)을 제외하고는 0 세팅
            val = "" if r in [10, 11] else "0"
            item_v = ThousandSeparatorItem(val) if r not in [10, 11] else QTableWidgetItem(val)
            item_v.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            
            if r in [6, 7, 8, 13, 14]: # 자동 계산 셀
                item_v.setBackground(self.target_light_blue)
                item_v.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(r, 1, item_v)
        self.table.blockSignals(False)

    def calculate_totals(self, item):
        if item.column() == 0: return
        self.table.blockSignals(True)
        try:
            def gv(r):
                it = self.table.item(r, 1)
                return float(it.text().replace(',', '')) if it and it.text() else 0.0

            # (나) 제외항목 합계 (1~5행 합산)
            val_na = sum(gv(r) for r in range(1, 6))
            self.table.item(6, 1).setText(str(int(val_na)))

            # (다) 기준보수 = (가) - (나)
            val_da = gv(0) - val_na
            self.table.item(7, 1).setText(str(int(val_da)))

            # (바) 총보수 = (다) + (라) + (마)  -> 라(1행), 마(2행)
            val_ba = val_da + gv(1) + gv(2)
            self.table.item(8, 1).setText(str(int(val_ba)))

            # (사) 총인원(9행), (아) 도입인원(12행)
            val_sa, val_ah = gv(9), gv(12)
            
            if val_sa != 0:
                # ⓑ = (다) * (아) / (사)
                self.table.item(13, 1).setText(str(int(val_da * val_ah / val_sa)))
                # ⓓ = (바) * (아) / (사)
                self.table.item(14, 1).setText(str(int(val_ba * val_ah / val_sa)))
                
        except: pass
        finally: self.table.blockSignals(False)

    def handle_help_popup(self, item):
        if item.column() != 0: return
        helps = {
            0: "<b>&lt;주1&gt;</b><br> 급료,임금,제수당 (가)와 제외항목은 (2)인건비 집계를 위한 Template 상의 각 항목과 일치하여야 함. (hwp 7페이지)",
            1: "<b>&lt;주2&gt;</b><br> 예산운용지침상 한도를 초과하여 집행한 인센티브상여금은 제외함.",
            2: "<b>&lt;주3&gt;</b><br> 법정수당은 법률을 근거로 지급하는 수당으로, 시간외근로수당 등을 포함함",
            9: "<b>&lt;주4&gt;</b><br> 2025년도 연간 누적 총인원(사)는 (3-2)직급별 평균인원 계산을 위한 Template의 당년도 월별 인원(계)의 합계와 일치하여야 함. (hwp 15페이지)",
            12: "<b>&lt;주8&gt;</b><br> 직무급 제도 도입 이후 기간의 누적 총인원(아)은 (3-2)직급별 평균인원 계산을 위한 Template 중 직무급 제도를 전직원에게 도입한 시점이 속한 달 이후 기간의 월별 인원(계)의 합계 (hwp 15페이지)"
        }
        row = item.row()
        if row in helps:
            QMessageBox.information(self, "항목 상세 설명", f"<b>[{item.text()}]</b><br><br>{helps[row]}")

    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사")
        paste_action = menu.addAction("붙여넣기")
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action: self.copy_selection()
        elif action == paste_action: self.paste_selection()

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        lines = []
        header_labels = [self.table.horizontalHeaderItem(c).text() for c in range(min_c, max_c + 1)]
        lines.append("\t".join(header_labels))

        for r in range(min_r, max_r + 1):
            row_data = []
            for c in range(min_c, max_c + 1):
                item = self.table.item(r, c)
                text = item.text() if item else ""
                if c == 1:
                    ex_r = r + 2
                    # 엑셀용 수식 적용 (B열 기준)
                    formulas = {
                        6: "=SUM(B3:B7)", # 제외합계
                        7: "=B2-B8",      # 기준보수 (가-나)
                        8: "=B9+B3+B4",   # 총보수 (다+라+마)
                        13: "=B9*B14/B11", # b = 다*아/사
                        14: "=B10*B14/B11" # d = 바*아/사
                    }
                    text = formulas.get(r, text.replace(',', ''))
                row_data.append(text)
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        clipboard = QApplication.clipboard().text()
        if not clipboard: return
        rows = clipboard.split('\n')
        current = self.table.currentItem()
        if not current: return
        self.table.blockSignals(True)
        for i, row_text in enumerate(rows):
            if "\t" not in row_text: continue
            cols = row_text.split('\t')
            for j, col_text in enumerate(cols):
                r, c = current.row()+i, current.column()+j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    if c == 1 and r not in [6, 7, 8, 13, 14]:
                        item = self.table.item(r, c)
                        if item: item.setData(Qt.EditRole, col_text.strip().replace(',', ''))
        self.table.blockSignals(False)
        self.calculate_totals(current)
