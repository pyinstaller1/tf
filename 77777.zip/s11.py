from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QKeySequence, QFont


rank_count = 8

# S5와 동일한 Delegate 및 Item 클래스 유지
class s11RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor
    def setModelData(self, editor, model, index):
        model.setData(index, editor.text().replace(',', ''), Qt.EditRole)

class s11ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                num = float(str(val).replace(',', ''))
                return format(int(num), ",") if num == int(num) else format(num, ",.2f")
            except: return val
        return super().data(role)

class Sheet11Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent

        global rank_count
        rank_count = len(self.main_window.list_title_11)


        
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-5) 가. 별도직군 승진시기 차이에 따른 인건비 효과 조정을 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        # 행: 표1(8) + 공백(1) + 표2제목(1) + 표2(8) = 총 18행
        # 열: 구분(1) + 직급(1) + (3개항목 * 6개월) = 20열
        self.table = QTableWidget((rank_count*2)+4, 20)
        self.setup_style()
        self.setup_headers()
        self.setup_content()

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        delegate = s11RightAlignedDelegate(self.table)
        for c in range(2, 20):
            self.table.setItemDelegateForColumn(c, delegate)

        self.table.itemChanged.connect(self.calculate_s11)
        layout.addWidget(self.table)

        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertical { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
        """)




    def setup_style(self):
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.verticalHeader().setFixedWidth(25)
        







    def setup_headers(self):
        h_labels = ["구분", "직급"]
        for m in range(1, 7):
            for sub in ["당해전환", "근속승진", "승진TO"]:
                h_labels.append(f"{m}월\n{sub}")
        self.table.setHorizontalHeaderLabels(h_labels)
        self.table.horizontalHeader().setFixedHeight(45)
        
        self.table.setColumnWidth(0, 30) 
        self.table.setColumnWidth(1, 60)
        for c in range(2, 20): self.table.setColumnWidth(c, 65)




    def create_row_items(self, row, rank):
        bold_font = QFont(); bold_font.setBold(True)
        it_rank = QTableWidgetItem(rank)
        it_rank.setTextAlignment(Qt.AlignCenter)
        it_rank.setBackground(self.base_sky_blue)
        it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        if rank == "계": it_rank.setFont(bold_font)
        self.table.setItem(row, 1, it_rank)

        for c in range(2, 20):
            it = s11ThousandSeparatorItem("0")
            it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            
            # --- [수정된 로직] ---
            # 1. 근속승진 열 (3, 6, 9, 12, 15, 18열) -> S5 연동 (노란색, 수정불가)
            if (c - 3) % 3 == 0 and rank != "계":
                it.setBackground(QColor(255, 255, 225)) # 노란색
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 연동용 (수정불가)

            # 2. 승진TO 열 (4, 7, 10...열) 또는 '계' 행 -> 자동합계/결과 (하늘색, 수정불가)
            elif (c - 4) % 3 == 0 or rank == "계":
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                it.setBackground(self.base_sky_blue)
                it.setFont(bold_font)

            # 3. 당해전환 열 (2, 5, 8, 11, 14, 17열) -> 사용자가 직접 입력 (흰색, 수정가능)
            else:
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                it.setBackground(Qt.white)
            
            self.table.setItem(row, c, it)

    def cell_value(self, r, c):
        it = self.table.item(r, c)
        if not it: return 0.0
        try: return float(it.text().replace(',', ''))
        except: return 0.0







    def setup_content(self):
        self.table.blockSignals(True)
        
        # main_window의 실제 리스트 참조
        self.ranks = self.main_window.list_title_11
        
        # 전체 행 수 설정 (직급수 * 2 + 4)
        self.table.setRowCount((rank_count * 2) + 4)

        # [1] 첫 번째 표 (1~6월)
        year_item1 = QTableWidgetItem("당\n년\n도")
        year_item1.setTextAlignment(Qt.AlignCenter)
        year_item1.setBackground(QColor(245, 245, 245))
        year_item1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(0, 0, year_item1)
        self.table.setSpan(0, 0, rank_count, 1)

        for r, rank in enumerate(self.ranks):
            self.create_row_items(r, rank)
        
        self.table.setRowHeight(rank_count, 15) # 첫 번째 구분선 (기존 9)

        # [2] 두 번째 표 제목줄 (7~12월 헤더)
        h_font = QFont(); h_font.setBold(True)
        for c in range(20):
            it = QTableWidgetItem()
            it.setBackground(QColor(240, 240, 240))
            it.setFont(h_font)
            it.setTextAlignment(Qt.AlignCenter)
            if c == 0: it.setText("구분")
            elif c == 1: it.setText("직급")
            else:
                m = 7 + (c-2)//3
                sub = ["당해전환", "근속승진", "승진TO"][(c-2)%3]
                it.setText(f"{m}월\n{sub}")
            self.table.setItem(rank_count + 1, c, it) # 기존 10
        self.table.setRowHeight(rank_count + 1, 45)

        # [3] 두 번째 표 데이터 (7~12월)
        year_item2 = QTableWidgetItem("당\n년\n도")
        year_item2.setTextAlignment(Qt.AlignCenter)
        year_item2.setBackground(QColor(245, 245, 245))
        year_item2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(rank_count + 2, 0, year_item2) # 기존 11
        self.table.setSpan(rank_count + 2, 0, rank_count, 1)

        for r, rank in enumerate(self.ranks):
            self.create_row_items(rank_count + 2 + r, rank) # 기존 11 + r
            
        self.table.setRowHeight((rank_count * 2) + 2, 15) # 두 번째 구분선 (기존 20)

        # [4] 주석
        note_text = (
            "가. 별도직군 승진 가능 인원(승진T.O) 계산: 승진 T.O = 당해 전환 – min(당해 전환, 근속승진)\n"
            " * '승진T.O'는 직급별 누적차가 음수인 경우 영(0)을 한도로 하고, 양수인 경우 해당 누적차에서 승진(누적)의 합을 한도로 한다."
        )
        note_item = QTableWidgetItem(note_text)
        note_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem((rank_count * 2) + 3, 0, note_item) # 기존 21
        self.table.setSpan((rank_count * 2) + 3, 0, 1, 20)
        self.table.setRowHeight((rank_count * 2) + 3, 50)
        
        self.table.blockSignals(False)






    def calculate_s11(self, item):
        r, c = item.row(), item.column()
        
        # [수정] 제목줄, 구분선, 주석 제외 (하드코딩 제거 및 직관적 수식)
        if c < 2 or (c - 2) % 3 == 2 or r in [rank_count, rank_count + 1, (rank_count * 2) + 2, (rank_count * 2) + 3]:
            return
        
        self.table.blockSignals(True)
        try:
            month_base = 2 + ((c - 2) // 3) * 3
            
            # [수정] 상단/하단 표 판단에 따른 루프 범위 직접 지정
            if r < rank_count:
                # 상단 표: 0부터 rank_count-1(계) 직전까지 계산
                for row in range(0, rank_count - 1):
                    val_transfer = self.cell_value(row, month_base)
                    val_promotion = self.cell_value(row, month_base + 1)
                    res = val_transfer - min(val_transfer, val_promotion)
                    
                    if self.table.item(row, month_base + 2):
                        self.table.item(row, month_base + 2).setData(Qt.EditRole, int(res))

                # 세로 합계 (계 행: rank_count - 1)
                for col in range(month_base, month_base + 3):
                    v_sum = sum(self.cell_value(i, col) for i in range(rank_count - 1))
                    if self.table.item(rank_count - 1, col):
                        self.table.item(rank_count - 1, col).setData(Qt.EditRole, int(v_sum))
            else:
                # 하단 표: rank_count+2부터 마지막 '계' 직전까지 계산
                for row in range(rank_count + 2, (rank_count * 2) + 1):
                    val_transfer = self.cell_value(row, month_base)
                    val_promotion = self.cell_value(row, month_base + 1)
                    res = val_transfer - min(val_transfer, val_promotion)
                    
                    if self.table.item(row, month_base + 2):
                        self.table.item(row, month_base + 2).setData(Qt.EditRole, int(res))

                # 세로 합계 (계 행: rank_count * 2 + 1)
                for col in range(month_base, month_base + 3):
                    v_sum = sum(self.cell_value(rank_count + 2 + i, col) for i in range(rank_count - 1))
                    if self.table.item((rank_count * 2) + 1, col):
                        self.table.item((rank_count * 2) + 1, col).setData(Qt.EditRole, int(v_sum))


             
        finally: 
            self.table.blockSignals(False)
            self.send_to_s12()



    def sync_from_s5(self, s5_data):
        if not s5_data: return
        self.table.blockSignals(True)
        try:
            for r in range(len(s5_data)):
                # 상단 표 (1~6월)
                for m in range(0, 6):
                    val = s5_data[r][m]
                    converted_val = abs(val) if val < 0 else 0.0
                    
                    # target_col: 2(당해전환) -> 3(근속승진)으로 변경
                    target_col = 2 + (m * 3) + 1 
                    if r < rank_count - 1:
                        item = self.table.item(r, target_col)
                        if item: item.setData(Qt.EditRole, round(converted_val, 2))

                # 하단 표 (7~12월)
                for m in range(6, 12):
                    val = s5_data[r][m]
                    converted_val = abs(val) if val < 0 else 0.0
                    
                    # target_col: 근속승진 위치로 변경
                    target_col = 2 + ((m-6) * 3) + 1
                    target_row = rank_count + 2 + r
                    if target_row < self.table.rowCount():
                        item = self.table.item(target_row, target_col)
                        if item: item.setData(Qt.EditRole, round(converted_val, 2))

            # 계산 업데이트 (첫 번째 당해전환 셀 기준 호출)
            if self.table.item(0, 2):
                self.calculate_s11(self.table.item(0, 2))
        finally:
            self.table.blockSignals(False)
            


    def send_to_s12(self):
        """Sheet12로 전달할 승진TO 데이터(8직급 x 12개월)를 추출하여 리턴"""
        result = [[0.0 for _ in range(12)] for _ in range(rank_count)]

        for r in range(rank_count):
            # 상반기 (1~6월)
            for m in range(6):
                col = 4 + (m * 3) 
                result[r][m] = self.cell_value(r, col)
            
            # 하반기 (7~12월)
            for m in range(6, 12):
                col = 4 + ((m - 6) * 3)
                row = rank_count + 2 + r
                result[r][m] = self.cell_value(row, col)

        # print(result)
        
        return result # 데이터를 밖으로 던져줌



    def copy_selection(self):
        ranges = self.table.selectedRanges()
        if not ranges: return
        r0, r1 = min(r.topRow() for r in ranges), max(r.bottomRow() for r in ranges)
        c0, c1 = min(r.leftColumn() for r in ranges), max(r.rightColumn() for r in ranges)
        lines = []
        
        # [1] 상단 헤더 복사
        if r0 == 0:
            h_row = []
            for c in range(c0, c1 + 1):
                h_item = self.table.horizontalHeaderItem(c)
                h_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(h_row))

        for r in range(r0, r1 + 1):
            # [수정] 구분선 및 헤더 행 판정 (rank_count 기반 직계 수식)
            if r in [rank_count, rank_count + 1, (rank_count * 2) + 2]:
                row_data = []
                for c in range(c0, c1 + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data)); continue

            # [수정] 주석 행 판정
            if r == (rank_count * 2) + 3:
                it = self.table.item(r, 0)
                val = it.text().strip() if it else ""
                lines.append(val + "\t" * (c1 - c0)); continue

            row_data = []
            is_first_table = r < rank_count
            # [수정] 합계 행 여부: 첫 번째 표의 마지막(rank_count-1) 또는 두 번째 표의 마지막(rank_count*2 + 1)
            is_total_row = (r == rank_count - 1 or r == (rank_count * 2) + 1)
            
            # 엑셀은 1행이 헤더이므로 데이터는 2행부터 시작 (r + 2)
            excel_r = r + 2
            
            # [수정] 엑셀 SUM 수식 범위 자동 계산 (중간 변수 없이 직접 할당)
            # 표1 시작: 2행 / 끝: rank_count (엑셀 기준)
            # 표2 시작: rank_count + 4행 / 끝: rank_count * 2 + 2행 (엑셀 기준)
            ex_start = 2 if is_first_table else rank_count + 4
            ex_end = rank_count if is_first_table else (rank_count * 2) + 2

            for c in range(c0, c1 + 1):
                col_let = self.col_letter(c)
                # 승진TO 수식: =당해전환-근속승진
                if c >= 2 and (c-2)%3 == 2 and not is_total_row:
                    c1_let = self.col_letter(c-2)
                    c2_let = self.col_letter(c-1)
                    row_data.append(f"={c1_let}{excel_r}-{c2_let}{excel_r}")
                # 합계 수식: SUM 범위 지정
                elif is_total_row and c >= 2:
                    row_data.append(f"=SUM({col_let}{ex_start}:{col_let}{ex_end})")
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').replace('\n', ' ') if it else ""
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            # 헤더나 구분 문자 포함 시 건너뜀
            if any(kw in line for kw in ["월", "직급", "가.", "나."]): continue
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    # 수정 가능한 셀에만 데이터 입력
                    if it and (it.flags() & Qt.ItemIsEditable):
                        it.setText(val.split('=')[-1] if '=' in val else val)
        self.table.blockSignals(False)
        self.calculate_s11(curr)





    def col_letter(self, idx):
        return chr(65 + idx)


















    def show_context_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #c0c0c0;
            }
            QMenu::item {
                padding: 6px 25px;
                color: black;
            }
            QMenu::item:selected {
                background-color: #5fa8f5;
                color: white;
            }
        """)

        menu.addAction("복사", self.copy_selection)
        menu.addAction("붙여넣기", self.paste_selection)
        menu.exec_(self.table.viewport().mapToGlobal(pos))


    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
