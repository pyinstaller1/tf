from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QKeySequence, QFont
import re


rank_count = 8

class s12ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                num = float(str(val).replace(',', ''))
                return format(int(num), ",") if num == int(num) else format(num, ",.2f")
            except: return val
        return super().data(role)

class Sheet12Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent

        global rank_count
        rank_count = len(self.main_window.list_title_12)

        self.base_yellow = QColor(255, 255, 225) # 연한 노랑
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-5) 나. 별도직군 승진 가능 인원 내 미승진자 인원 계산")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        # 구분(1) + 직급(1) + (4항목 * 6개월) = 26열
        self.table = QTableWidget((rank_count * 2) + 4, 26)
        self.setup_style()
        self.setup_headers()
        self.setup_content()

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        self.table.itemChanged.connect(self.calculate_s12)
        layout.addWidget(self.table)

        # 제목바 및 행번호 열 스타일 (저장된 정보 준수)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertical { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
        """)

    def setup_style(self):
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.verticalHeader().setFixedWidth(25)

    def setup_headers(self):
        h_labels = ["구분", "직급"]
        for m in range(1, 7):
            h_labels.append(f"{m}월\n승진TO")
            h_labels.append(f"{m}월\n승진")
            h_labels.append("전년말\n미승진") # 월 표시 없음
            h_labels.append(f"{m}월\n미승진자")
        self.table.setHorizontalHeaderLabels(h_labels)
        self.table.horizontalHeader().setFixedHeight(45)
        self.table.setColumnWidth(0, 30); self.table.setColumnWidth(1, 60)
        for c in range(2, 26): self.table.setColumnWidth(c, 65)






    def create_row_items(self, row, rank):
        bold_f = QFont(); bold_f.setBold(True)
        it_rank = QTableWidgetItem(rank); it_rank.setTextAlignment(Qt.AlignCenter)
        it_rank.setBackground(self.base_sky_blue); it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(row, 1, it_rank)
        
        for c in range(2, 26):
            it = s12ThousandSeparatorItem("0"); it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            
            col_type = (c - 2) % 4 # 0:TO, 1:승진, 2:전년말, 3:미승진자
            
            # 1. 미승진자 열(3) 이거나 '계' 행인 경우 (기존 유지 + 하늘색)
            if col_type == 3 or rank == "계":
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                it.setBackground(self.base_sky_blue)
                it.setFont(bold_f)
                
            # 2. [추가] 승진TO(0) 또는 전년말 미승진(2) 열인 경우 (노란색 + 수정불가)
            elif col_type == 0 or col_type == 2:
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                it.setBackground(self.base_yellow)
            
            # 3. 그 외 (승진 열 등)는 편집 가능 (기존 유지)
            else:
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                
            self.table.setItem(row, c, it)











    def setup_content(self):
        self.table.blockSignals(True)
        # 1. main_window에서 가져온 리스트 사용
        self.ranks = self.main_window.list_title_12
        
        # [수정] rank_count 기준 전체 행 수 자동 계산
        total_rows = (rank_count * 2) + 4
        self.table.setRowCount(total_rows)

        # [상반기] 0 ~ rank_count-1
        y1 = QTableWidgetItem("당\n년\n도"); y1.setTextAlignment(Qt.AlignCenter)
        y1.setBackground(QColor(245, 245, 245))
        y1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 수정 불가 추가
        self.table.setItem(0, 0, y1)
        self.table.setSpan(0, 0, rank_count, 1)

        for r, rank in enumerate(self.ranks): 
            self.create_row_items(r, rank)
        
        # --- 첫 번째 구분선: rank_count 위치 ---
        self.table.setRowHeight(rank_count, 15)
        for c in range(26):
            empty_it = QTableWidgetItem("")
            empty_it.setFlags(Qt.NoItemFlags) # 완전히 비활성화
            self.table.setItem(rank_count, c, empty_it)

        # --- [하반기 제목줄]: rank_count + 1 위치 ---
        h_f = QFont(); h_f.setBold(True)
        for c in range(26):
            it = QTableWidgetItem()
            it.setBackground(QColor(240, 240, 240)); it.setFont(h_f); it.setTextAlignment(Qt.AlignCenter)
            it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 헤더 수정 불가
            if c == 0: it.setText("구분")
            elif c == 1: it.setText("직급")
            else:
                m, idx = 7 + (c - 2) // 4, (c - 2) % 4
                labels = ["승진TO", "승진", "전년말\n미승진", "미승진자"]
                it.setText(f"{m}월\n{labels[idx]}" if idx != 2 else labels[idx])
            self.table.setItem(rank_count + 1, c, it)
        self.table.setRowHeight(rank_count + 1, 45)

        # [하반기 데이터]: rank_count + 2 위치부터 rank_count개
        y2 = QTableWidgetItem("당\n년\n도"); y2.setTextAlignment(Qt.AlignCenter)
        y2.setBackground(QColor(245, 245, 245))
        y2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 수정 불가 추가
        self.table.setItem(rank_count + 2, 0, y2)
        self.table.setSpan(rank_count + 2, 0, rank_count, 1)

        for r, rank in enumerate(self.ranks): 
            self.create_row_items(rank_count + 2 + r, rank)

        # --- 두 번째 구분선: (rank_count * 2) + 2 ---
        self.table.setRowHeight((rank_count * 2) + 2, 15)
        for c in range(26):
            empty_it2 = QTableWidgetItem("")
            empty_it2.setFlags(Qt.NoItemFlags)
            self.table.setItem((rank_count * 2) + 2, c, empty_it2)

        # --- 주석: (rank_count * 2) + 3 ---
        note_text = " * 미승진자 = 승진 T.O – min{ 승진 T.O , max(0, 승진 – 전년도말 미승진) }\n * 노란색 셀은 타 시트 연계 항목으로 수동 수정을 제한합니다."
        n_it = QTableWidgetItem(note_text)
        n_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 주석 수정 불가
        n_it.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.table.setItem((rank_count * 2) + 3, 0, n_it)
        self.table.setSpan((rank_count * 2) + 3, 0, 1, 26)
        self.table.setRowHeight((rank_count * 2) + 3, 40)
        
        self.table.blockSignals(False)



        

    def calculate_s12(self, item):
        r, c = item.row(), item.column()
        # [수정] 수식 기반 제외 행 판정
        if c < 2 or (c - 2) % 4 == 3 or r in [rank_count, rank_count + 1, (rank_count * 2) + 2, (rank_count * 2) + 3]:
            return
        
        self.table.blockSignals(True)
        try:
            m_base = 2 + ((c - 2) // 4) * 4
            # [수정] 상/하단 표 시작점과 계(total) 행을 rank_count로 직결
            start_r = 0 if r < rank_count else rank_count + 2
            total_row = start_r + rank_count - 1 # 각 표의 마지막 '계' 행
            
            # 1. 미승진자 계산 (계 행 직전까지)
            for row in range(start_r, total_row):
                to = self.get_val(row, m_base)
                prom = self.get_val(row, m_base + 1)
                prev = self.get_val(row, m_base + 2)
                res = to - min(to, max(0, prom - prev))
                
                res_it = self.table.item(row, m_base + 3)
                if res_it: res_it.setData(Qt.EditRole, int(res))
            
            # 2. 세로 합계
            for col in range(m_base, m_base + 4):
                v_sum = sum(self.get_val(start_r + i, col) for i in range(rank_count - 1))
                s_it = self.table.item(total_row, col)
                if s_it: s_it.setData(Qt.EditRole, int(v_sum))
        finally: 
            self.table.blockSignals(False)



    def get_from_s11(self, s11_data):
        """Sheet11로부터 데이터를 수신하여 승진TO 열(노란색 셀) 갱신"""
        if not s11_data: return
        
        self.table.blockSignals(True)
        try:
            for r in range(len(s11_data)):
                # 상반기 업데이트 (Sheet12 승진TO: 2, 6, 10, 14, 18, 22열)
                for m in range(6):
                    target_col = 2 + (m * 4)
                    if r < rank_count:
                        it = self.table.item(r, target_col)
                        if it: it.setData(Qt.EditRole, int(s11_data[r][m]))

                # 하반기 업데이트 (Sheet12 하단 시작: rank_count + 2)
                for m in range(6, 12):
                    target_col = 2 + ((m - 6) * 4)
                    target_row = rank_count + 2 + r
                    if target_row < self.table.rowCount():
                        it = self.table.item(target_row, target_col)
                        if it: it.setData(Qt.EditRole, int(s11_data[r][m]))
            
            # 데이터 채운 후 미승진자(Sheet12 로직) 재계산
            first_it = self.table.item(0, 2)
            if first_it:
                self.calculate_s12(first_it)
                
        finally:
            self.table.blockSignals(False)




    def get_from_s13(self, s13_data):
        """S13에서 받은 전년말 데이터를 S12의 모든 '전년말 미승진' 열에 입력"""
        if not s13_data: return
        
        self.table.blockSignals(True)
        try:
            # S12의 전년말 미승진 열 인덱스들: 4, 8, 12 (상반기) / 4, 8, 12 (하반기 동일)
            target_cols = [4, 8, 12, 16, 20, 24]
            
            for r_idx, val in enumerate(s13_data):
                # 1. 상반기 (0 ~ rank_count-2)
                for c in target_cols:
                    it_up = self.table.item(r_idx, c)
                    if it_up: it_up.setData(Qt.EditRole, int(val))
                
                # 2. 하반기 (rank_count+2 ~ rank_count*2)
                for c in target_cols:
                    target_row = rank_count + 2 + r_idx
                    if target_row < self.table.rowCount():
                        it_down = self.table.item(target_row, c)
                        if it_down: it_down.setData(Qt.EditRole, int(val))
            
            # 데이터 입력 후 S12 전체 재계산 트리거
            first_it = self.table.item(0, 2)
            if first_it: self.calculate_s12(first_it)
            
        finally:
            self.table.blockSignals(False)
            self.table.viewport().update()












    def copy_selection(self):
        ranges = self.table.selectedRanges()
        if not ranges: return
        r0, r1 = min(r.topRow() for r in ranges), max(r.bottomRow() for r in ranges)
        c0, c1 = min(r.leftColumn() for r in ranges), max(r.rightColumn() for r in ranges)
        lines = []

        # [1] 헤더 복사
        if r0 == 0:
            h_row = []
            for c in range(c0, c1 + 1):
                h_item = self.table.horizontalHeaderItem(c)
                h_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(h_row))

        for r in range(r0, r1 + 1):
            # [수정] 구분선(rank_count), 하반기 헤더(rank_count+1), 두번째 구분선(rank_count*2 + 2)
            if r in [rank_count, rank_count + 1, (rank_count * 2) + 2]:
                row_data = []
                for c in range(c0, c1 + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data)); continue

            # [수정] 주석 행 (rank_count*2 + 3)
            if r == (rank_count * 2) + 3:
                it = self.table.item(r, 0)
                val = it.text().strip() if it else ""
                lines.append(val + "\t" * (c1 - c0)); continue

            row_data = []
            is_first_table = r < rank_count
            # [수정] 합계 행: 상반기 끝(rank_count-1), 하반기 끝(rank_count*2 + 1)
            is_total_row = (r == rank_count - 1 or r == (rank_count * 2) + 1)
            
            excel_r = r + 2 
            
            # [수정] 데이터 시작/끝 행 자동 계산 (엑셀 기준)
            # 상반기: 2행 ~ rank_count행
            # 하반기: rank_count + 4행 ~ rank_count*2 + 2행
            data_start_r = 2 if is_first_table else rank_count + 4
            data_end_r = rank_count if is_first_table else (rank_count * 2) + 2

            for c in range(c0, c1 + 1):
                col_let = self.get_excel_col(c)
                
                # 미승진자 수식 (4열 간격)
                if c >= 2 and (c - 2) % 4 == 3 and not is_total_row:
                    c_to = self.get_excel_col(c - 3)
                    c_prom = self.get_excel_col(c - 2)
                    c_prev = self.get_excel_col(c - 1)
                    # 공식: TO - MIN(TO, MAX(0, 승진-전년말))
                    val = f"={c_to}{excel_r}-MIN({c_to}{excel_r}, MAX(0, {c_prom}{excel_r}-{c_prev}{excel_r}))"
                
                # 합계 수식
                elif is_total_row and c >= 2:
                    val = f"=SUM({col_let}{data_start_r}:{col_let}{data_end_r})"
                
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').replace('\n', ' ') if it else ""
                    if val.startswith(('=', '-', '+')): val = "'" + val
                
                row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))






    def get_excel_col(self, n):
        res = ""
        n += 1
        while n > 0:
            n, rem = divmod(n - 1, 26)
            res = chr(65 + rem) + res
        return res
        



    def get_val(self, r, c):
        it = self.table.item(r, c)
        if not it: return 0.0
        try: return float(re.sub(r'[^\d.-]', '', it.text()))
        except: return 0.0

    def show_context_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #c0c0c0;
            }
            QMenu::item {
                padding: 6px 25px;
                color: black;
            }
            QMenu::item:selected {
                background-color: #5fa8f5;
                color: white;
            }
        """)

        menu.addAction("복사", self.copy_selection)
        menu.addAction("붙여넣기", self.paste_selection)
        menu.exec_(self.table.viewport().mapToGlobal(pos))





    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable):
                        # 엑셀의 수식 결과값에서 숫자만 추출하여 입력
                        it.setText(re.sub(r'[^\d.-]', '', val))
        self.table.blockSignals(False)
        self.calculate_s12(curr)
