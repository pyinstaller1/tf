from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

rank_count = 8

class S13RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor
    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)



class S13ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                num = float(str(val).replace(',', ''))
                col = self.column()
                
                # 평균인원 열(14) 및 우측 하단 합계 -> 소수점 1자리
                if col == 14:
                    return format(num, ",.1f")
                
                # 일반 월별 데이터 열(2~13) -> 소수점 2자리 (정수면 콤마만)
                if num == int(num):
                    return format(int(num), ",")
                else:
                    return format(num, ",.2f")
            except:
                return val
        return super().data(role)


class Sheet13Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent

        global rank_count
        rank_count = len(self.main_window.list_title_13)
        
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-5) 다. 미승진자 평균인원")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)        

        self.table = QTableWidget((rank_count * 2) + 4, 15)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # [수정] S7과 동일한 얇은 실선 스타일로 원복 (두꺼운 선 제거)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section:horizontal {
                background-color: #f4f4f4; padding: 2px; 
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; padding-left: 5px; padding-right: 5px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)

        headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["평균인원"]
        self.table.setHorizontalHeaderLabels(headers)
        self.table.verticalHeader().setFixedWidth(25)
        self.table.verticalHeader().setDefaultSectionSize(26)

        self.delegate = S13RightAlignedDelegate(self.table)
        for i in range(2, 15):
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 50)
        self.table.setColumnWidth(14, 70)

        self.table.itemChanged.connect(self.calculate_s13)
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        # 1. 메인 윈도우의 리스트와 전역 rank_count 사용
        ranks = self.main_window.list_title_13
        full_headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["평균인원"]
        
        # [직결] 전체 행 수 재계산 (기존 22 -> 가변)
        # 전년도(rank_count) + 구분선(1) + 제목(1) + 당년도(rank_count) + 구분선(1) + 주석(1)
        total_rows = (rank_count * 2) + 4
        self.table.setRowCount(total_rows)

        for r in range(total_rows):
            for c in range(15):
                # 특수 행 좌표 직결 (9 -> rank_count, 10 -> rank_count + 1 등)
                if r in [rank_count, rank_count * 2 + 2]: # 구분선
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags); item.setBackground(Qt.white)
                elif r == rank_count + 1: # 중간제목
                    item = QTableWidgetItem(full_headers[c])
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setBackground(QColor(244, 244, 244))
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    f = item.font(); f.setBold(True); item.setFont(f)
                elif r == total_rows - 1: # 주석 (마지막 행)
                    note = ("\n * 각 직급별 미승진자 인원은 ‘나. 별도직군 승진 가능 인원 내 미승진자 인원 계산’의 “미승진자” 인원을 기입함.\n\n"
                            " * 각 직급별 평균인원은 1월부터 12월까지의 인원 총계를 12로 나누어서 구하되 소수점 이하 둘째 자리에서 반올림함.")
                    item = QTableWidgetItem(note)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignTop)
                else:
                    item = S13ThousandSeparatorItem("0")
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)
                    
                    # 강조색 설정 (계 행 위치 직결: 8 -> rank_count-1, 19 -> rank_count*2+1)
                    prev_sum_row = rank_count - 1
                    curr_sum_row = rank_count * 2 + 1
                    
                    if c == 1 or r == prev_sum_row or r == curr_sum_row or c == 14:
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r in [prev_sum_row, curr_sum_row] or c == 14:
                            f = item.font(); f.setBold(True); item.setFont(f)
                    
                    # 구분 열 (0열)
                    if c == 0:
                        item.setBackground(QColor(245, 245, 245))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r == 0: item.setText("당년도")
                        elif r == rank_count + 2: item.setText("전년도")

                    # 직급 명칭 (1열)
                    if c == 1:
                        if 0 <= r <= prev_sum_row: 
                            item.setText(ranks[r])
                        elif rank_count + 2 <= r <= curr_sum_row: 
                            item.setText(ranks[r - (rank_count + 2)])

                self.table.setItem(r, c, item)

        # 병합 및 높이 조절 (원본 수치를 rank_count 기반으로 치환)
        self.table.setSpan(0, 0, rank_count, 1) # 전년도 구분
        self.table.setSpan(rank_count + 2, 0, rank_count, 1) # 당년도 구분
        self.table.setSpan(total_rows - 1, 0, 1, 15) # 주석
        
        self.table.setRowHeight(rank_count, 10) # 첫 번째 구분선
        self.table.setRowHeight(rank_count * 2 + 2, 10) # 두 번째 구분선
        self.table.setRowHeight(total_rows - 1, 70) # 주석 높이
        self.table.blockSignals(False)
















    def calculate_s13(self, item):
        row, col = item.row(), item.column()
        
        # 계산 제외: 구분열, 평균열(결과전용), 구분선/제목/주석 행
        if col < 2 or col == 14 or row in [rank_count-1, rank_count, rank_count+1, rank_count*2+1, rank_count*2+2, rank_count*2+3]: 
            return 
        
        self.table.blockSignals(True)
        try:
            # 범위 확정
            if 0 <= row < rank_count - 1:
                data_rows, sum_row = range(rank_count - 1), rank_count - 1
            elif rank_count + 2 <= row < rank_count * 2 + 1:
                data_rows, sum_row = range(rank_count + 2, rank_count * 2 + 1), rank_count * 2 + 1
            else: return

            # 1. [평균인원 열 - 1자리] 가로 평균 계산
            total_avg_accumulator = 0
            for r in data_rows:
                row_sum = 0
                for c in range(2, 14):
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else "0"
                    row_sum += float(val or 0)
                
                # 평균은 소수점 1자리 (2번째에서 반올림)
                avg_val = self.s_round(row_sum / 12, 1)
                self.table.item(r, 14).setData(Qt.EditRole, avg_val)
                total_avg_accumulator += avg_val

            # 2. [일반 월별 열 - 2자리] 현재 수정된 열의 세로 합계 계산
            current_col_sum = 0
            for r in data_rows:
                it = self.table.item(r, col)
                val = it.text().replace(',', '').strip() if it else "0"
                current_col_sum += float(val or 0)
            
            # 일반 열의 합계는 소수점 2자리 적용 (3번째에서 반올림)
            self.table.item(sum_row, col).setData(Qt.EditRole, self.s_round(current_col_sum, 2))

            # 3. [우측 하단 끝 합계 - 1자리] 평균인원의 총합
            self.table.item(sum_row, 14).setData(Qt.EditRole, self.s_round(total_avg_accumulator, 1))
            
        except Exception as e:
            print(f"계산 오류: {e}")
        finally:
            self.table.blockSignals(False)



    def s_round(self, value, digits=1):
        from decimal import Decimal, ROUND_HALF_UP
        
        try:
            # 부동소수점 오차 방지를 위해 문자열로 변환 후 Decimal 처리
            d_val = Decimal(str(value))
            exp = Decimal('1.' + '0' * digits) if digits > 0 else Decimal('1')
            # quantize를 이용한 사사오입 수행
            return float(d_val.quantize(Decimal(str(1 / (10**digits))), rounding=ROUND_HALF_UP))
        except:
            return value


    def send_to_s12(self):
        """전년도(하단 표)의 12월(13열) 데이터를 리스트로 추출"""
        data = []
        # 전년도 데이터 시작 행: rank_count + 2
        # '계' 행을 제외한 실제 직급별 데이터 추출
        start_row = rank_count + 2
        end_row = start_row + rank_count - 1 
        
        for r in range(start_row, end_row):
            item = self.table.item(r, 13) # 12월 열 (인덱스 13)
            val = item.text().replace(',', '').strip() if item else "0"
            data.append(float(val or 0))
        return data


    def send_to_s14(self):
        """
        S14로 전달할 전년도/당년도 평균인원 데이터를 추출하여 반환
        반환 형식: {"prev": [전년도 리스트], "curr": [당년도 리스트]}
        """
        data = {"prev": [], "curr": []}
        
        # 1. 전년도 평균인원 추출 (상단 표의 14열)
        # 데이터 시작: 0행, 끝: rank_count - 1 (계 행 제외)
        for r in range(0, rank_count - 1):
            item = self.table.item(r, 14) # 평균인원 열
            val = item.text().replace(',', '').strip() if item else "0.0"
            data["prev"].append(float(val or 0))
            
        # 2. 당년도 평균인원 추출 (하단 표의 14열)
        # 데이터 시작: rank_count + 2행, 끝: rank_count * 2 + 1 (계 행 제외)
        start_row = rank_count + 2
        end_row = start_row + rank_count - 1
        for r in range(start_row, end_row):
            item = self.table.item(r, 14) # 평균인원 열
            val = item.text().replace(',', '').strip() if item else "0.0"
            data["curr"].append(float(val or 0))
            
        return data





        

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        lines = []

        # [1] 헤더 복사 (0행 포함 시)
        if min_r == 0:
            h_row = [self.table.horizontalHeaderItem(c).text().replace('\n', ' ') 
                     if self.table.horizontalHeaderItem(c) else "" for c in range(min_c, max_c + 1)]
            lines.append("\t".join(h_row))

        for r in range(min_r, max_r + 1):
            # [2] 특수 행 (구분선, 중간제목) - r 좌표 직결
            if r in [rank_count, rank_count + 1, rank_count * 2 + 2]:
                row_data = [(self.table.item(r, c).text().replace('\n', ' ') if self.table.item(r, c) else "") 
                            for c in range(min_c, max_c + 1)]
                lines.append("\t".join(row_data))
                continue

            # [3] 주석 행 (마지막 행) - r 좌표 직결
            if r == rank_count * 2 + 3:
                it = self.table.item(r, 0)
                lines.append((it.text().strip() if it else "") + "\t" * (max_c - min_c))
                continue
                
            # [4] 일반 데이터 및 수식 처리
            row_data = []
            ex_r = r + 2 # 엑셀 행 번호 보정 (헤더가 1행이므로 +2)

            for c in range(min_c, max_c + 1):
                col_let = chr(65 + c)
                
                # 가로 평균 수식 (평균인원 열, 계 행 제외)
                if c == 14 and r not in [rank_count - 1, rank_count * 2 + 1]:
                    row_data.append(f"=ROUND(AVERAGE(C{ex_r}:N{ex_r}), 2)")
                
                # 전년도 합계 수식 (전년도 계 행)
                elif r == rank_count - 1 and c >= 2:
                    row_data.append(f"=SUM({col_let}2:{col_let}{rank_count})")
                
                # 당년도 합계 수식 (당년도 계 행)
                elif r == rank_count * 2 + 1 and c >= 2:
                    # 당년도 시작 행: rank_count(구분선) + 1(제목) + 1(데이터시작) + 1(엑셀보정) = rank_count + 4
                    start_ex_r = rank_count + 3 
                    end_ex_r = rank_count * 2 + 1
                    row_data.append(f"=SUM({col_let}{start_ex_r}:{col_let}{end_ex_r})")
                
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))
        


    def show_context_menu(self, pos):
        menu = QMenu()
        cp = menu.addAction("복사 (Ctrl+C)")
        ps = menu.addAction("붙여넣기 (Ctrl+V)")
        
        # 마우스 클릭한 위치에 메뉴 띄우기
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        
        if act == cp:
            self.copy_selection()
        elif act == ps:
            self.paste_selection()


    def paste_selection(self):
        txt = QApplication.clipboard().text(); curr = self.table.currentItem()
        if not txt or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(txt.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable): it.setText(val.strip())
        self.table.blockSignals(False)
        self.calculate_s13(curr)

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
