from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont

# [1] 천단위 콤마 및 소수점 처리 (비중 ⓒ, ⓔ는 소수점 4자리까지 표시)
class ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val or val == "n/a": return val
            try:
                clean_val = str(val).replace(',', '')
                table = self.tableWidget()
                # 비중 계산 행(3행, 5행)은 소수점 4자리 표시 (백분율 등)
                if table and table.row(self) in [3, 5]: 
                    return format(float(clean_val), ",.4f")
                return format(int(float(clean_val)), ",")
            except: return val
        return super().data(role)

# [2] 실시간 입력 델리게이트 (계산 행 보호)
class RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        # 보호 행: 0행(직무급a), 3행(비중c), 5행(비중e)는 자동 계산
        if index.row() in [0, 3, 5] or index.column() == 0:
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet17Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.target_light_blue = QColor(247, 250, 255)
        self.very_light_gray = QColor(252, 252, 252)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        title = QLabel("hwp 33페이지: 4. 총보수·기준보수 대비 직무급 비중 계산을 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        # 6개 항목 행
        self.table = QTableWidget(6, 2)
        self.table.setHorizontalHeaderLabels(["구분", "금액"])
        
        # 지침 반영: 타이틀 바 및 구분선 스타일 통일
        self.table.verticalHeader().setFixedWidth(25)
        self.table.setColumnWidth(0, 450)
        self.table.setColumnWidth(1, 200)
        
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section { 
                background-color: #f4f4f4; font-weight: bold; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal; 
            }
        """)

        self.delegate = RightAlignedDelegate(self.table)
        self.table.setItemDelegateForColumn(1, self.delegate)

        self.setup_content()
        self.table.itemChanged.connect(self.calculate_totals)
        
        # 표 먼저 추가
        layout.addWidget(self.table)

        # 주석 하단 추가
        footer_note = QLabel(
            "<font color='#555555'>"
            "<b>[1]</b> 보수항목의 명칭에 상관없이 체계적 직무분석 및 직무평가를 거쳐 그 결과에 따라 등급을 구분하여 지급하는 보수(체계적 직무평가와 무관한 보수는 제외)<br><br>"
            "<b>[2]</b> 보수항목란에 기관별 규정상 해당 보수항목 명칭 기재할 것(직무급에 해당하는 보수항목이 둘 이상인 경우 행 추가하여 각각의 항목명과 금액을 기재할 것.)<br><br>"
            "<b>[3]</b> 가중평균 총보수 및 기준보수(성과연봉, 법정수당 및 복리후생비 등 변동급여를 제외한 보수)의 구체적인 계산방법은 아래와 같음.<br><br>"
            "</font>"
        )
        footer_note.setStyleSheet("margin-top: 5px; padding: 8px; background-color: #fcfcfc; border: 1px solid #eeeeee;")
        layout.addWidget(footer_note)

    def setup_content(self):
        self.table.blockSignals(True)
        rows = [
            "직무급 ⓐ   [1]", 
            "보수항목 : 직무평가급   [2]", 
            "가중평균 기준보수 ⓑ   [3]", 
            "기준보수 대비 직무급 비중 ⓒ = ⓐ/ⓑ", 
            "가중평균 총보수 ⓓ   [3]", 
            "총보수 대비 직무급 비중 ⓔ = ⓐ/ⓓ"
        ]

        for r, text in enumerate(rows):
            item_a = QTableWidgetItem(text)
            item_a.setBackground(self.very_light_gray)
            item_a.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            
            # 계산 결과 행 스타일
            if any(mark in text for mark in ["ⓐ", "ⓒ", "ⓔ"]):
                item_a.setBackground(self.base_sky_blue)
                item_a.setFont(QFont("Malgun Gothic", 9, QFont.Bold))
            self.table.setItem(r, 0, item_a)

            item_v = ThousandSeparatorItem("0")
            item_v.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if r in [0, 3, 5]: # 자동 계산 셀
                item_v.setBackground(self.target_light_blue)
                item_v.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(r, 1, item_v)
            
        self.table.blockSignals(False)

    def calculate_totals(self, item):
        if item.column() == 0: return
        self.table.blockSignals(True)
        try:
            def gv(r):
                it = self.table.item(r, 1)
                return float(it.text().replace(',', '')) if it and it.text() else 0.0

            # [요청반영] 직무급 ⓐ (0행)는 바로 아래칸 (1행) 금액을 그대로 가져옴
            val_a = gv(1)
            self.table.item(0, 1).setText(str(int(val_a)))

            # ⓒ = ⓐ/ⓑ
            val_b = gv(2)
            if val_b != 0:
                self.table.item(3, 1).setText(str(round(val_a / val_b, 10)))

            # ⓔ = ⓐ/ⓓ
            val_d = gv(4)
            if val_d != 0:
                self.table.item(5, 1).setText(str(round(val_a / val_d, 10)))
                
        except: pass
        finally: self.table.blockSignals(False)

    # --- 우클릭 메뉴 및 복사 로직 (S15/S16과 동일하게 유지) ---
    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사")
        paste_action = menu.addAction("붙여넣기")
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action: self.copy_selection()
        elif action == paste_action: self.paste_selection()

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        lines = []
        header_labels = [self.table.horizontalHeaderItem(c).text() for c in range(min_c, max_c + 1)]
        lines.append("\t".join(header_labels))

        for r in range(min_r, max_r + 1):
            row_data = []
            for c in range(min_c, max_c + 1):
                item = self.table.item(r, c)
                text = item.text() if item else ""
                if c == 1:
                    # 엑셀 수식 (ⓐ는 바로 아래 참조 등)
                    ex_r = r + 2
                    formulas = {
                        0: f"=B3", # 0행(직무급a)은 1행(B3) 참조
                        3: f"=IF(B4=0,0,B2/B4)", # c = a/b
                        5: f"=IF(B6=0,0,B2/B6)"  # e = a/d
                    }
                    text = formulas.get(r, text.replace(',', ''))
                row_data.append(text)
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        clipboard = QApplication.clipboard().text()
        if not clipboard: return
        rows = clipboard.split('\n')
        current = self.table.currentItem()
        if not current: return
        self.table.blockSignals(True)
        for i, row_text in enumerate(rows):
            if "\t" not in row_text: continue
            cols = row_text.split('\t')
            for j, col_text in enumerate(cols):
                r, c = current.row()+i, current.column()+j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    if c == 1 and r not in [0, 3, 5]:
                        item = self.table.item(r, c)
                        if item: item.setData(Qt.EditRole, col_text.strip().replace(',', ''))
        self.table.blockSignals(False)
        self.calculate_totals(current)
