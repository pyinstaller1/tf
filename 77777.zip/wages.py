import os
os.environ["QT_BE_CONFORMANT_PLATFORM"] = "1"


import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from s1 import Sheet1Page
from s2 import Sheet2Page
from s3 import Sheet3Page
from s4 import Sheet4Page
from s5 import Sheet5Page
from s6 import Sheet6Page
from s7 import Sheet7Page
from s8 import Sheet8Page
from s9 import Sheet9Page
from s10 import Sheet10Page
from s11 import Sheet11Page
from s12 import Sheet12Page
from s13 import Sheet13Page
from s14 import Sheet14Page
from s15 import Sheet15Page
from s16 import Sheet16Page
from s17 import Sheet17Page
from s18 import Sheet18Page


import pygetwindow as gw
from pywinauto import Application
import subprocess
import pyperclip
import keyboard
from pynput.mouse import Controller, Button
import time









class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4개 공통지표 점수로 인건비 집계")        
        self.setGeometry(580, 150, 1100, 850)
        self.setStyleSheet("background-color: white;") 
        
        widget = QWidget()
        self.setCentralWidget(widget)
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(10, 5, 10, 5)

        # 1. 상단 버튼바 (간격 최소화: spacing=2)
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(2) # 버튼 사이 간격을 2픽셀로 고정
        
        btn_style = """
            QPushButton {
                border: 1px solid #dcdcdc;
                border-radius: 2px;
                padding: 3px 8px;
                background-color: #f9f9f9;
            }
            QPushButton:hover { background-color: #f0f0f0; }
        """
        
        # 버튼명 수정: "다른 이름으로 저장"
        '''
        for btn_name in ["열기", "저장", "다른 이름으로 저장", "초기화"]:
            btn = QPushButton(btn_name)
            btn.setStyleSheet(btn_style)
            btn.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
            nav_layout.addWidget(btn)
        '''

        nav_layout.addStretch(1)

        # 엑셀 버튼
        btn_excel = QPushButton("엑셀")
        btn_excel.setStyleSheet("""
            QPushButton {
                background-color: #217346; color: white; border-radius: 2px;
                padding: 3px 12px; font-weight: bold;
            }
            QPushButton:hover { background-color: #1a5a37; }
        """)
        # nav_layout.addWidget(btn_excel)
        layout.addLayout(nav_layout)

        # 2. 하단 시트 탭
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.South)

        self.tabs.setStyleSheet("""
    QTabWidget::pane { 
        border: 1px solid #f2f2f2; /* 본문 테두리와 만나는 선을 아주 연하게 */
    }
    QTabBar::tab {
        background: #f8f8f8; 
        border: 1px solid #dcdcdc;
        padding: 6px 20px; 
        margin-right: 2px;
        color: #666;
    }
    QTabBar::tab:selected { 
        background: white; 
        border-bottom: 2px solid white; /* 선택된 탭이 본문과 연결된 느낌 */
        font-weight: bold;
        color: #000;
    }
""")
        # 각 번호에 맞는 시트 클래스를 연결
        for i in range(1, 19):
            if i == 1:
                page = Sheet1Page()           
            elif i == 2:
                page = Sheet2Page()
            elif i == 3:
                page = Sheet3Page()
            elif i == 4:
                page = Sheet4Page()
            elif i == 5:
                page = Sheet5Page()                
            elif i == 6:
                page = Sheet6Page()                
            elif i == 7:
                page = Sheet7Page()
            elif i == 8:
                page = Sheet8Page()
            elif i == 9:
                page = Sheet9Page()
            elif i == 10:
                page = Sheet10Page()                  
            elif i == 11:
                page = Sheet11Page()
            elif i == 12:
                page = Sheet12Page()                
            elif i == 13:
                page = Sheet13Page()           
            elif i == 14:
                page = Sheet14Page()                                            
            elif i == 15:
                page = Sheet15Page()
            elif i == 16:
                page = Sheet16Page()
            elif i == 17:
                page = Sheet17Page()
            elif i == 18:
                page = Sheet18Page()                  
            else:
                page = QWidget() # 나머지는 아직 빈 페이지
                
            self.tabs.addTab(page, f"Sheet{i}")

        self.tabs.setCurrentIndex(6)
        layout.addWidget(self.tabs)








        # 검증 버튼 생성
        self.btn_verify = QPushButton("검증")
        
        # [수정] 크기를 너무 크지 않게 적절히 조정 (기존 45 -> 35)
        self.btn_verify.setFixedHeight(35)  
        self.btn_verify.setMinimumWidth(100) 
        
        self.btn_verify.setStyleSheet("""
            QPushButton {
                background-color: #BBDEFB; /* 농도를 높인 파스텔 블루 (너무 하얗지 않게) */
                color: #0D47A1;            /* 글자색을 짙은 파랑으로 하여 대비 강화 */
                border: 1px solid #90CAF9; /* 테두리를 배경보다 진하게 설정 */
                border-radius: 4px;        /* 곡률을 살짝 줄여 깔끔하게 */
                font-size: 13px;           
                font-weight: bold;
                padding: 2px 15px;
            }
            QPushButton:hover {
                background-color: #90CAF9; /* 마우스 올리면 더 진해짐 */
                border: 1px solid #64B5F6;
            }
            QPushButton:pressed {
                background-color: #64B5F6; /* 클릭 시 확실한 피드백 */
            }
        """)
        
        self.btn_verify.clicked.connect(self.rpa)
        nav_layout.addWidget(self.btn_verify)



        

        self.rpa()




























    def number(self, str_excel):
        item = str_excel.replace(',', '').replace('\r', '').replace('\n', '').replace('\t', '').replace(' ', ''). strip()
        if item == '':
            item = 0
        elif item == '-':
            item = 0
        elif item == ',':
            item = 0
        else:
            item = int(item)
        return item

    def number_float(self, str_excel):
        item = str_excel.replace(',', '').replace('\r', '').replace('\n', '').replace('\t', '').replace(' ', ''). strip()
        if item == '':
            item = 0
        elif item == '-':
            item = 0
        elif item == ',':
            item = 0
        else:
            item = float(item)
        return item

    
    def table(self, r, c):
        return self.number(self.tabs.currentWidget().table.item(r, c).text())

    def table_float(self, r, c):
        return self.number_float(self.tabs.currentWidget().table.item(r, c).text())


    def text_table(self, r, c):
        return self.tabs.currentWidget().table.item(r, c).text()


    def title(self, c):
        return self.tabs.currentWidget().table.horizontalHeaderItem(c).text()





    def rpa(self):

        current_index = self.tabs.currentIndex()+1


        for item in gw.getAllWindows():
            if item.title.startswith('★2024년도 계량지표'):
                
                win = item
                app = Application().connect(handle=win._hWnd)
                
                app.window(handle=win._hWnd).set_focus()

        time.sleep(1)
        keyboard.press_and_release('ctrl + pageup')
        keyboard.press_and_release('ctrl + pageup')
        keyboard.press_and_release('ctrl + pageup')
        keyboard.press_and_release('ctrl + pageup')
        keyboard.press_and_release('ctrl + pageup')
        keyboard.press_and_release('ctrl + pageup')
        keyboard.press_and_release('ctrl + pageup')
        keyboard.press_and_release('ctrl + pageup')
        keyboard.press_and_release('ctrl + pageup')
        keyboard.press_and_release('ctrl + pageup')
        time.sleep(1)

        for i in range(current_index-1):
            keyboard.press_and_release('ctrl + pagedown')
        
        mouse = Controller()
        if current_index >= 5:
            mouse.position = (1500, 880)   # 최근 1줄 선택   15 270
        else:
            mouse.position = (70, 800)   # 최근 1줄 선택   15 270
        mouse.click(Button.left, 1)

        time.sleep(1)
        keyboard.press_and_release('ctrl + a')   # 최근 1줄 복사
        time.sleep(1)
        keyboard.press_and_release('ctrl + c')   # 최근 1줄 복사
        time.sleep(1)

        if current_index == 1: excel_original01 = pyperclip.paste()
        if current_index == 2: excel_original02 = pyperclip.paste()
        if current_index == 3: excel_original03 = pyperclip.paste()
        if current_index == 4: excel_original04 = pyperclip.paste()
        if current_index == 5: excel_original05 = pyperclip.paste()
        if current_index == 6: excel_original06 = pyperclip.paste()
        if current_index == 7: excel_original07 = pyperclip.paste()
        if current_index == 8: excel_original08 = pyperclip.paste()
        if current_index == 9: excel_original09 = pyperclip.paste()
        if current_index == 10: excel_original10 = pyperclip.paste()        
        time.sleep(1)
        keyboard.press_and_release('esc')


        # excel_original01 = '(2) 인건비 집계를 위한 Template\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t(단위: 원)\r\n인건비 항목\t\t\t판관비\t영업외비용\t 제조원가\t타계정대체\t이익잉여금\t합계\r\n"급료\n임금\n제수당"\t기본급\t\t 744,433,839,400 \t\t\t\t\t 744,433,839,400 \r\n\t상여금\t인센티브 상여금\t 50,727,850,151 \t\t\t\t\t 50,727,850,151 \r\n\t\t그 외 상여금\t 48,367,494,910 \t\t\t\t\t 48,367,494,910 \r\n\t제수당\t법정수당\t 66,931,057,610 \t\t\t\t\t 66,931,057,610 \r\n\t\t해외근무수당\t 50,000,000 \t\t\t\t\t 50,000,000 \r\n\t\t그 외 제수당\t 202,750,281,360 \t\t\t\t\t 202,750,281,360 \r\n\t퇴직급여(명예퇴직금 포함)\t\t 168,793,866,818 \t\t\t\t\t 168,793,866,818 \r\n\t임원 인건비\t\t 983,482,250 \t\t\t\t\t 983,482,250 \r\n\t비상임이사 인건비\t\t 600,000,000 \t\t\t\t\t 600,000,000 \r\n\t"인상률 제외\n인건비"\t통상임금소송결과에 따른 실적급여 증가액\t 70,000,000 \t\t\t\t\t 70,000,000 \r\n\t\t기타 제외 인건비\t 8,000,000 \t\t\t\t\t 8,000,000 \r\n\t기타항목\t\t 74,870,000 \t\t\t\t\t 74,870,000 \r\n\t급료, 임금, 제수당 소계 ⓐ\t\t 1,283,790,742,499 \t - \t - \t - \t - \t 1,283,790,742,499 \r\n"복 리\n후생비"\t사내근로복지기금출연금\t\t 700,000,000 \t\t\t\t\t 700,000,000 \r\n\t국민연금사용자부담분\t\t 38,566,372,740 \t\t\t\t\t 38,566,372,740 \r\n\t건강보험사용자부담분\t\t 41,634,941,020 \t\t\t\t\t 41,634,941,020 \r\n\t고용보험사용자부담분\t\t 18,164,674,530 \t\t\t\t\t 18,164,674,530 \r\n\t산재보험료사용자부담분\t\t 5,325,440,550 \t\t\t\t\t 5,325,440,550 \r\n\t급식비\t\t 700,000,000 \t\t\t\t\t 700,000,000 \r\n\t교통보조비\t\t 800,000,000,000 \t\t\t\t\t 800,000,000,000 \r\n\t자가운전보조금\t\t 60,000,000 \t\t\t\t\t 60,000,000 \r\n\t학자보조금\t\t 49,525,720 \t\t\t\t\t 49,525,720 \r\n\t건강진단비 등(독감예방주사비용)\t\t 173,882,997 \t\t\t\t\t 173,882,997 \r\n\t선택적복지\t\t 9,194,447,060 \t\t\t\t\t 9,194,447,060 \r\n\t행사비\t\t 700,000,000 \t\t\t\t\t 700,000,000 \r\n\t포상품(비)\t\t 52,602,620 \t\t\t\t\t 52,602,620 \r\n\t기념품(비)\t\t 80,000,000 \t\t\t\t\t 80,000,000 \r\n\t격려품(비)\t\t 7,000,000 \t\t\t\t\t 7,000,000 \r\n\t장기근속관련 비용\t\t 8,000,000 \t\t\t\t\t 8,000,000 \r\n\t육아보조비 및 출산장려금\t\t 743,000,000 \t\t\t\t\t 743,000,000 \r\n\t자기계발비\t\t 80,000,000 \t\t\t\t\t 80,000,000 \r\n\t특별근로의 대가\t\t 8,000,000 \t\t\t\t\t 8,000,000 \r\n\t피복비\t\t 700,000,000 \t\t\t\t\t 700,000,000 \r\n\t경로효친비\t\t 800,000,000 \t\t\t\t\t 800,000,000 \r\n\t통신비\t\t 5,000,000 \t\t\t\t\t 5,000,000 \r\n\t축하금/조의금\t\t 70,000,000 \t\t\t\t\t 70,000,000 \r\n\t기타금품 등\t\t 100,927,240 \t\t\t\t\t 100,927,240 \r\n\t복리후생비 소계 ⓑ\t\t 917,923,814,477 \t - \t - \t - \t - \t 917,923,814,477 \r\n"\'잡급 및 무기계약직에\n대한 인건비\'\n(복리후생비, 인센티브포함) ⓒ"\t\t일반 급여(1)\t 15,823,215,150 \t - \t - \t - \t - \t 15,823,215,150 \r\n\t\t 인센티브 상여금\t 7,000,000 \t\t\t\t\t 7,000,000 \r\n\t\t 순액\t 15,816,215,150 \t\t\t\t\t 15,816,215,150 \r\n\t\t청년인턴 급여(2)\t 9,414,136,240 \t - \t - \t - \t - \t 9,414,136,240 \r\n\t\t 인센티브 상여금\t 8,000,000 \t\t\t\t\t 8,000,000 \r\n\t\t 순액\t 9,406,136,240 \t\t\t\t\t 9,406,136,240 \r\n\t\t무기계약직 급여(3)\t 26,694,838,746 \t - \t - \t - \t - \t 26,694,838,746 \r\n\t\t 인센티브 상여금\t 1,256,862,230 \t\t\t\t\t 1,256,862,230 \r\n\t\t 순액\t 25,437,976,516 \t\t\t\t\t 25,437,976,516 \r\n\t\t소계 ⓒ=(1)+(2)+(3)\t 51,932,190,136 \t - \t - \t - \t - \t 51,932,190,136 \r\n\t\t\t\t\t\t\t\t\r\n인건비 총계 : ⓓ=ⓐ+ⓑ+ⓒ\t\t\t 2,253,646,747,112 \t - \t - \t - \t - \t 2,253,646,747,112 \r\n인센티브 상여금 ⓔ=ⓔ-1+ⓔ-2\t\t\t 51,984,712,381 \t - \t - \t - \t - \t 51,984,712,381 \r\n- 인센티브 전환금 (ⓔ-1)\t\t\t 43,589,629,529 \t\t\t\t\t 43,589,629,529 \r\n- 인센티브 추가금 (ⓔ-2)\t\t\t 8,395,082,852 \t\t\t\t\t 8,395,082,852 \r\n인건비 해당금액 : ⓓ-ⓔ\t\t\t 2,201,662,034,731 \t - \t - \t - \t - \t 2,201,662,034,731 \r\n\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\r\n'
        # excel_original01 = excel_original01.replace(' ', '')


        # excel_original02 = '(3)총인건비인상률지표의점수계산을위한Template\t\t\t\t\r\n\t\t\t\t(단위:원)\r\n구분\t\t\t2024\t2023\r\n\t1.인센티브상여금을제외한인건비총액\t\t\t\r\n\ta.판관비로처리한인건비\t\t1,397,001,034,731\t1,298,932,744,191\r\n\tb.영업외비용으로처리한인건비\t\t-\t-\r\n\tc.제조원가로처리한인건비\t\t-\t-\r\n\td.타계정대체로처리한인건비\t\t-\t-\r\n\te.이익잉여금의증감으로처리한인건비\t\t-\t-\r\n\t소계:(A)=a+b+c+d+e\t\t1,397,001,034,731\t1,298,932,744,191\r\n\t\t\t\t\r\n\t2.총인건비 인상률계산에서제외(조정)되는인건비\t\t\t\r\n\tf.퇴직급여(명예퇴직금포함)\t\t168,793,866,818\t141,500,433,647\r\n\tg.임원인건비\t\t983,482,250\t771,999,300\r\n\th.비상임이사인건비\t\t-\t-\r\n\ti.인상률제외인건비\t통상임금소송결과에따른실 적급여증가액\t-\t-\r\n\t\t기타제외인건비\t-\t-\r\n\tj.사내근로복지기금출연금\t\t-\t-\r\n\tk.잡급및무기계약직에대한인건비(복리후생비포함,인센티브상여금제외)\t\t50,660,327,906\t50,195,933,210\r\n\tl.공적보험사용자부담분\t\t103,691,428,840\t104,545,198,290\r\n\tm.연월차수당등조정(㉠-㉡+㉢)\t\t71,795,906,667\t-2,930,735,981\r\n\t-연월차수당등발생액(㉠)\t\t123,325,995,917\t63,001,832,519\r\n\t-연월차수당등지급액(㉡)\t\t51,530,089,250\t65,932,568,500\r\n\t-종업원저리대여금이 자관련인건비(㉢)\t\t-\t-\r\n\tn.저리·무상대여이익\t\t4,725,943,920\t5,598,293,980\r\n\to.지방이전관련직접인건비\t\t-\t-\r\n\tp.법령에따른특수건강진단비\t\t-\t-\r\n\tq.코로나19대응을위한시간외근로수당등\t\t-\t-\r\n\tr.해외근무수당\t\t-\t-\r\n\ts.직무발명보상금\t\t-\t-\r\n\tt.공무원수준내의자녀수당및출산격려금\t\t3,051,903,476\t1,832,315,628\r\n\tu.야간간호특별수당\t\t-\t-\r\n\tv.비상진료체계운영에따른특별수당등\t\t-\t-\r\n\tu.국민건강보험공단2023년도총인건비초과액에따른상환금액\t\t-\t22,500,000,000\r\n\t소계:(B)=f+g+h+i+j+k+l+m-n+o+p+q+r+s+t+u+v+w\t\t394,250,972,037\t312,816,850,114\r\n\t\t\t\t\r\n\t3.실집행액기준총인건비발생액(C)=(A)-(B)\t\t1,002,750,062,694\t986,115,894,077\r\n\t\t\t\t\r\n"전년대비\n조정된\n총인건비\n발생액\n산출"\t4.연도별증원소요인건비의영향을제거하기위한인건비의조정(D)\t\t\t-8,039,360,305\r\n\t5.별도직군승진시기차이에따른인건비효과조정(E)\t\t\t\r\n\t6.초임직급정원변동에따른인건비효과조정(F)\t\t\t-511,459,730\r\n\t7.정년이후재고용을전제로전환된정원외인력의인건비효과조정(G)\t\t\t\r\n\t8.생산량증가로인하여\'23년도\'에추가로지급된인건비의영향제거(H)\t\t\tn/a\r\n\t9.최저임금지급직원에대한인건비효과조정(I)\t\t\t\r\n\t10.파업등에따른인건비효과조정(J)\t\t\t\r\n\t11.코로나19로인한휴업의인건비효과조정(K)\t\t\t\r\n\t"12.총인건비인상률계산대상총인건비발생액\n=(C)+(D)+(E)-(F)-(G)-(H)+(I)+(J)+(K)+(L)"\t\t1,002,750,062,694\t978,587,993,501\r\n\t\t\t\t\r\n"당해연도\n총인건비\n인상률\n계산"\t13.총인건비인상률가이드라인에따른총인건비상한액\t\tn/a\tn/a\r\n\t(1)\'23년도총인건비인상률가이드라인을준수한경우\t\t\t978,587,993,501\r\n\t(2)\'23년도총인건비인상률가이드라인을준수경우하지않은경우\t\t\t-\r\n\t\t\t\t\r\n\t14.총인건비인상률 산출(\'24년도총인건비인상률가이드라인=2.5%)\t\tn/a\t\r\n\t(1)\'23년도총인건비인상률가이드라인을준수한경우\t\t2.469%\t\r\n\t(2)\'23년도총인건비인상률가이드라인을준수경우하지않은경우\t\t-\t\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t\r\n'
        # excel_original02 = excel_original02.replace(' ', '')



        # excel_original03 = '(3-1) 증원소요 인건비 계산을 위한 Template\t\t\t\t\t\t\r\n\t\t\t\t\t(단위: 명, 원)\t\r\n직급\t인원\t\t\t"전년도의\n평균단가\n(D)"\t"증원소요 인건비\n(C) x (D)"\t\r\n\t"전년도\n(A)"\t"당년도\n(B)"\t"증감\n(C)=(B)-(A)"\t\t\t\r\n1급\t133.0 \t133.0 \t -  \t99,310,634 \t -  \t\r\n2급\t589.0 \t589.0 \t -  \t92,457,982 \t -  \t\r\n3급\t2,437.1 \t2,444.9 \t7.8 \t86,403,138 \t673,944,476 \t\r\n4급\t4,314.5 \t4,060.4 \t△254.1 \t77,428,700 \t△19,674,632,670 \t\r\n5급\t3,887.0 \t4,251.8 \t364.8 \t53,434,940 \t19,493,066,112 \t\r\n6급\t3,466.0 \t3,269.3 \t△196.7 \t44,091,356 \t△8,672,769,725 \t\r\n연 구직\t136.9 \t138.8 \t1.9 \t74,227,106 \t141,031,501 \t\r\n계\t14,963.5 \t14,887.2 \t△76.3 \t\t△8,039,360,305 \t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n\t\t\t\t\t\t\r\n'
        # excel_original04 = '(3-2) 직급별 평균인원 계산을 위한 Template\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t(단위: 명)\t\r\n전년도\t직급\t1월\t2월\t3월\t4월\t5월\t6월\t7월\t8월\t9월\t10월\t11월\t12월\t평균인원\t\r\n\t1급\t 166.0 \t 166.0 \t 167.0 \t 167.0 \t 167.0 \t 167.0 \t 159.0 \t 158.0 \t 158.0 \t 158.0 \t 158.0 \t 158.0 \t 162.4 \t\r\n\t2급\t 678.0 \t 678.0 \t 680.0 \t 680.0 \t 680.0 \t 678.0 \t 669.0 \t 669.0 \t 671.0 \t 670.0 \t 668.0 \t 670.0 \t 674.3 \t\r\n\t3급\t 2,598.0 \t 2,594.0 \t 2,591.0 \t 2,587.0 \t 2,584.0 \t 2,586.0 \t 2,555.0 \t 2,547.0 \t 2,548.0 \t 2,550.0 \t 2,549.0 \t 2,551.8 \t 2,570.1 \t\r\n\t4급\t 4,039.0 \t 4,189.8 \t 4,180.0 \t 4,174.5 \t 4,173.3 \t 4,168.3 \t 3,985.0 \t 3,967.5 \t 3,992.8 \t 3,981.3 \t 3,974.3 \t 3,977.5 \t 4,066.9 \t\r\n\t5급\t 4,011.3 \t 3,815.5 \t 3,797.0 \t 3,785.3 \t 3,773.5 \t 3,761.8 \t 3,966.8 \t 3,959.8 \t 3,988.0 \t 3,942.0 \t 3,916.0 \t 3,927.5 \t 3,887.0 \t\r\n\t6급\t 3,440.0 \t 3,432.0 \t 3,437.3 \t 3,440.5 \t 3,436.5 \t 3,439.8 \t 3,451.0 \t 3,439.0 \t 3,445.0 \t 3,423.5 \t 3,425.5 \t 3,782.0 \t 3,466.0 \t\r\n\t연구직\t 145.0 \t 140.0 \t 136.0 \t 133.0 \t 133.0 \t 133.0 \t 139.0 \t 138.0 \t 135.0 \t 135.0 \t 136.0 \t 139.8 \t 136.9 \t\r\n\t계\t 15,077.3 \t 15,015.3 \t 14,988.3 \t 14,967.3 \t 14,947.3 \t 14,933.8 \t 14,924.8 \t 14,878.3 \t 14,937.8 \t 14,859.8 \t 14,826.8 \t 15,206.5 \t 14,963.6 \t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t(단위: 명)\t\r\n당년도\t직급\t1월\t2월\t3월\t4월\t5월\t6월\t7월\t8월\t9월\t10월\t11월\t12월\t평균인원\t\r\n\t1급\t 162.00 \t 162.00 \t 161.00 \t 160.00 \t 159.00 \t 158.00 \t 165.00 \t 165.00 \t 165.00 \t 165.00 \t 165.00 \t 165.00 \t 162.70 \t\r\n\t2급\t 678.00 \t 678.00 \t 678.00 \t 678.00 \t 678.00 \t 678.00 \t 670.00 \t 669.00 \t 669.00 \t 669.00 \t 669.00 \t 667.00 \t 673.40 \t\r\n\t3급\t 2,583.00 \t 2,579.00 \t 2,573.75 \t 2,566.50 \t 2,556.75 \t 2,561.00 \t 2,575.00 \t 2,571.75 \t 2,572.75 \t 2,569.75 \t 2,568.50 \t 2,569.50 \t 2,570.60 \t\r\n\t4급\t 3,877.75 \t 3,854.75 \t 3,847.75 \t 3,840.75 \t 3,835.00 \t 3,842.50 \t 3,526.50 \t 3,855.75 \t 3,853.00 \t 3,842.25 \t 3,834.50 \t 3,837.50 \t 3,820.70 \t\r\n\t5급\t 4,149.25 \t 4,126.25 \t 4,119.00 \t 4,117.75 \t 4,105.75 \t 4,119.50 \t 4,673.25 \t 4,325.50 \t 4,348.25 \t 4,318.50 \t 4,312.25 \t 4,306.75 \t 4,251.80 \t\r\n\t6급\t 3,319.75 \t 3,318.00 \t 3,307.50 \t 3,302.75 \t 3,292.50 \t 3,292.00 \t 3,155.25 \t 3,156.00 \t 3,160.00 \t 3,160.00 \t 3,160.75 \t 3,607.50 \t 3,269.30 \t\r\n\t연구직\t 138.00 \t 139.00 \t 136.00 \t 135.00 \t 134.00 \t 136.00 \t 137.00 \t 141.00 \t 139.00 \t 139.00 \t 146.00 \t 145.00 \t 138.80 \t\r\n\t계\t 14,907.75 \t 14,857.00 \t 14,823.00 \t 14,800.75 \t 14,761.00 \t 14,787.00 \t 14,902.00 \t 14,884.00 \t 14,907.00 \t 14,863.50 \t 14,856.00 \t 15,298.25 \t 14,887.30 \t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n'
        # excel_original05 = ''
        # excel_original06 = '(3-4) 직급별 평균단가 계산을 위한 Template\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t(단위: 원)\r\n전년도\t직급\t1월\t2월\t3월\t4월\t5월\t6월\t7월\t8월\t9월\t10월\t11월\t 12월 \t"인건비\n총계"\t평균인원\t"직급별\n평균단가\n(수정 전)"\t"공무원 수준 내\n가족(자녀)수당"\t"공무원 수준 내\n출산축하금"\t"총인건비 차감 액\n(225억원)"\t"인건비 총계\n(수정 후)"\t"직급별\n평균단가"\r\n\t1급\t 1,321,802,810 \t 1,291,429,920 \t 1,326,000,290 \t 1,326,201,640 \t 1,268,376,330 \t 1,330,114,040 \t 1,733,986,960 \t 1,320,458,570 \t 1,312,172,040 \t 1,312,139,870 \t 1,315,490,040 \t 1,637,182,180 \t 16,495,354,690 \t 162.4 \t 101,572,381 \t - \t - \t 367,307,772 \t 16,128,046,918 \t 99,310,634 \r\n\t2급\t 4,948,980,180 \t 4,863,629,030 \t 4,953,343,590 \t 4,954,987,280 \t 4,769,837,630 \t 4,975,979,063 \t 6,451,898,160 \t 5,095,134,530 \t 5,091,679,310 \t 5,094,012,550 \t 5,088,037,870 \t 7,476,759,374 \t 63,764,278,567 \t 674.3 \t 94,563,664 \t\t - \t 1,419,861,260 \t 62,344,417,307 \t 92,457,982 \r\n\t3급\t 19,111,270,460 \t 17,320,263,020 \t 19,035,988,790 \t 17,316,149,340 \t 17,301,048,560 \t 20,258,047,323 \t 17,060,089,490 \t 17,042,175,518 \t 20,405,748,920 \t 17,024,524,280 \t 17,062,985,470 \t 28,690,840,311 \t 227,629,131,482 \t 2,570.1 \t 88,568,200 \t 493,728,590 \t 2,000,000 \t 5,068,696,653 \t 222,064,706,239 \t 86,403,138 \r\n\t4급\t 27,973,217,490 \t 25,314,121,630 \t 27,873,909,550 \t 25,211,744,390 \t 25,201,347,530 \t 26,581,898,988 \t 23,809,210,590 \t 23,736,133,130 \t 28,723,590,960 \t 23,824,586,280 \t 23,750,159,250 \t 40,926,953,862 \t 322,926,873,650 \t 4,066.9 \t 79,403,692 \t 796,369,178 \t 45,000,000 \t 7,190,724,460 \t 314,894,780,012 \t 77,428,700 \r\n\t5급\t 17,284,675,850 \t 15,464,665,320 \t 17,260,224,060 \t 15,372,935,600 \t 15,371,757,040 \t 17,199,384,134 \t 16,081,394,090 \t 16,153,774,921 \t 20,025,879,960 \t 16,191,904,800 \t 16,111,683,600 \t 30,354,439,609 \t 212,872,718,984 \t 3,887.0 \t 54,765,299 \t 329,995,920 \t 101,000,000 \t 4,740,110,509 \t 207,701,612,555 \t 53,434,940 \r\n\t6급\t 12,923,915,810 \t 11,492,535,180 \t 12,878,647,990 \t 11,552,605,610 \t 11,568,258,340 \t 13,256,094,043 \t 11,055,966,180 \t 11,589,625,850 \t 14,279,261,000 \t 11,550,381,140 \t 11,561,789,550 \t 22,657,653,654 \t 156,366,734,347 \t 3,466.0 \t 45,114,465 \t 47,221,940 \t 17,000,000 \t 3,481,872,192 \t 152,820,640,215 \t 44,091,356 \r\n\t연구직\t 858,793,160 \t 842,878,770 \t 819,288,680 \t 794,829,380 \t 788,109,900 \t 787,871,080 \t 804,115,530 \t 825,729,100 \t 807,479,280 \t 790,436,900 \t 810,932,730 \t 1,462,653,475 \t 10,393,117,985 \t 136.9 \t 75,917,589 \t - \t - \t 231,427,155 \t 10,161,690,830 \t 74,227,106 \r\n\t계\t 84,422,655,760 \t 76,589,522,870 \t 84,147,402,950 \t 76,529,453,240 \t 76,268,735,330 \t 84,389,388,671 \t 76,996,661,000 \t 75,763,031,619 \t 90,645,811,470 \t 75,787,985,820 \t 75,701,078,510 \t 133,206,482,465 \t 1,010,448,209,705 \t 14,963.6 \t 67,527,080 \t 1,667,315,628 \t 165,000,000 \t 22,500,000,000 \t 986,115,894,077 \t 65,900,979 \r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t(단위: 원)\t\t\t\t\t\r\n당년도\t직급\t1월\t2월\t3월\t4월\t5월\t6월\t7월\t8월\t9월\t10월\t11월\t 12월 \t"인건비\n총계"\t평균인원\t"직급별\n평균단가"\t\t\t\t\t\r\n\t1급\t 1,289,093,280 \t 1,301,470,470 \t 1,282,011,870 \t 1,294,314,070 \t 1,273,310,800 \t 1,266,833,110 \t 1,823,613,250 \t 1,377,821,680 \t 1,376,883,040 \t 1,377,071,790 \t 1,377,552,390 \t 1,543,436,610 \t 16,583,412,360 \t 162.7 \t 101,926,321 \t\t\t\t\t\r\n\t2급\t 5,041,228,250 \t 5,037,789,130 \t 5,038,918,830 \t 5,036,626,310 \t 5,028,001,270 \t 5,039,934,860 \t 6,644,537,710 \t 5,224,911,050 \t 5,219,179,220 \t 5,219,764,100 \t 5,220,681,520 \t 5,981,594,485 \t 63,733,166,735 \t 673.4 \t 94,643,847 \t\t\t\t\t\r\n\t3급\t 17,625,397,980 \t 19,344,193,980 \t 19,650,934,360 \t 17,536,858,650 \t 17,347,801,340 \t 19,553,311,730 \t 17,587,988,237 \t 17,519,558,340 \t 21,352,936,869 \t 17,542,838,840 \t 17,530,272,050 \t 24,306,822,638 \t 226,898,915,014 \t 2,570.6 \t 88,266,909 \t\t\t\t\t\r\n\t4급\t 23,541,146,470 \t 25,996,996,330 \t 26,409,785,160 \t 23,431,021,930 \t 23,228,242,220 \t 26,394,368,690 \t 21,477,194,120 \t 22,996,134,860 \t 28,449,719,510 \t 23,030,309,980 \t 23,019,346,970 \t 31,547,253,484 \t 299,521,519,724 \t 3,820.7 \t 78,394,409 \t\t\t\t\t\r\n\t5급\t 17,441,936,300 \t 19,518,492,260 \t 19,897,277,120 \t 17,437,728,740 \t 17,343,345,220 \t 19,981,102,910 \t 19,756,931,320 \t 18,280,688,130 \t 23,216,590,420 \t 18,386,888,560 \t 18,335,357,990 \t 27,101,369,172 \t 236,697,708,142 \t 4,251.8 \t 55,670,001 \t\t\t\t\t\r\n\t6급\t 11,643,907,510 \t 12,952,398,370 \t 13,176,416,364 \t 11,512,510,520 \t 11,503,845,320 \t 13,171,697,790 \t 10,234,872,400 \t 11,611,045,360 \t 13,778,287,160 \t 10,972,489,010 \t 10,996,629,300 \t 17,273,398,355 \t 148,827,497,459 \t 3,269.3 \t 45,522,741 \t\t\t\t\t\r\n\t연구직\t 879,506,520 \t 869,343,780 \t 865,985,430 \t 843,876,470 \t 826,613,590 \t 835,660,310 \t 841,369,650 \t 846,139,520 \t 869,109,910 \t 856,415,910 \t 853,742,870 \t 1,100,079,300 \t 10,487,843,260 \t 138.8 \t 75,560,830 \t\t\t\t\t\r\n\t계\t 77,462,216,310 \t 85,020,684,320 \t 86,321,329,134 \t 77,092,936,690 \t 76,551,159,760 \t 86,242,909,400 \t 78,366,506,687 \t 77,856,298,940 \t 94,262,706,129 \t 77,385,778,190 \t 77,333,583,090 \t 108,853,954,044 \t 1,002,750,062,694 \t 14,887.3 \t 67,356,073 \t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n'
        # excel_original07 = '(3-6) 초임직급 정원변동에 따른 인건비 효과 조정을 위한 Template\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n가. 초임직급 정원\t\t\t\t\t\t\t\t\t\t\t\t\t\t(단위: 명)\t\t\t\t\t\t\t\r\n당년도\t직급\t1월\t2월\t3월\t4월\t5월\t6월\t7월\t8월\t9월\t10월\t11월\t12월\t평균정원\t\t\t\t\t\t\t\r\n\t1급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t2급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t3급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t4급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t5급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t6급\t575 \t575 \t575 \t575 \t575 \t642 \t642 \t642 \t642 \t642 \t642 \t642 \t614.1 \t\t\t\t\t\t\t\r\n\t연구직\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t기능직\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t계\t575 \t575 \t575 \t575 \t575 \t642 \t642 \t642 \t642 \t642 \t642 \t642 \t614.1 \t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n전년도\t직급\t1월\t2월\t3월\t4월\t5월\t6월\t7월\t8월\t9월\t10월\t11월\t12월\t평균정원\t\t\t\t\t\t\t\r\n\t1급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t2급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t3급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t4급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t5급\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t6급\t657 \t657 \t657 \t657 \t657 \t608 \t608 \t608 \t608 \t608 \t608 \t575 \t625.7 \t\t\t\t\t\t\t\r\n\t연구직\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t기능직\t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0 \t0.0 \t\t\t\t\t\t\t\r\n\t계\t657 \t657 \t657 \t657 \t657 \t608 \t608 \t608 \t608 \t608 \t608 \t575 \t625.7 \t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n나. 초임직급 정원 변동에 따른 인건비 효과\t\t\t\t\t\t(단위: 명, 원)\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n구분\t정원\t\t\t"전년도의\n평균단가\n(D)"\t"인건비 효과\n(E) = (C) x (D)"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t"전년도\n(A)"\t"당년도\n(B)"\t"증감\n(C)=(B)-(A)"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n1급\t - \t - \t - \t - \t - \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n2급\t - \t - \t - \t - \t - \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n3급\t - \t - \t - \t - \t - \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n4급\t - \t - \t - \t - \t - \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n5급\t - \t - \t - \t - \t - \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n6급\t 625.7 \t 614.1 \t-11.6 \t44,091,356 \t-511,459,730 \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n연구직\t - \t - \t - \t - \t - \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n기능직\t - \t - \t - \t - \t - \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n계\t 625.7 \t 614.1 \t-11.6 \t\t-511,459,730 \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n'
        # excel_original08 =
        # excel_original09 =
        # excel_original10 = 



        
        print(repr(excel_original07))
        return


        str_err = '-----------------------\n   인건비 오류 검증\n-----------------------\n'
        
        
        table = self.tabs.currentWidget().table


        if current_index == 1:
            
            
            list_title = ['기본급\t', '인센티브상여금', '그외상여금', '법정수당', '해외근무수당', '그외제수당', '퇴직급여(명예퇴직금포함)\t', '임원인건비\t', '비상임이사인건비\t',
                          '통상임금소송결과에따른실적급여증가액', '기타제외인건비', '기타항목\t', '급료,임금,제수당소계ⓐ\t',  '사내근로복지기금출연금\t', '국민연금사용자부담분\t',
                          '건강보험사용자부담분\t', '고용보험사용자부담분\t', '산재보험료사용자부담분\t', '급식비\t', '교통보조비\t', '자가운전보조금\t', '학자보조금\t','건강진단비등(독감예방주사비용)\t',
                          '선택적복지\t', '행사비\t', '포상품(비)\t', '기념품(비)\t', '격려품(비)\t', '장기근속관련비용\t', '육아보조비및출산장려금\t', '자기계발비\t', '특별근로의대가\t',
                          '피복비\t', '경로효친비\t', '통신비\t', '축하금/조의금\t', '기타금품등\t', '복리후생비소계ⓑ\t', '일반급여(1)', '인센티브상여금', '순액', '청년인턴급여(2)', '인센티브상여금', '순액', '무기계약직급여(3)',
                          '인센티브상여금', '순액', '소계ⓒ=(1)+(2)+(3)', '인건비총계:ⓓ=ⓐ+ⓑ+ⓒ\t\t', '인센티브상여금ⓔ=ⓔ-1+ⓔ-2\t\t', '인센티브전환금(ⓔ-1)\t\t', '인센티브추가금(ⓔ-2)\t\t', '인건비해당금액:ⓓ-ⓔ\t\t']

            # print(list_title)
            # print(len(list_title))

            str_err += '\n(2) 인건비 집계를 위한 Template\n\n'
            str_err += '급료임금제수당\n'
            str_err += '               \t판영제타이합\n'

            for i in range (0, 53):  # 53
                if i == 39: excel = excel_original.split('일반급여(1)')[1]    
                if i == 42: excel = excel_original.split('청년인턴급여(2)')[1]
                if i == 45: excel = excel_original.split('무기계약직급여(3)')[1]    
                if i == 49: excel = excel_original.split('인건비총계:ⓓ=ⓐ+ⓑ+ⓒ')[1]

                if i == 13: str_err += '\n복리후생비\n               \t판영제타이합\n'
                if i == 38: str_err += '\n잡급\n               \t판영제타이합\n'
                if i == 49: str_err += '\n인건비\n               \t판영제타이합\n'


                excel = excel_original01
                excel = excel.split(list_title[i])[1] # 기본급
                excel_item = excel.split('\r\n')[0]

                # print(repr(excel))

                # print(list_title[i])
                # print(self.text_table(i, 0))

                # print(excel_item.split('\t')[1])
                # print(self.table(i, 1))


                if i in [0, 18, 24, 32, 34, 40, 43, 46]:
                    str_err += self.text_table(i, 0)[:6] + '\t\t'
                else:
                    str_err += self.text_table(i, 0)[:6] + '\t'

                for j in range(1, 7):
                    if self.number(excel_item.split('\t')[j]) == self.table(i, j): str_err += 'O '
                    else: str_err += 'X '


                # str_err = str_err[:-1] + '\t' + self.text_table(i, 0) + '\t' + list_title[i] + str(self.text_table(i, 6)) +  '\t' + str(excel_item.split('\t')[6]) + '\n'
                str_err = str_err[:-1] + '\n'


            print(str_err)
            # print(repr(excel))


            return






        if current_index == 2:

            list_title = ['1. 인센티브 상여금을 제외한 인건비 총액', 'a. 판관비로 처리한 인건비', 'b. 영업외비용으로 처리한 인건비', 'c. 제조원가로 처리한 인건비', 'd. 타계정대체로 처리한 인건비', 'e. 이익잉여금의 증감으로 처리한 인건비',
                          '소계 : (A)=a+b+c+d+e', '2. 총인건비 인상률 계산에서 제외(조정)되는 인건비', 'f. 퇴직급여(명예퇴직금 포함)', 'g. 임원 인건비', 'h. 비상임이사 인건비', ' 통상임금소송결과에 따른 실적급여 증가액',
                          ' 기타 제외 인건비', 'j. 사내근로복지기금출연금', 'k. 잡급 및 무기계약직에 대한 인건비(복리후생비 포함, 인센티브상여금 제외)', 'l. 공적보험 사용자부담분', 'm. 연월차수당 등 조정(㉠-㉡+㉢)', '- 연월차수당 등 발생액(㉠)',
                          '- 연월차수당 등 지급액(㉡)', '- 종업원 저리 대여금 이자 관련 인건비(㉢)', 'n. 저리·무상대여 이익', 'o. 지방이전 관련 직접 인건비', 'p. 법령에 따른 특수건강진단비', 'q. 코로나19 대응을 위한 시간외근로수당 등',
                          'r. 해외근무수당', 's. 직무발명보상금', 't. 공무원 수준 내의 자녀수당 및 출산격려금', 'u. 야간간호특별수당', 'v. 비상진료체계 운영에 따른 특별수당 등',
                          'u. 국민건강보험공단 2023년도 총인건비 초과액에 따른 상환금액', '소계 : (B)=f+g+h+i+j+k+l+m-n+o+p+q+r+s+t+u+v+w', '3. 실집행액기준 총인건비 발생액 (C)=(A)-(B)', '4. 연도별 증원소요 인건비의 영향을 제거하기 위한 인건비의 조정(D)',
                          '5. 별도직군 승진시기 차이에 따른 인건비 효과 조정(E)', '6. 초임직급 정원 변동에 따른 인건비 효과 조정(F)', '7. 정년이후 재고용을 전제로 전환된 정원외인력의 인건비 효과 조정(G)',
                          '추가로 지급된 인건비의 영향 제거(H)', '9. 최저임금 지급 직원에 대한 인건비 효과 조정(I)', '10. 파업 등에 따른 인건비 효과 조정(J)',
                          '11. 코로나19로 인한 휴업의 인건비 효과 조정(K)', '(C)+(D)+(E)-(F)-(G)-(H)+(I)+(J)+(K)+(L)', '13. 총인건비 인상률 가이드라인에 따른 총인건비 상한액',
                          '23년도 총인건비 인상률 가이드라인을 준수한 경우', '23년도 총인건비 인상률 가이드라인을 준수 경우하지 않은 경우', '24년도 총인건비 인상률 가이드라인=2.5%)', '23년도 총인건비 인상률 가이드라인을 준수한 경우',
                          '23년도 총인건비 인상률 가이드라인을 준수 경우하지 않은 경우' ]

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
            str_err += '\n(3) 총인건비 인상률 지표의 점수계산을 위한 Template\n\n'
            str_err += '실집행액 기준 총인건비 발생액 산출\n'
            str_err += '               \t판영제타이합\n'



            for i in range (0, 10):  # 53


                excel = excel_original02
                excel = excel.split(list_title[i])[1] # 기본급
                excel_item = excel.split('\r\n')[0]

                # print(repr(excel))

                # print(list_title[i])
                # print(self.text_table(i, 0))

                # print(excel_item.split('\t')[1])
                # print(self.table(i, 1))


                if i in [0, 18, 24, 32, 34, 40, 43, 46]:
                    str_err += self.text_table(i, 0)[:6] + '\t\t'
                else:
                    str_err += self.text_table(i, 0)[:6] + '\t'

                for j in range(1, 7):
                    if self.number(excel_item.split('\t')[j]) == self.table(i, j): str_err += 'O '
                    else: str_err += 'X '


                # str_err = str_err[:-1] + '\t' + self.text_table(i, 0) + '\t' + list_title[i] + str(self.text_table(i, 6)) +  '\t' + str(excel_item.split('\t')[6]) + '\n'
                str_err = str_err[:-1] + '\n'


            print(str_err)
            # print(repr(excel))


            return



































            
        win.minimize()


    


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setFont(QFont("맑은 고딕", 9))
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
