import sys
import os
import pandas as pd
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor

class Set1Window(QDialog):
    def __init__(self):
        super().__init__()
        self.filename = "임금점수산정.xlsx"
        self.setWindowTitle("제 1세트: 다중 복사 및 우클릭 지원")
        self.setGeometry(100, 100, 1100, 850)
        self.check_and_create_excel()
        self.initUI()

    def check_and_create_excel(self):
        if not os.path.exists(self.filename):
            data = [[""] * 6] * 35
            df = pd.DataFrame(data, columns=["영역", "항목", "코드", "2025", "2024", "2023"])
            df.to_excel(self.filename, index=False)

    def initUI(self):
        layout = QVBoxLayout()
        self.table = QTableWidget(35, 6)
        self.table.setHorizontalHeaderLabels(["대분류(A)", "항목명(B)", "기호", "2025(C)", "2024(D)", "2023(E)"])
        self.table.setColumnWidth(1, 400)
        
        # [중요] 우클릭 메뉴 정책 설정 (기본값으로 둠 - contextMenuEvent 사용)
        self.table.setContextMenuPolicy(Qt.DefaultContextMenu)
        
        # 다중 선택 및 드래그 설정
        self.table.setSelectionMode(QAbstractItemView.ExtendedSelection) 
        self.table.setSelectionBehavior(QAbstractItemView.SelectItems)     
        
        self.setup_table_content()
        layout.addWidget(self.table)
        self.setLayout(layout)

    def setup_table_content(self):
        # 모든 셀 초기화 (None 방지)
        for r in range(35):
            for c in range(6):
                self.table.setItem(r, c, QTableWidgetItem(""))

        self.table.setSpan(0, 0, 25, 1)
        self.table.setSpan(25, 0, 10, 1)
        
        self.table.item(0, 0).setText("실집행액 기준")
        self.table.item(25, 0).setText("전년대비 조정")
        
        for r in range(35):
            for c in range(1, 6):
                item = self.table.item(r, c)
                item.setText(f"R{r}C{c}")
                if r in [0, 6, 24, 30]: 
                    item.setBackground(QColor(220, 235, 245))

    def contextMenuEvent(self, event):
        """우클릭 시 메뉴 생성 (테이블 위에서만 작동)"""
        # 마우스 위치가 테이블 위인지 확인
        if self.table.underMouse():
            menu = QMenu(self)
            copy_action = menu.addAction("복사 (Ctrl+C)")
            paste_action = menu.addAction("붙여넣기 (Ctrl+V)")
            
            # 메뉴 위치 지정 및 실행
            action = menu.exec_(event.globalPos())
            
            if action == copy_action:
                self.copy_selection()
            elif action == paste_action:
                self.paste_selection()

    def keyPressEvent(self, event):
        """키보드 단축키 지원"""
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C:
            self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V:
            self.paste_selection()
        else:
            super().keyPressEvent(event)

    def copy_selection(self):
        """다중 셀 복사 (병합 및 쪼개진 영역 대응)"""
        selection = self.table.selectedRanges()
        if not selection:
            return

        # 전체 영역 계산
        min_row = min(r.topRow() for r in selection)
        max_row = max(r.bottomRow() for r in selection)
        min_col = min(r.leftColumn() for r in selection)
        max_col = max(r.rightColumn() for r in selection)

        result_text = []
        for r in range(min_row, max_row + 1):
            row_data = []
            for c in range(min_col, max_col + 1):
                item = self.table.item(r, c)
                # 병합된 셀이나 비어있는 셀 대응
                text = item.text() if item else ""
                row_data.append(text)
            result_text.append("\t".join(row_data))
        
        QApplication.clipboard().setText("\n".join(result_text))

    def paste_selection(self):
        """클립보드 내용을 현재 위치부터 붙여넣기"""
        text = QApplication.clipboard().text()
        if not text: return
        
        curr = self.table.currentItem()
        if not curr: return

        r_start, c_start = curr.row(), curr.column()
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = r_start + i, c_start + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    item = self.table.item(r, c)
                    if item: item.setText(val)

class MainApp(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        btn = QPushButton("제 1세트 창 열기")
        btn.clicked.connect(lambda: Set1Window().exec_()) 
        layout.addWidget(btn)
        self.setLayout(layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    m = MainApp()
    m.show()
    sys.exit(app.exec_())
