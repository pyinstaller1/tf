import sys
import os
import pandas as pd
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont

class Set1Window(QDialog):
    def __init__(self):
        super().__init__()
        self.filename = "임금점수산정.xlsx"
        self.setWindowTitle("제 1세트: 총인건비 발생액 산출 (실무 항목 적용)")
        self.setGeometry(100, 100, 1300, 900)
        self.check_and_create_excel()
        self.initUI()

    def check_and_create_excel(self):
        if not os.path.exists(self.filename):
            df = pd.DataFrame([[""] * 5] * 50, columns=["영역", "항목명", "2025", "2024", "2023"])
            df.to_excel(self.filename, index=False)

    def initUI(self):
        layout = QVBoxLayout()
        info = QLabel("💡 흰색 칸에 금액을 입력하세요. 소계/합계(하늘색)는 자동 계산됩니다.")
        info.setStyleSheet("color: #2c3e50; font-weight: bold; margin: 5px;")
        layout.addWidget(info)

        # 항목이 많아졌으므로 55행으로 확장
        self.table = QTableWidget(55, 5)
        self.table.setHorizontalHeaderLabels(["영역(A)", "항목명(B)", "2025(C)", "2024(D)", "2023(E)"])
        
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(1, 650) # B열 항목명이 길어서 더 넓게 설정
        self.table.setColumnWidth(2, 140)
        self.table.setColumnWidth(3, 140)
        self.table.setColumnWidth(4, 140)
        
        self.table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.table.setContextMenuPolicy(Qt.DefaultContextMenu)
        
        self.setup_table_content()
        self.table.itemChanged.connect(self.calculate_totals)
        
        layout.addWidget(self.table)
        
        save_btn = QPushButton("엑셀 파일로 저장하기 (B열 너비/병합/배경색 유지)")
        save_btn.setFixedHeight(50)
        save_btn.setStyleSheet("background-color: #3498db; color: white; font-weight: bold;")
        save_btn.clicked.connect(self.save_to_excel)
        layout.addWidget(save_btn)

        self.setLayout(layout)

    def setup_table_content(self):
        self.table.blockSignals(True)
        for r in range(55):
            for c in range(5):
                self.table.setItem(r, c, QTableWidgetItem("0"))

        # 1번째 A열 병합 (0~31행)
        self.table.setSpan(0, 0, 32, 1)
        self.table.item(0, 0).setText("실집행액 기준\n총인건비 발생액 산출")
        # 2번째 A열 병합 (32~54행)
        self.table.setSpan(32, 0, 23, 1)
        self.table.item(32, 0).setText("전년대비 조정된\n총인건비 발생액 산출")

        # B열 항목 상세 입력
        content = {
            # 1. 인건비 총액 섹션
            0: "1. 인센티브 상여금을 제외한 인건비 총액",
            1: "  a. 판관비로 처리한 인건비 <주1>",
            2: "  b. 영업외비용으로 처리한 인건비 <주2>",
            3: "  c. 제조원가로 처리한 인건비 <주3>",
            4: "  d. 타계정대체로 처리한 인건비 <주4>",
            5: "  e. 이익잉여금의 증감으로 처리한 인건비 <주5>",
            6: "소계 : (A)=a+b+c+d+e",
            
            # 구분선 역할을 위한 빈 줄 (7번 행)
            
            # 2. 조정되는 인건비 섹션
            8: "2. 총인건비 인상률 계산에서 제외(조정)되는 인건비",
            9: "  f. 퇴직급여(명예퇴직금 포함) <주6>",
            10: "  g. 임원 인건비<주7>",
            11: "  h. 비상임이사 인건비<주8>",
            12: "  i. 인상률 제외 인건비<주9>",
            13: "  j. 사내근로복지기금출연금<주10>",
            14: "  k. 잡급 및 무기계약직에 대한 인건비(복리후생비 포함, 인센티브상여금 제외) <주11>",
            15: "  l. 공적보험 사용자부담분<주12>",
            16: "  m. 연월차수당 등 조정(㉠-㉡+㉢)<주13>",
            17: "    - 연월차수당 등 발생액(㉠)",
            18: "    - 연월차수당 등 지급액(㉡)",
            19: "    - 종업원 저리 대여금 이자 관련 인건비(㉢)",
            20: "  n. 저리·무상대여 이익<주14>",
            21: "  o. 지방이전 관련 직접 인건비<주15>",
            22: "  p. 법령에 따른 특수건강진단비<주16>",
            23: "  q. 해외근무수당<주17>",
            24: "  r. 직무발명보상금<주18>",
            25: "  s. 공무원 수준 내 지급되는 자녀수당 및 출산축하금<주19>",
            26: "  t. 야간간호특별수당<주20>",
            27: "  u. 비상진료체계 운영에 따른 특별수당 등<주21>",
            28: "  v. 통상임금 판단기준 변경 판례의 영향으로 인한 법정수당 증가분(2024년 귀속분) <주22>",
            29: "소계 : (B)=f+g+h+i+j+k+l+m-n+o+p+q+r+s+t+u+v",
            31: "3. 실집행액기준 총인건비 발생액 (C)=(A)-(B)",

            # 2번째 영역 섹션
            33: "4. 연도별 증원소요 인건비의 영향을 제거하기 위한 인건비의 조정(D) <주23>",
            34: "5. 별도직군 승진시기 차이에 따른 인건비 효과 조정(E) <주24>",
            35: "6. 초임직급 정원 변동에 따른 인건비 효과 조정(F) <주25>",
            36: "7. 정년이후 재고용을 전제로 전환된 정원외인력의 인건비 효과 조정(G) <주26>",
            37: "8. 생산량증가로 인하여 ’25년도’에 추가로 지급된 인건비의 영향 제거(H) <주27>",
            38: "9. 최저임금 지급 직원에 대한 인건비 효과 조정(I) <주28>",
            39: "10. 파업 등에 따른 인건비 효과 조정(J) <주29>",
            40: "11. 통상임금 판단기준 변경 판례의 영향으로 인한 법정수당 증가분(2025년 귀속분) (K) <주30>",
            42: "12. 총인건비 인상률 계산대상 총인건비 발생액",
            43: "  = (C)+(D)+(E)-(F)-(G)-(H)+(I)+(J)-(K) <주31>"
        }

        # 하늘색 배경 (수식/제목행)
        readonly_rows = [0, 6, 8, 29, 31, 32, 42, 43]
        # 구분선용 공백행 (입력 불가)
        empty_rows = [7, 30, 32, 41]

        for r in range(55):
            if r in content:
                self.table.item(r, 1).setText(content[r])
            
            # 숫자 우측 정렬
            for c in range(2, 5):
                self.table.item(r, c).setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

            # 스타일 설정
            if r in readonly_rows or r in empty_rows:
                for c in range(5):
                    item = self.table.item(r, c)
                    if r in readonly_rows: item.setBackground(QColor(220, 235, 245))
                    if r in empty_rows: 
                        item.setBackground(QColor(250, 250, 250))
                        item.setText("")
                    item.setFlags(item.flags() ^ Qt.ItemIsEditable)
                    font = QFont(); font.setBold(True); item.setFont(font)

        self.table.blockSignals(False)

    def get_val(self, r, c):
        try: return int(float(self.table.item(r, c).text().replace(',', '') or 0))
        except: return 0

    def calculate_totals(self):
        self.table.blockSignals(True)
        for c in range(2, 5):
            # (A) 소계 : 1~5행 합산
            val_a = sum(self.get_val(r, c) for r in range(1, 6))
            self.table.item(6, c).setText(format(val_a, ","))

            # (B) 소계 : f~v 합산 (n은 뺌)
            # f(9) ~ v(28) 중 m(16)은 별도 계산(17-18+19)
            val_m = self.get_val(17, c) - self.get_val(18, c) + self.get_val(19, c)
            self.table.item(16, c).setText(format(val_m, ","))
            
            val_b = sum(self.get_val(r, c) for r in [9,10,11,12,13,14,15,16,21,22,23,24,25,26,27,28]) - self.get_val(20, c)
            self.table.item(29, c).setText(format(val_b, ","))

            # (C) = (A) - (B)
            val_c = val_a - val_b
            self.table.item(31, c).setText(format(val_c, ","))

            # 최종 합계 (42번행)
            # (C:31)+(D:33)+(E:34)-(F:35)-(G:36)-(H:37)+(I:38)+(J:39)-(K:40)
            final = val_c + self.get_val(33, c) + self.get_val(34, c) - self.get_val(35, c) - \
                    self.get_val(36, c) - self.get_val(37, c) + self.get_val(38, c) + \
                    self.get_val(39, c) - self.get_val(40, c)
            self.table.item(43, c).setText(format(final, ","))
            
        self.table.blockSignals(False)

    def contextMenuEvent(self, event):
        if self.table.underMouse():
            menu = QMenu(self); cp = menu.addAction("복사"); ps = menu.addAction("붙여넣기")
            action = menu.exec_(event.globalPos())
            if action == cp: self.copy_selection()
            elif action == ps: self.paste_selection()

    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C: self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V: self.paste_selection()
        else: super().keyPressEvent(event)

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []
        for r in range(min_r, max_r + 1):
            row = [self.table.item(r, c).text() for c in range(min_c, max_c + 1)]
            lines.append("\t".join(row))
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        r_s, c_s = curr.row(), curr.column()
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                if r_s+i < self.table.rowCount() and c_s+j < self.table.columnCount():
                    item = self.table.item(r_s+i, c_s+j)
                    if item and (item.flags() & Qt.ItemIsEditable):
                        try: cv = str(int(float(val.strip().replace(',', ''))))
                        except: cv = val.strip()
                        item.setText(cv)

    def save_to_excel(self):
        from openpyxl.styles import Alignment, PatternFill
        data = [[self.table.item(r, c).text().replace(',', '') for c in range(5)] for r in range(55)]
        df = pd.DataFrame(data, columns=["영역", "항목명", "2025", "2024", "2023"])
        with pd.ExcelWriter(self.filename, engine='openpyxl') as writer:
            df.to_excel(writer, index=False); ws = writer.sheets['Sheet1']
            sky = PatternFill(start_color="DCEBF5", end_color="DCEBF5", fill_type="solid")
            for r_idx in [2, 8, 10, 31, 33, 34, 44, 45]:
                for c_idx in range(1, 6): ws.cell(row=r_idx, column=col_idx).fill = sky
            ws.column_dimensions['A'].width = 25
            ws.column_dimensions['B'].width = 80
            for col in ['C', 'D', 'E']: ws.column_dimensions[col].width = 18
            ws.merge_cells('A2:A33'); ws.merge_cells('A34:A56')
            for cell in ['A2', 'A34']:
                ws[cell].alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                ws[cell].fill = sky
        QMessageBox.information(self, "저장 완료", "엑셀 저장이 완료되었습니다.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = Set1Window(); win.show(); sys.exit(app.exec_())
