import sys
import os
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, 
    QVBoxLayout, QHBoxLayout, QTextEdit, QScrollArea
)
from PyQt5.QtCore import Qt
from openpyxl import Workbook # 최초 생성용

# --- 설정 및 데이터 ---
EXCEL_FILENAME = "업무분장_기초자료.xlsx"
# (ALL_PERSONS, data, ANALYSIS_DATA 등은 기존과 동일)

class SimpleFilterApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("업무 키워드 분석기 (조회 전용)")
        self.setGeometry(100, 100, 900, 800)
        self.init_ui()
        
        # 시작할 때 기초 엑셀 파일 한 번만 생성 (보안 통과용)
        self.create_initial_excel()

    def create_initial_excel(self):
        """처음에 엑셀 파일이 없으면 양식만 딱 한 번 생성"""
        if not os.path.exists(EXCEL_FILENAME):
            try:
                wb = Workbook()
                ws = wb.active
                ws.title = "키워드분석결과"
                ws.append(["담당자", "고유 키워드(자동추출)"])
                
                for p in ALL_PERSONS:
                    keywords = ANALYSIS_DATA.get(p, {}).get('only_keywords', [])
                    ws.append([p, ", ".join(keywords)])
                
                wb.save(EXCEL_FILENAME)
                print(f"기초 파일 '{EXCEL_FILENAME}' 생성 완료")
            except Exception as e:
                print(f"파일 생성 실패 (보안): {e}")

    def init_ui(self):
        main_layout = QVBoxLayout()

        # 1. 상단: 담당자별 키워드 버튼 (조회용)
        top_scroll = QScrollArea()
        top_scroll.setWidgetResizable(True)
        top_widget = QWidget()
        top_vbox = QVBoxLayout(top_widget)

        for person in ALL_PERSONS:
            p_layout = QHBoxLayout()
            p_label = QLabel(f"<b>{person}</b>")
            p_label.setFixedWidth(80)
            p_layout.addWidget(p_label)

            # 고유 키워드 버튼들
            for word, c_self, c_others in ANALYSIS_DATA[person]['analysis']:
                btn = QPushButton(f"{word} ({c_self})")
                btn.setStyleSheet("padding: 5px; background-color: #f0f0f0;")
                # 클릭 시 하단에 관련 문장 필터링 출력
                btn.clicked.connect(lambda checked, w=word: self.display_sentences(w))
                p_layout.addWidget(btn)
            
            p_layout.addStretch(1)
            top_vbox.addLayout(p_layout)
        
        top_scroll.setWidget(top_widget)
        main_layout.addWidget(top_scroll, 1)

        # 2. 하단: 문장 필터링 결과 출력창
        self.result_display = QTextEdit()
        self.result_display.setReadOnly(True)
        self.result_display.setPlaceholderText("키워드 버튼을 클릭하면 관련 문장들이 여기에 표시됩니다.")
        main_layout.addWidget(self.result_display, 2)

        self.setLayout(main_layout)

    def display_sentences(self, keyword):
        """클릭한 키워드가 포함된 문장들을 하단에 출력"""
        filtered = [item for item in data if keyword in item[0]]
        
        html = f"<h3>키워드 '{keyword}' 분석 결과</h3><table border='1' width='100%' style='border-collapse:collapse;'>"
        html += "<tr style='background-color:#eee;'><th>문장 내용</th><th>기존 담당</th></tr>"
        
        for sentence, person in filtered:
            # 키워드 강조
            highlighted = sentence.replace(keyword, f"<b style='color:red;'>{keyword}</b>")
            html += f"<tr><td>{highlighted}</td><td align='center'>{person}</td></tr>"
        
        html += "</table>"
        self.result_display.setHtml(html)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = SimpleFilterApp()
    window.show()
    sys.exit(app.exec_())
