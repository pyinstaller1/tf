import sys
import os
import json
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, 
    QVBoxLayout, QHBoxLayout, QTextEdit, QSizePolicy, QMessageBox
)
from PyQt5.QtCore import Qt, QMimeData, QPoint
from PyQt5.QtGui import QDrag
from collections import defaultdict, Counter 

# 엑셀 처리를 위한 라이브러리 및 스타일 임포트
try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill 
except ImportError:
    print("오류: openpyxl 라이브러리가 설치되어 있지 않습니다.")
    print("명령 프롬프트에서 'pip install openpyxl'을 실행해주세요.")
    sys.exit(1)

# --- 설정 파일 경로 및 데이터 ---
EXCEL_FILENAME = "분장.xlsx"
ALL_PERSONS = ['김영수', '박영희', '최민수', '이철민', '정수현', '신규담당자'] 

# 확장된 데이터
data = [
    # 김영수 (7건)
    ['대한민국의 발전과 미래 성장 전략', '김영수'], ['영국의 발전사 연구', '김영수'], ['글로벌 시장 분석 보고서', '김영수'],
    ['성장 동력 확보 방안', '김영수'], ['미래 기술 전망과 발전 방향', '김영수'], ['국가 경쟁력 강화 방안', '김영수'],
    ['분석 기법의 발전과 활용', '김영수'], 
    
    # 박영희 (7건)
    ['잘 놀기 위한 팁과 전략', '박영희'], ['유럽 문화의 이해와 특징', '박영희'], ['여행과 여가 시간 활용 방안', '박영희'],
    ['삶의 질 향상을 위한 접근', '박영희'], ['문화 교류 증진 프로그램', '박영희'], ['영국의 문화 및 예술', '박영희'],
    ['새로운 여가 트렌드 분석', '박영희'], 
    
    # 최민수 (7건)
    ['미래 발전 전략 수립', '최민수'], ['기술 혁신과 시장 변화 예측', '최민수'], ['인공지능 도입 효과 분석', '최민수'],
    ['데이터 분석 활용 사례', '최민수'], ['전략적 의사결정 방법론', '최민수'], ['성공적인 디지털 전환 사례', '최민수'],
    ['비즈니스 모델 혁신', '최민수'], 
    
    # 이철민 (7건)
    ['공급망 관리 최적화 기법', '이철민'], ['물류 시스템의 효율화 방안', '이철민'], ['국제 무역 규제 동향 분석', '이철민'],
    ['재고 관리의 중요성', '이철민'], ['해외 시장 개척 전략', '이철민'], ['수출입 통관 절차 이해', '이철민'],
    ['운송 비용 절감 방안', '이철민'],
    
    # 정수현 (7건)
    ['고객 만족도 향상 프로젝트', '정수현'], ['서비스 디자인 방법론', '정수현'], ['VOC 분석을 통한 개선점 도출', '정수현'],
    ['사용자 경험(UX) 개선 방안', '정수현'], ['마케팅 캠페인 성과 측정', '정수현'], ['브랜드 이미지 구축 전략', '정수현'],
    ['온라인 커뮤니케이션 강화', '정수현'],
]


def analyze_data_for_pyqt(data):
    all_person_words = defaultdict(list)
    for sentence, person in data: all_person_words[person].extend(sentence.split(' '))
    all_person_counts = {p: Counter(w) for p, w in all_person_words.items()}
    final_comparison_result = {}
    
    for target_person in ALL_PERSONS:
        target_counts = all_person_counts.get(target_person, Counter())
        current_person_results = []
        excel_initial_keywords = []

        if not target_counts:
            final_comparison_result[target_person] = {'analysis': [], 'only_keywords': []}
            continue

        for word, count_self in target_counts.most_common():
            if len(word) < 2: continue 
            
            count_others = sum(
                other_counts.get(word, 0)
                for other_person, other_counts in all_person_counts.items()
                if other_person != target_person
            )
            
            # 1. PyQt 버튼 생성 조건 (Self > 1 and Self > Others) 
            if count_self > 1 and count_self > count_others:
                 current_person_results.append((word, count_self, count_others))
            
            # 2. Excel 초기 생성 조건 (Self >= 2 and Others = 0) - (예: 미래 2/1은 제외됨)
            if count_self >= 2 and count_others == 0: 
                excel_initial_keywords.append(word)
                
        final_comparison_result[target_person] = {'analysis': current_person_results, 'only_keywords': excel_initial_keywords}
    return final_comparison_result

ANALYSIS_DATA = analyze_data_for_pyqt(data)


# --- 2. DragButton 및 PersonDropLabel 클래스 정의 ---
class DragButton(QPushButton):
    def __init__(self, text, keyword, person):
        super().__init__(text)
        self.keyword = keyword 
        self.person = person 
        self.drag_start_position = None
        self.setStyleSheet("padding: 5px; margin: 2px;")
        
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_start_position = event.pos() 
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        # 드래그 안정화 로직: 움직인 거리가 임계값보다 클 때 QDrag 시작
        if event.buttons() & Qt.LeftButton and self.drag_start_position is not None:
            if (event.pos() - self.drag_start_position).manhattanLength() > QApplication.startDragDistance():
                self.start_drag()
                return 
        super().mouseMoveEvent(event)
        
    def start_drag(self):
        # QMimeData 설정 (QDrag 객체 생성 전 반드시 필요)
        mime_data = QMimeData()
        data_to_save = f'{{"keyword": "{self.keyword}", "person": "{self.person}"}}'
        mime_data.setData("application/x-keyword-assignment", data_to_save.encode('utf-8'))
        
        drag = QDrag(self)
        drag.setMimeData(mime_data) # MimeData 설정
        
        # 시각화 설정 (선택 사항)
        drag.setPixmap(self.grab()) 
        drag.setHotSpot(self.rect().center()) 
        
        # QDrag 실행 (PyQt5)
        drag.exec_(Qt.CopyAction) 
        
        # 드래그가 끝난 후 시작 위치 초기화
        self.drag_start_position = None


class PersonDropLabel(QLabel):
    def __init__(self, person_name, parent_app):
        super().__init__(person_name)
        self.person_name = person_name
        self.parent_app = parent_app
        self.setAcceptDrops(True)
        self.setStyleSheet("font-size: 12pt; padding-right: 10px; font-weight: bold; background-color: #E0E0FF;") 
        self.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Preferred)
        self.setAlignment(Qt.AlignCenter)

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat("application/x-keyword-assignment"):
            event.accept()
            self.setStyleSheet("font-size: 12pt; padding-right: 10px; font-weight: bold; background-color: #B0C4DE;")
        else:
            event.ignore()
    
    # 드롭 영역 안정화
    def dragMoveEvent(self, event):
        if event.mimeData().hasFormat("application/x-keyword-assignment"):
            event.accept()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self.setStyleSheet("font-size: 12pt; padding-right: 10px; font-weight: bold; background-color: #E0E0FF;")
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        import json
        self.setStyleSheet("font-size: 12pt; padding-right: 10px; font-weight: bold; background-color: #E0E0FF;") 
        
        mime_data = event.mimeData()
        if mime_data.hasFormat("application/x-keyword-assignment"):
            try:
                data_bytes = mime_data.data("application/x-keyword-assignment")
                data_str = data_bytes.data().decode('utf-8')
                data_dict = json.loads(data_str)
                
                keyword = data_dict['keyword']
                target_person = self.person_name 
                
                success = self.parent_app.save_to_excel(keyword, target_person)

                if success:
                    QMessageBox.information(self, "저장 및 갱신 안내", 
                                            f"'{target_person}'에게 키워드 '{keyword}'를 성공적으로 추가했습니다.\n\n"
                                            f"**최신 내용을 보려면 '엑셀 닫고 다시 열기 (갱신)' 버튼을 누르세요.**")
                    
                else:
                    QMessageBox.critical(self, "오류", "엑셀 파일 저장 중 오류가 발생했습니다. 파일이 열려있는지 확인하세요.")
                
            except Exception as e:
                QMessageBox.critical(self, "오류", f"데이터 처리 중 예상치 못한 오류 발생: {e}")

            event.accept()
        else:
            event.ignore()


# --- 3. 메인 애플리케이션 클래스 ---
class FilterApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("키워드 분장 및 엑셀 저장")
        self.setGeometry(100, 100, 1000, 700) 
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.ANALYSIS_DATA = ANALYSIS_DATA
        self.init_ui()

    def reload_excel_file(self):
        reply = QMessageBox.question(self, '엑셀 갱신 확인', 
                                     f"'{EXCEL_FILENAME}' 파일을 닫고 최신 내용으로 다시 엽니다.\n"
                                     "**작업 중인 내용이 있다면 반드시 엑셀에서 저장한 후, 수동으로 닫아주세요.**\n\n"
                                     "계속하시겠습니까?",
                                     QMessageBox.Yes | QMessageBox.No)

        if reply == QMessageBox.Yes:
            try:
                os.startfile(EXCEL_FILENAME)
                QMessageBox.information(self, "성공", "엑셀 파일을 다시 열었습니다. (수동으로 닫았는지 확인하세요)")
            except AttributeError:
                QMessageBox.warning(self, "경고", "현재 환경에서 파일을 자동으로 열 수 없습니다. 수동으로 파일을 닫고 다시 열어주세요.")
            except Exception as e:
                QMessageBox.critical(self, "오류", f"엑셀 파일을 여는 중 오류가 발생했습니다: {e}")


    def save_to_excel(self, keyword, person):
        try:
            if not os.path.exists(EXCEL_FILENAME):
                wb = Workbook()
                ws = wb.active
                header_font = Font(color="FFFFFF", bold=True)
                header_fill = PatternFill(start_color="0000FF", end_color="0000FF", fill_type="solid")
                ws['A1'], ws['B1'] = '담당자 이름', '키워드 목록'
                ws['A1'].font, ws['B1'].font = header_font, header_font
                ws['A1'].fill, ws['B1'].fill = header_fill, header_fill
                row_num = 2
                for p in ALL_PERSONS:
                    data_dict = self.ANALYSIS_DATA.get(p, {'only_keywords': []})
                    ws[f'A{row_num}'] = p
                    # 🌟 only_keywords (Others = 0)만 초기 기록
                    ws[f'B{row_num}'] = ', '.join(data_dict['only_keywords'])
                    row_num += 1
                ws.column_dimensions['A'].width = 15
                ws.column_dimensions['B'].width = 50
            else: 
                wb = load_workbook(EXCEL_FILENAME)
                ws = wb.active
            
            # 드래그앤드롭으로 인한 키워드 추가
            found_row = -1
            for row in range(2, ws.max_row + 1):
                if ws[f'A{row}'].value == person:
                    found_row = row
                    break
            if found_row == -1:
                new_row = ws.max_row + 1
                ws[f'A{new_row}'] = person
                ws[f'B{new_row}'] = keyword 
            else:
                current_keywords = ws[f'B{found_row}'].value
                if current_keywords:
                    keyword_list = [k.strip() for k in str(current_keywords).split(',')]
                    clean_keyword_list = [k.split(' (')[0] for k in keyword_list]
                    if keyword not in clean_keyword_list:
                        keyword_list.append(keyword)
                    new_keyword_str = ', '.join(keyword_list)
                else:
                    new_keyword_str = keyword
                ws[f'B{found_row}'] = new_keyword_str
            wb.save(EXCEL_FILENAME)
            return True
        except Exception as e:
            QMessageBox.critical(None, "Excel 오류", 
                                 f"🚨 엑셀 파일 저장 실패: 파일이 열려있을 수 있습니다.\n"
                                 f"드래그앤드롭 전에 반드시 '{EXCEL_FILENAME}' 파일을 닫고 재시도하세요.")
            print(f"Excel Save Error: {e}")
            return False

    def init_ui(self):
        main_vbox = QVBoxLayout()
        top_buttons_widget = QWidget()
        top_vbox = QVBoxLayout(top_buttons_widget)
        for person, data_dict in self.ANALYSIS_DATA.items():
            word_list = data_dict['analysis']
            person_hbox = QHBoxLayout()
            person_label = PersonDropLabel(person, self) 
            person_hbox.addWidget(person_label)
            for word, count_self, count_others in word_list:
                button_text = f"{word} {count_self}/{count_others}"
                button = DragButton(button_text, word, person) 
                button.clicked.connect(lambda checked, w=word: self.display_on_click(w))
                person_hbox.addWidget(button)
            person_hbox.addStretch(1) 
            top_vbox.addLayout(person_hbox)
        top_vbox.addStretch(1) 
        main_vbox.addWidget(top_buttons_widget, 4) 
        bottom_hbox = QHBoxLayout()
        self.refresh_button = QPushButton("🚨 엑셀 닫고 다시 열기 (갱신)")
        self.refresh_button.setStyleSheet("background-color: #FFD700; color: black; font-weight: bold; padding: 10px;")
        self.refresh_button.clicked.connect(self.reload_excel_file)
        self.refresh_button.setFixedWidth(250) 
        self.generic_textbox = QTextEdit()
        self.generic_textbox.setPlaceholderText("여기에 버튼 클릭 결과가 출력됩니다.")
        bottom_hbox.addWidget(self.refresh_button, 1) 
        bottom_hbox.addWidget(self.generic_textbox, 4) 
        main_vbox.addLayout(bottom_hbox, 6) 
        self.setLayout(main_vbox)

    def display_on_click(self, keyword):
        filtered_list = [item for item in data if keyword in item[0]]
        html_output = f"<p style='font-size:14pt; color:blue; font-weight:bold;'>--- 키워드: '{keyword}' 필터링 결과 (클릭 영역) ---</p>"
        html_output += "<table border='0' cellspacing='0' cellpadding='5' style='font-size:11pt; width:100%;'>"
        for sentence, person in filtered_list:
            highlighted_sentence = sentence.replace(keyword, f"<span style='color:blue; font-weight:bold;'>{keyword}</span>")
            html_output += "<tr>"
            html_output += f"<td style='text-align:left; vertical-align:top;'>{highlighted_sentence}</td>"
            html_output += f"<td style='text-align:right; font-weight:bold; padding-left:20px; width:100px; vertical-align:top;'>{person}</td>"
            html_output += "</tr>"
        html_output += "</table>"
        self.generic_textbox.setHtml(html_output)


if __name__ == '__main__':
    try:
        from PyQt5.QtWidgets import QApplication
    except ImportError:
        print("오류: PyQt5 라이브러리가 설치되어 있지 않습니다. 'pip install pyqt5'를 실행해주세요.")
        sys.exit(1)
        
    app = QApplication(sys.argv)
    
    # 엑셀 파일 초기 생성 (Others=0 조건 충족 키워드만)
    if not os.path.exists(EXCEL_FILENAME):
        temp_app = FilterApp() 
        temp_app.save_to_excel(keyword="초기화", person="시스템")
        del temp_app
        
    # 엑셀 파일 자동 열기
    try:
        os.startfile(EXCEL_FILENAME)
        print(f"'{EXCEL_FILENAME}' 파일이 열렸습니다. PyQt 창이 그 위에 표시됩니다.")
    except Exception as e:
        QMessageBox.critical(None, "파일 열기 오류", f"엑셀 파일을 여는 데 실패했습니다: {e}")
    
    # 메인 프로그램 실행
    window = FilterApp()
    window.show()
    sys.exit(app.exec_())
