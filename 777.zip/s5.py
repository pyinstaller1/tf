from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QKeySequence, QFont

rank_count = 8


# [2] 실시간 우측 정렬 델리게이트 (s5용 통합 버전)
class S5RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 테이블 전체에 이벤트 필터를 설치하여 평소 상태 감시
        if parent:
            parent.installEventFilter(self)
            
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 입력 중(에디터 활성화)일 때도 키 감시
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택만)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력 중이 아니거나(테이블), 커서가 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력 중이 아니거나(테이블), 커서가 앞일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 단순 선택(Index 변경)만 수행"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)






class s5ThousandSeparatorItem(QTableWidgetItem):
    
    def data(self, role):

        def s_round(val, precision = 2):
            num = float(str(val).replace(',', ''))
            return format(round(num + 1e-9, precision), ",.2f")
        
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "":
                return ""
            try:
                # num = float(str(val).replace(',', ''))
                # return format(num, ",.2f")
                num = s_round(float(str(val).replace(',', '')), 2)
                return num
            except:
                return val
        return super().data(role)






class Sheet5Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent

        global rank_count
        rank_count = len(self.main_window.list_title_05)
        
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-3) 가. 정원 및 현원")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        self.table = QTableWidget((rank_count * 2) + 4, 26)
        self.setup_style()
        self.setup_headers()
        self.setup_content()

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        delegate = S5RightAlignedDelegate(self.table)
        for c in range(2, 26):
            self.table.setItemDelegateForColumn(c, delegate)

        self.table.itemChanged.connect(self.calculate_s5)
        layout.addWidget(self.table)

    def setup_style(self):
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.verticalHeader().setFixedWidth(25)

        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            
            /* 헤더 스타일 */
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;
            }

            /* 가로 스크롤바 스타일 개선 */
            QScrollBar:horizontal {
                border: 1px solid #d0d0d0;
                background: #f0f0f0;
                height: 12px;
                margin: 0px 0px 0px 0px;
            }
            QScrollBar::handle:horizontal {
                background: #bcbcbc; /* 스크롤 핸들 색상 (진한 회색) */
                min-width: 20px;
                border-radius: 5px;
            }
            QScrollBar::handle:horizontal:hover {
                background: #a0a0a0; /* 마우스 올렸을 때 더 진하게 */
            }

            /* 세로 스크롤바 스타일 개선 */
            QScrollBar:vertical {
                border: 1px solid #d0d0d0;
                background: #f0f0f0;
                width: 12px;
                margin: 0px 0px 0px 0px;
            }
            QScrollBar::handle:vertical {
                background: #bcbcbc;
                min-height: 20px;
                border-radius: 5px;
            }
            QScrollBar::handle:vertical:hover {
                background: #a0a0a0;
            }
            
            /* 스크롤바 상하단 화살표 제거 (더 깔끔하게) */
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                width: 0px; height: 0px;
            }
            
        """)



    def setup_headers(self):
        h_labels = ["구분", "직급"]
        for m in range(1, 7):
            for sub in ["정원", "현원", "복직자", "누적차"]:
                h_labels.append(f"{m}월\n{sub}")
        self.table.setHorizontalHeaderLabels(h_labels)
        self.table.horizontalHeader().setFixedHeight(45)
        
        self.table.setColumnWidth(0, 30) 
        self.table.setColumnWidth(1, 60)
        for c in range(2, 26): self.table.setColumnWidth(c, 70)

    def setup_content(self):
        self.table.blockSignals(True)
        
        # 1. 다른 시트와 동일한 행수 계산 방식 (9*2 + 3 = 21행)
        # 전년도(rank_count) + 구분선(1) + 헤더(1) + 당년도(rank_count) + 주석(1)
        self.table.setRowCount((rank_count * 2) + 4)
        self.table.setColumnCount(26)

        # 2. 직급 리스트 명시적 선언 (유지보수 시 이 부분만 수정)
        ranks = list(self.main_window.list_title_05)
        # ranks = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직", "계"]
        
        # 3. 행 위치 변수 (다른 시트와 동일 로직)
        sep_row1 = rank_count            # 9
        title_row = sep_row1 + 1         # 10
        data2_start_idx = title_row + 1  # 11
        sep_row2 = data2_start_idx + rank_count # 20
        comment_row = sep_row2 + 1       # 21

        bold_font = QFont(); bold_font.setBold(True)

        # --- [첫 번째 표 생성] ---
        year_item1 = QTableWidgetItem("당\n년\n도") # S5 성격에 맞게 '전년도' 또는 '당년도'
        year_item1.setTextAlignment(Qt.AlignCenter)
        year_item1.setBackground(QColor(245, 245, 245))
        self.table.setItem(0, 0, year_item1)
        self.table.setSpan(0, 0, rank_count, 1)

        for r in range(rank_count):
            is_last = (r == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[r])
            it_rank.setTextAlignment(Qt.AlignCenter)
            it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # Editable 제외
            self.table.setItem(r, 1, it_rank)




            for c in range(2, 26):
                it = s5ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                # 계 행이거나 누적차 열이면 강조 및 잠금
                if is_last or (c - 2) % 4 == 3:
                    it.setBackground(self.base_sky_blue); it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(r, c, it)

        # --- [중간 구분선 & 제목줄] ---
        self.table.setRowHeight(rank_count, 15)
        self.table.setRowHeight(rank_count+1, 45)
        for c in range(26):
            self.table.setItem(sep_row1, c, QTableWidgetItem("")) # 구분선
            
            t_it = QTableWidgetItem()
            t_it.setBackground(QColor(240, 240, 240)); t_it.setFont(bold_font); t_it.setTextAlignment(Qt.AlignCenter)
            if c == 0: t_it.setText("구분")
            elif c == 1: t_it.setText("직급")
            else:
                m = 7 + (c - 2) // 4
                sub = ["정원", "현원", "복직자", "누적차"][(c - 2) % 4]
                t_it.setText(f"{m}월\n{sub}")
            self.table.setItem(title_row, c, t_it)

        # --- [두 번째 표 생성] ---
        year_item2 = QTableWidgetItem("당\n년\n도")
        year_item2.setTextAlignment(Qt.AlignCenter)
        year_item2.setBackground(QColor(245, 245, 245))
        self.table.setItem(rank_count + 2, 0, year_item2)
        self.table.setSpan(rank_count + 2, 0, rank_count, 1)

        for i in range(rank_count):
            curr_r = data2_start_idx + i
            is_last = (i == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[i])
            it_rank.setTextAlignment(Qt.AlignCenter)
            it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # Editable 제외

            self.table.setItem(curr_r, 1, it_rank)

            for c in range(2, 26):
                it = s5ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if is_last or (c - 2) % 4 == 3:
                    it.setBackground(self.base_sky_blue); it.setFont(bold_font)
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                self.table.setItem(curr_r, c, it)


        self.table.setRowHeight(sep_row2, 15)
        for c in range(26): 
            self.table.setItem(sep_row2, c, QTableWidgetItem(""))

        comment_row = sep_row2 + 1 
        self.table.setRowHeight(comment_row, 60) 
        self.table.setSpan(comment_row, 0, 1, 26)
        
        comment_text = (
            " * 누적차는 정원의 누적에서 현원의 누적을 차감한 후 복직자의 누적을 가산한 것임.\n"
            "   (이 때 누적은 최상위 직급의 인원부터 해당 직급의 인원까지 순차적으로 합산한 인원임).\n"
            "   누적차가 음수인 경우 근속승진을 의미함."
        )
        comment_it = QTableWidgetItem(comment_text)
        comment_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        # 텍스트가 여러 줄이므로 수직/수평 정렬 조절 (필요 시)
        comment_it.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter) 
        self.table.setItem(comment_row, 0, comment_it)
        
        self.table.blockSignals(False)
        


    def calculate_s5(self, item):

        r, c = item.row(), item.column()
        ranks = self.main_window.list_title_05


        
        # 1. setup_content와 동일한 좌표 기준 (rank_count 기반)
        sep_row1 = rank_count            # 9
        title_row = sep_row1 + 1         # 10
        data2_start = title_row + 1      # 11
        
        # 입력 제외 대상: 구분 열, 누적차 열, 구분선 행, 제목줄 행
        if c < 2 or (c - 2) % 4 == 3 or r in [rank_count, rank_count + 1]: 
            return 
        
        self.table.blockSignals(True)
        try:
            month_base = 2 + ((c - 2) // 4) * 4

            cnt_g = sum(1 for rank in ranks if rank.endswith("급"))


            cnt_1 = 0
            for item in ranks:
                if item.startswith('1'):
                    break
                cnt_1 += 1



                
            # 2. 현재 수정 중인 표의 영역 설정
            if r < rank_count:
                # 표 1 (0 ~ 8행)
                start_row = 0
                mid_row = cnt_g
                last_row = rank_count - 1  # index 8 ('계' 행)
            elif r >= rank_count + 2:
                # 표 2 (11 ~ 19행)
                start_row = rank_count + 2
                mid_row = start_row + cnt_g
                last_row = (rank_count + 2) + rank_count - 1 # index 19 ('계' 행)
                cnt_1 = rank_count + 2 + cnt_1
            else:
                return


            # 3. 각 직급별 누적차 계산 (계 행 제외)
            # range(start_row, last_row) -> 0~7 또는 11~18 (별도직군까지만 계산)

            for row in range(start_row, last_row):   # 연구소장~6급
                
                if cnt_1 <= row < cnt_g + cnt_1:   # 정원_row: "O" (1급~6급)
                    acc = 0
                    for rr in range(cnt_1, row + 1):
                        val_jung = self.cell_value(rr, month_base)     # 정원
                        val_hyun = self.cell_value(rr, month_base + 1) # 현원
                        val_bok = self.cell_value(rr, month_base + 2)  # 복직자
                        acc = acc + (val_jung - val_hyun + val_bok)    # 누적차
                        # 누적차 = 바로위 누적차 + (정원-현원+복직자)
                        
                elif row < cnt_1:      # 정원_row: "X" (소장~위원)
                    val_jung = self.cell_value(row, month_base)     # 정원
                    val_hyun = self.cell_value(row, month_base + 1) # 현원
                    val_bok = self.cell_value(row, month_base + 2)  # 복직자
                    acc = (val_jung - val_hyun + val_bok)           # 누적차
                    # 누적차 = (정원-현원+복직자)
                        



                else:
                    # --- 단일 계산 영역 (mid_row ~ last_row) ---
                    # 이전 행들을 더하지 않고 현재 row의 값만 계산
                    val_jung = self.cell_value(row, month_base)
                    val_hyun = self.cell_value(row, month_base + 1)
                    val_bok = self.cell_value(row, month_base + 2)
                    acc = (val_jung - val_hyun + val_bok)

                # 2. 결과 입력 (공통)
                diff_it = self.table.item(row, month_base + 3)
                if diff_it:
                    diff_it.setData(Qt.EditRole, float(acc))
                    # 음수일 경우 빨간색 표시 (S6ThousandSeparatorItem의 자동 로직이 있다면 중복일 수 있음)
                    diff_it.setForeground(QColor("red") if acc < 0 else QColor("black"))


            




            # 4. '계' 행(last_row)에 세로 합계 입력 (정원, 현원, 복직자만)
            # 누적차(off=3)는 수직 합계에서 제외함
            for off in range(3): 
                col_idx = month_base + off
                v_sum = 0
                
                # 데이터 행(rank_count-1 개)을 순차적으로 합산
                for i in range(rank_count - 1): 
                    v_sum += self.cell_value(start_row + i, col_idx)
                
                # '계' 행의 해당 칸(정원/현원/복직)에 합계 입력
                sum_item = self.table.item(last_row, col_idx)
                if sum_item:
                    sum_item.setData(Qt.EditRole, float(v_sum))
                    # '계' 행 스타일: 굵게 표시 (이전 가이드 준수)
                    font = sum_item.font()
                    font.setBold(True)
                    sum_item.setFont(font)




                
            # 5. 누적차 '계' (마지막 데이터 행인 '별도직군'의 누적차를 복사)
            # index: last_row - 1 은 '별도직군' 행
            last_diff_val = self.cell_value(last_row - 1, month_base + 3)
            total_diff_item = self.table.item(last_row, month_base + 3) # 여기가 진짜 '계' 행
            

            
            
            if total_diff_item:
                #total_diff_item.setData(Qt.EditRole, float(last_diff_val))
                total_diff_item.setText("")  # 빈 문자열로 설정하여 빈칸 처리
                # 색상 동기화
                target_it = self.table.item(last_row - 1, month_base + 3)
                if target_it:
                    total_diff_item.setForeground(target_it.foreground())
            
        finally: 
            self.table.blockSignals(False)
            self.send_to_s11_from_s5()
            
        









    def get_data_for_s6(self):
        result = [[0 for _ in range(12)] for _ in range(rank_count - 1)]

        ranks = self.main_window.list_title_05
        mid_row = sum(1 for rank in ranks if rank.endswith("급"))

        for m in range(12):
            start_row = rank_count + 2 if m >= 6 else 0
            month_block_idx = m % 6
            col = 2 + (month_block_idx * 4) + 3  # 누적차 열
            
            for r in range(rank_count - 1):
                acc = self.cell_value(start_row + r, col)  # 🔥 핵심 수정
                # result[r][m] = abs(acc) if acc < 0 else 0
                result[r][m] = acc
                
        return result


    def send_to_s11_from_s5(self):
        """
        S5의 데이터를 { '직급': [1월~12월 데이터] } 형태의 딕셔너리로 반환
        """
        ranks = list(self.main_window.list_title_05) # ['임원', '임원대우', ..., '합계']
        rank_count = len(ranks)
        
        # 1. 딕셔너리 초기화 { '임원': [0.0, ... 0.0], '1급': [0.0, ...], ... }
        result_dict = {rank: [0.0 for _ in range(12)] for rank in ranks}

        for m in range(12):
            # 하반기(7~12월) 시작 행 위치 계산 (헤더 포함 여부에 따라 조정 필요)
            start_row = (rank_count + 1) if m >= 6 else 0
            
            # 열 위치 계산: 누적차 열 추출 로직 유지
            col = (m % 6 * 4) + 5
            
            for r_idx, rank_name in enumerate(ranks):
                val = self.cell_value(start_row + r_idx, col)
                
                # 데이터 정제 (빈 값/하이픈 처리)
                if val is None or str(val).strip() in ["", "-", "None"]:
                    clean_float = 0.0
                else:
                    try:
                        # 괄호(음수) 및 콤마 처리
                        str_val = str(val).replace(",", "").strip()
                        if "(" in str_val:
                            str_val = "-" + str_val.replace("(", "").replace(")", "")
                        clean_float = float(str_val)
                    except (ValueError, TypeError):
                        clean_float = 0.0
                
                # 딕셔너리에 값 할당
                result_dict[rank_name][m] = clean_float

        return result_dict









    def cell_value(self, r, c):
        """콤마 제거 후 안전하게 float 변환 (에러 방지)"""
        it = self.table.item(r, c)
        if not it: 
            return 0.0
        
        txt = it.text().replace(',', '').strip()
        if not txt: 
            return 0.0
            
        try: 
            return float(txt)
        except ValueError: 
            return 0.0

        



    def copy_selection(self):
        # 선택 영역 가져오기
        ranges = self.table.selectedRanges()
        if not ranges: return
        
        r0, r1 = min(r.topRow() for r in ranges), max(r.bottomRow() for r in ranges)
        c0, c1 = min(r.leftColumn() for r in ranges), max(r.rightColumn() for r in ranges)
        
        lines = []
        for r in range(r0, r1 + 1):
            row_data = []
            for c in range(c0, c1 + 1):
                it = self.table.item(r, c)
                if it:
                    # [수정] 콤마만 제거하고 원본 텍스트 그대로 복사
                    # 작은따옴표(')를 붙이는 로직을 완전히 삭제했습니다.
                    txt = it.text().replace(',', '').strip()
                    row_data.append(txt)
                else:
                    row_data.append("")
            
            lines.append("\t".join(row_data))

        # 클립보드에 설정
        QApplication.clipboard().setText("\n".join(lines))

        
    def paste_selection(self):
        # [수식 제거] 붙여넣을 때도 수식 기호를 떼고 값만 입력합니다.
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
            
        self.table.blockSignals(True)
        affected_rows = set()
        affected_cols = set()

        # [기준 인덱스] rank_count = 9 기준
        sep_row1 = rank_count
        title_row = sep_row1 + 1
        data2_start = title_row + 1
        sep_row2 = data2_start + rank_count
        protected_rows = [sep_row1, title_row, sep_row2]

        for i, line in enumerate(text.splitlines()):
            # 헤더 텍스트 포함 줄은 스킵
            if any(h in line for h in ["월", "정원", "현원", "복직", "직급", "구분"]): 
                continue
                
            cells = line.split('\t')
            for j, val in enumerate(cells):
                r, c = curr.row() + i, curr.column() + j
                
                if r < self.table.rowCount() and c < self.table.columnCount():
                    # 보호 영역(구분, 직급, 누적차 열, 구분선 등) 제외
                    if c < 2 or (c - 2) % 4 == 3 or r in protected_rows:
                        continue
                        
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable):
                        # 수식 기호(=)가 포함되어 있다면 제거하고 숫자만 입력
                        clean_val = val.lstrip("'").split('=')[-1]
                        it.setText(clean_val.strip())
                        affected_rows.add(r)
                        affected_cols.add(c)
                            
        self.table.blockSignals(False) 
        
        # 데이터가 바뀌었으므로 기존 프로그램의 calculate_s5를 호출하여 결과 갱신
        if affected_rows and affected_cols:
            for col in affected_cols:
                if col >= 2:
                    m_idx = (col - 2) // 4
                    col_to_trigger = 2 + (m_idx * 4)
                    
                    # 전년도 영역 갱신
                    if any(r < sep_row1 for r in affected_rows):
                        up_it = self.table.item(0, col_to_trigger)
                        if up_it: self.calculate_s5(up_it)
                    
                    # 당년도 영역 갱신
                    if any(r >= data2_start for r in affected_rows):
                        low_it = self.table.item(data2_start, col_to_trigger)
                        if low_it: self.calculate_s5(low_it)
                        

                
                    

    def show_context_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #c0c0c0;
            }
            QMenu::item {
                padding: 6px 25px;
                color: black;
            }
            QMenu::item:selected {
                background-color: #5fa8f5;
                color: white;
            }
        """)

        menu.addAction("복사", self.copy_selection)
        menu.addAction("붙여넣기", self.paste_selection)
        menu.exec_(self.table.viewport().mapToGlobal(pos))

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
