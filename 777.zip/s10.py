from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QPen

rank_count = 9

class S10RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 생성 시 테이블 자체를 감시하여 평소 상태에서도 키 입력 처리
        if parent:
            parent.installEventFilter(self)
            
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 입력 중(에디터 활성화)일 때도 키 감시를 위해 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (수정 내용 저장 보장)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나(테이블 상태), 커서가 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나, 커서가 시작일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 인덱스만 변경 (자동 편집 진입 제거)"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def setModelData(self, editor, model, index):
        # 쉼표 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)


# [1] Sheet 14 전용 (을) 표시 델리게이트 (S3SymbolDelegate 구조 유지)
class S10SymbolDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        painter.save()
        # 8행(합계), 5열(인건비 효과)에 "(을)" 그리기
        if index.row() == rank_count - 1 and index.column() == 5:
            painter.setPen(QPen(QColor(40, 40, 40))) 
            font = painter.font()
            font.setFamily("맑은 고딕")
            font.setPointSize(15) 
            font.setBold(True)
            painter.setFont(font)
            # 숫자와 겹치지 않게 왼쪽 여백(8) 조정
            painter.drawText(option.rect.adjusted(8, -3, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(을)")
        painter.restore()

class S10ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):

        if role == Qt.ForegroundRole:
            val = super().data(Qt.EditRole)
            try:
                if val is not None and float(str(val).replace(',', '')) < 0:
                    return QColor(Qt.red)
            except:
                pass
            return super().data(role) # 음수가 아니면 기본 색상


        
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "":
                return ""

            try:
                num = float(str(val).replace(',', ''))

                # A, B, C
                if self.column() in (1, 2, 3):
                    return format(num, ",.1f")

                # D, E
                if self.column() in (4, 5):
                    return format(int(num), ",")

            except:
                return val

        return super().data(role)


    

class Sheet10Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent


        global rank_count
        rank_count = len(self.main_window.list_title_10)
        
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()
        

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        title = QLabel("나. 초임직급 정원 변동에 따른 인건비 효과")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        # 11행 6열 구성
        self.table = QTableWidget(rank_count+3, 6)
        
        # [제목줄 설정] 요청하신 순서
        headers = [
            "직급", "전년도\n정원(A)", "당년도\n정원(B)", 
            "증감\n(C)=(B)-(A)", "전년도\n평균단가(D)", "인건비 효과\n(E)=(C)×(D)"
        ]
        self.table.setHorizontalHeaderLabels(headers)
        
        # [스타일 복구] Sheet 3와 동일한 번호열 및 구분선 설정
        self.table.verticalHeader().setFixedWidth(25) # 번호열 너비 고정
        self.table.horizontalHeader().setFixedHeight(45)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)
        self.table.verticalHeader().setDefaultSectionSize(28)

        # 델리게이트 적용
        # self.table.setItemDelegateForRow(8, S10SymbolDelegate(self.table))


        # 1. 델리게이트 객체 생성
        self.delegate = S10RightAlignedDelegate(self.table)
        
        # 2. 데이터가 들어가는 1열(전년정원)부터 5열(인건비효과)까지 델리게이트 연결
        for i in range(1, 6):
            self.table.setItemDelegateForColumn(i, self.delegate)

        # (주의) 기존에 있던 SymbolDelegate는 행 단위이므로 이 아래에 그대로 둡니다.
        self.table.setItemDelegateForRow(rank_count - 1, S10SymbolDelegate(self.table))



        self.setup_content()
        
        # 컬럼 너비 설정
        self.table.setColumnWidth(0, 60)
        for i in range(1, 4): self.table.setColumnWidth(i, 70)
        self.table.setColumnWidth(4, 108)        
        self.table.setColumnWidth(5, 157)

        self.table.itemChanged.connect(self.calculate_s10)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        layout.addWidget(self.table)



    def setup_content(self):
        self.table.blockSignals(True)
        
        # 1. 직급 리스트 (S9과 동일하게 유지)
        ranks_list = list(self.main_window.list_title_10)
        # ranks_list.insert(-1, '기능직')

        # ranks_list = ["1급", "2급", "3급", "4급", "5급", "6급", "연구직", "기능직", "계"]
        # 실제 데이터로 표시할 직급 (계 제외한 순수 직급들)
        current_display_ranks = ranks_list[:rank_count-1] 
        
        # 2. 위치 변수 설정 (rank_count 기준)
        sum_row = rank_count - 1      # 합계(계) 행 위치
        blank_row = sum_row + 1       # 빈 줄
        note_row = sum_row + 2        # 주석 줄
        
        # 전체 행수 설정 (데이터 + 합계 + 빈줄 + 주석)
        self.table.setRowCount(rank_count + 2) 
        self.table.setColumnCount(6)

        # 색상 정의
        ref_yellow = QColor(255, 255, 225) # 외부 참조 (S8, S9)
        
        for r in range(self.table.rowCount()):
            for c in range(6):
                # 데이터/합계 영역만 "0" 초기화
                val = "0" if r <= sum_row and c > 0 else ""
                item = S10ThousandSeparatorItem(val)
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                
                # A. 데이터 행 처리 (0 ~ sum_row-1)
                if r < sum_row:
                    if c == 0: # 직급명
                        item.setText(current_display_ranks[r])
                        item.setTextAlignment(Qt.AlignCenter)
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    elif c in [1, 2, 4]: # 외부 참조 (노란색)
                        item.setBackground(ref_yellow)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    else: # 자동계산 (파란색)
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

                # B. 합계 행 처리 (계)
                elif r == sum_row:
                    item.setBackground(self.base_sky_blue)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    if c == 0:
                        item.setText("계")
                        item.setTextAlignment(Qt.AlignCenter)
                    # (을) 표시 델리게이트 적용을 위해 좌표 저장 (나중에 활용)
                    self.table.setItemDelegateForRow(r, S10SymbolDelegate(self.table))

                # C. 주석 및 기타
                else:
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    item.setBackground(Qt.white)
                    item.setText("")
                
                self.table.setItem(r, c, item)
                    

        # 하단 레이아웃 (rank_count에 따라 가변적)
        self.table.setSpan(blank_row, 0, 1, 6)
        self.table.setRowHeight(blank_row, 15)
        self.table.setSpan(note_row, 0, 1, 6)

        note_html = (
            "<b><span style='font-size:16pt;'>(을)</span></b> : "
            "(3)총인건비인상률 &lt;주25&gt; 칸에 자동 반영<br><br>"
            " * 당년도 및 전년도 각 직급별 정원은 ‘가. 초임직급 정원 변동’의 평균정원을 기재함.<br><br>"
            " * 전년도 평균단가는 Template에서 계산된 전년도 실집행 기준 평균단가임."
        )

        label = QLabel()
        label.setText(note_html)
        label.setTextFormat(Qt.RichText)
        label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        label.setWordWrap(True)

        self.table.setCellWidget(note_row, 0, label)
        self.table.setRowHeight(note_row, 150)
        self.table.blockSignals(False)

        
        













    def calculate_s10(self, item=None):
        import math
        self.table.blockSignals(True)
        try:
            def gv(r, c):
                it = self.table.item(r, c)
                if it is None: return 0.0
                txt = it.text().replace(',', '').strip()
                try:
                    return float(txt) if txt else 0.0
                except ValueError:
                    return 0.0

            def sv(r, c, val):
                it = self.table.item(r, c)
                if not it:
                    return

                # A, B, C
                if c in (1, 2, 3):
                    it.setData(Qt.EditRole, round(float(val), 1))

                # D, E → 정수 반올림
                elif c in (4, 5):
                    it.setData(Qt.EditRole, int(round(val + math.copysign(0.00001, val), 0)))

                else:
                    it.setData(Qt.EditRole, val)



            # 1. 개별 행 계산 (0 ~ rank_count-2)
            for r in range(rank_count - 1):
                v_prev_staff = gv(r, 1) # 전년도 정원(A)
                v_curr_staff = gv(r, 2) # 당년도 정원(B)
                v_diff_staff = v_curr_staff - v_prev_staff # 증감(C)
                
                v_unit_price = gv(r, 4) # 전년도 평균단가(D)

                # 증감(3열) 기록
                sv(r, 3, v_diff_staff)
                
                # 인건비 효과(5열) = 증감(C) * 단가(D)
                sv(r, 5, v_diff_staff * v_unit_price)

            # 2. 합계 행 계산 (rank_count - 1)
            sum_row = rank_count - 1
            
            # --- [수정 포인트: 모든 숫자 열 1, 2, 3, 4, 5의 세로 합계] ---
            total_prev = sum(gv(r, 1) for r in range(sum_row))
            total_curr = sum(gv(r, 2) for r in range(sum_row))
            total_diff = sum(gv(r, 3) for r in range(sum_row))
            # total_price = sum(gv(r, 4) for r in range(sum_row-1))  # 평균단가 단순 합계
            total_effect = sum(gv(r, 5) for r in range(sum_row))

            sv(sum_row, 1, total_prev)
            sv(sum_row, 2, total_curr)
            sv(sum_row, 3, total_diff)
            # sv(sum_row, 4, total_price)   # 나누기 로직 삭제, 단순 합계 기록
            self.table.item(sum_row, 4).setText("")
            sv(sum_row, 5, total_effect)

            if hasattr(self, 'main_window') and self.main_window:
                self.main_window.s2.sync_eul_from_s10(self.get_eul_to_s2())
                
        except Exception as e:
            print(f"S10 Calc Error Safety Catch: {e}")
        finally:
            self.table.blockSignals(False)






            
    def sync_from_s9(self, s9_data):
        """
        S9에서 넘어온 [전년도 리스트, 당년도 리스트]를 S10 테이블에 반영합니다.
        s9_data[0] = 전년도 평균정원 리스트
        s9_data[1] = 당년도 평균정원 리스트
        """
        prev_list, curr_list = s9_data
        
        self.table.blockSignals(True)
        try:
            # S9에서 넘어온 리스트의 개수만큼 반복 (9개라면 9번)
            for r in range(len(prev_list)):
                # 1. 전년도 정원 반영 (B열 / 1번 인덱스)
                it_p = self.table.item(r, 1)
                if it_p: 
                    it_p.setData(Qt.EditRole, prev_list[r])
                
                # 2. 당년도 정원 반영 (C열 / 2번 인덱스) - [주석 해제 및 반영]
                # 리스트 범위 안전 확인 후 데이터 입력
                if r < len(curr_list):
                    it_c = self.table.item(r, 2)
                    if it_c: 
                        it_c.setData(Qt.EditRole, curr_list[r])
                        
        except Exception as e:
            print(f"S10 Sync Error: {e}")
        finally:
            self.table.blockSignals(False)
            
            # 3. 데이터 주입 후 S10의 증감 및 인건비 효과 재계산 트리거
            # 데이터가 있는 첫 번째 행의 아이템을 던져서 calculate_s10 실행
            first_item = self.table.item(0, 1)
            if first_item:
                self.calculate_s10(first_item)
                


    def sync_unit_price_from_s8(self, s8_prices):
        """S8의 전년도 단가를 S10의 4열(D)에 주입 (노란색 칸)"""
        if not s8_prices: return
        self.table.blockSignals(True)
        try:
            for r in range(min(len(s8_prices), rank_count)):
                item = self.table.item(r, 4) # D열
                if item:
                    # 단가는 원 단위 정수로 입력
                    item.setData(Qt.EditRole, str(int(round(s8_prices[r]))))
            
            self.table.blockSignals(False)
            # 데이터 주입 후 S10 재계산 트리거
            self.calculate_s10(self.table.item(0, 4))
            self.table.blockSignals(True)
        finally:
            self.table.blockSignals(False)


    def get_eul_to_s2(self):
        """Sheet2 연동을 위해 (을) 값 추출"""

        sum_row = rank_count - 1 
        it = self.table.item(sum_row, 5)
        
        
        val_str = it.text().replace(',', '') if it and it.text() else "0"
        try:
            return float(val_str)
        except:
            return 0.0


        

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []

        if min_r == 0:
            headers = [self.table.horizontalHeaderItem(c).text().replace('\n', ' ') 
                       if self.table.horizontalHeaderItem(c) else "" for c in range(min_c, max_c + 1)]
            lines.append("\t".join(headers))

        for r in range(min_r, max_r + 1):
            if r >= rank_count: continue 
            
            row_data = []
            for c in range(min_c, max_c + 1):
                # --- [A. 데이터 행: 3번, 5번만 INDEX 수식] ---
                if r < rank_count - 1:
                    if c == 3: # 증감
                        formula = "=INDEX($1:$1048576, ROW(), COLUMN()-1)-INDEX($1:$1048576, ROW(), COLUMN()-2)"
                        row_data.append(formula)
                    elif c == 5: # 인건비 효과
                        formula = "=INDEX($1:$1048576, ROW(), COLUMN()-2)*INDEX($1:$1048576, ROW(), COLUMN()-1)"
                        row_data.append(formula)
                    else: # 0(직급), 1(전년정원), 2(당년정원), 4(평균단가) 값 복사
                        it = self.table.item(r, c)
                        val = it.text().replace(',', '').strip() if it else ""
                        if val.startswith(('=', '-', '+')): val = "'" + val
                        row_data.append(val)

                # --- [B. 계 줄: 모든 숫자 데이터 열(1~5) SUM 적용] ---
                elif r == rank_count - 1:
                    # 사용자님 말씀대로 "계 줄은 계"이므로 4번 포함 모든 열 합계
                    if c in [1, 2, 3, 4, 5]:
                        offset = rank_count - 1
                        formula = (
                            f"=SUM("
                            f"INDEX($1:$1048576, ROW()-{offset}, COLUMN()):"
                            f"INDEX($1:$1048576, ROW()-1, COLUMN())"
                            f")"
                        )
                        row_data.append(formula)
                    else:
                        # 0번(직급 '계') 등은 텍스트 복사
                        it = self.table.item(r, c)
                        val = it.text().replace(',', '').strip() if it else ""
                        row_data.append(val)
            
            if row_data:
                lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))



        

    def paste_selection(self):
        txt = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not txt or not curr: return
        
        self.table.blockSignals(True)
        try:
            for i, line in enumerate(txt.splitlines()):
                for j, val in enumerate(line.split('\t')):
                    r, c = curr.row() + i, curr.column() + j
                    if r < self.table.rowCount() and c < self.table.columnCount():
                        it = self.table.item(r, c)
                        if it:
                            # [핵심] 해당 셀이 편집 가능(Editable)한지 체크
                            # 노란색 셀들은 initUI에서 이 플래그를 뺐기 때문에 여기서 걸러짐
                            if it.flags() & Qt.ItemIsEditable:
                                clean_val = val.strip().replace(',', '')
                                try:
                                    # 숫자라면 콤마 포맷팅해서 입력
                                    f_val = float(clean_val or 0)
                                    it.setText(format(int(f_val), ","))
                                except:
                                    it.setText(val) # 숫자가 아니면 그냥 텍스트 입력
                            else:
                                # 편집 불가능한 셀(노란색 등)은 아무것도 하지 않고 건너뜀
                                pass
        finally:
            self.table.blockSignals(False)
            # 데이터가 바뀌었으니 계산 함수 한 번 호출 (첫 번째 데이터 행 기준)
            sample_item = self.table.item(0, 1)
            if sample_item:
                self.calculate_s10(sample_item)

    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C: self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V: self.paste_selection()
        else: super().keyPressEvent(event)

    def show_context_menu(self, pos):
        menu = QMenu()
        menu.addAction("복사 (Ctrl+C)", self.copy_selection)
        menu.addAction("붙여넣기 (Ctrl+V)", self.paste_selection)
        menu.exec_(self.table.viewport().mapToGlobal(pos))
