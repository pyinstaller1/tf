@echo off
cd /d %~dp0
cls
run\python.exe run\wage.py
pause
