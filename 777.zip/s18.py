from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont

class ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val or val == "n/a" or val == 0 or val == "0": 
                return "0" if (val == 0 or val == "0") else val
            try:
                clean_val = str(val).replace(',', '')
                return format(int(float(clean_val)), ",")
            except: 
                return val
        return super().data(role)

class RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent, protected_rows):
        super().__init__(parent)
        self.protected_rows = protected_rows

    def createEditor(self, parent, option, index):
        # 0열(제목) 및 보호된 행(계산 행)은 편집 불가
        if index.column() == 0 or index.row() in self.protected_rows:
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet18Page(QWidget):
    def __init__(self, parent, list_total_title, list_total):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)  # 진한 파랑 (제목)
        self.target_light_blue = QColor(247, 250, 255) # 연한 파랑 (데이터)
        self.very_light_gray = QColor(252, 252, 252)

        self.list_total_title = list_total_title
        self.list_total = list_total
        self.idx = {}
        self.protected_rows = []
        
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        title = QLabel("4. 기준보수")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(len(self.list_total_title), 2)
        self.table.setHorizontalHeaderLabels(["구분", "금액"])
        self.table.verticalHeader().setFixedWidth(25)
        self.table.setColumnWidth(0, 450)
        self.table.setColumnWidth(1, 200)
        
        # 타이틀 바(Header) 및 구분선 스타일 설정 (회색 배경 적용)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section { 
                background-color: #F0F0F0; font-weight: bold; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #F0F0F0; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal; 
            }
        """)











        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # Delegate 설정 (보호 행 적용)
        self.delegate = RightAlignedDelegate(self.table, self.protected_rows)
        self.table.setItemDelegateForColumn(1, self.delegate)

        self.setup_content()
        self.table.itemChanged.connect(self.calculate_totals)
        
        layout.addWidget(self.table)




    def setup_content(self):
        self.table.blockSignals(True)
        
        # 1. "(나)"가 들어있는 행 번호 찾기
        self.r_na = -1
        for r, title in enumerate(self.list_total_title):
            if "(나)" in title:
                self.r_na = r
                break

        # 2. 화면 그리기
        for r in range(len(self.list_total_title)):
            title_text = self.list_total_title[r]

            # 딱 이 두 줄만 추가하세요
            if r == 1: title_text = f"{title_text} (라)"
            if r == 2: title_text = f"{title_text} (마)"

            
            # --- 1열: 제목 (무조건 편집 불가) ---
            item_a = QTableWidgetItem(title_text)
            item_a.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 제목 수정 금지 핵심!
            item_a.setBackground(QColor(250, 250, 250)) # 약간의 회색빛으로 구분
            
            # --- 2열: 금액 ---
            item_v = ThousandSeparatorItem(str(self.list_total[r]))
            item_v.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

            # [금액 열 중 파란색 자동계산 칸 설정]
            if r == self.r_na or r == (self.r_na + 1) or "(바)" in title_text:
                blue_color = QColor(200, 225, 255) # 파란색
                item_a.setBackground(blue_color)
                item_v.setBackground(blue_color)
                # 금액 칸도 자동계산용은 수정 금지
                item_v.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) 
                item_a.setFont(QFont("Malgun Gothic", 9, QFont.Bold))
            
            self.table.setItem(r, 0, item_a)
            self.table.setItem(r, 1, item_v)
            
        self.calculate_totals()
        self.table.blockSignals(False)

    def calculate_totals(self, item=None):
        # 이미 1열은 setFlags로 막았지만, 안전장치로 한 번 더 체크
        if item and item.column() == 0: return
        
        self.table.blockSignals(True)
        try:
            def gv(r):
                if r < 0 or r >= self.table.rowCount(): return 0.0
                it = self.table.item(r, 1)
                if not it or not it.text(): return 0.0
                try:
                    return float(str(it.text()).replace(',', ''))
                except:
                    return 0.0

            if self.r_na != -1:
                # 1. (나) 제외항목 합계 계산: 1번 행부터 (나) 바로 위까지 합산
                total_exclude = sum(gv(i) for i in range(1, self.r_na))
                self.table.item(self.r_na, 1).setText(str(int(total_exclude)))

                
                # 2. (다) 기준보수 계산: 0번 행(가) - (나) 행
                val_ga = gv(0)
                val_na = total_exclude
                val_da = val_ga - val_na
                
                if (self.r_na + 1) < self.table.rowCount():
                    self.table.item(self.r_na + 1, 1).setText(str(int(val_da)))

                r_ba = next((i for i, t in enumerate(self.list_total_title) if "(바)" in t), -1)
                if r_ba != -1:
                    val_la = gv(1) # 1번째 행 (라)
                    val_ma = gv(2) # 2번째 행 (마)
                    val_ba = val_da + val_la + val_ma
                    self.table.item(r_ba, 1).setText(str(int(val_ba)))

                r_de = self.table.rowCount() - 1  # 맨 마지막 줄
                if r_de != -1:
                    val_ba = gv(self.r_ba) if hasattr(self, 'r_ba') else gv(r_ba)
                    val_sa = gv(self.r_na + 3) # (사) 위치 (상황에 맞게 행번호 조절)
                    val_ah = gv(self.r_na + 6) # (아) 위치 (상황에 맞게 행번호 조절)
                    
                    if val_sa != 0:
                        val_de = val_ba * val_ah / val_sa
                        self.table.item(r_de, 1).setText(str(int(val_de)))



 
        except Exception as e:
            print(f"계산 중 오류 발생: {e}")
        finally:
            self.table.blockSignals(False)






    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사")
        paste_action = menu.addAction("붙여넣기")
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action: self.copy_selection()
        elif action == paste_action: self.paste_selection()

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        lines = []
        for r in range(selection[0].topRow(), selection[0].bottomRow() + 1):
            row_data = []
            for c in range(selection[0].leftColumn(), selection[0].rightColumn() + 1):
                it = self.table.item(r, c)
                txt = it.text() if it else ""
                row_data.append(txt.replace(',', ''))
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        clipboard = QApplication.clipboard().text()
        if not clipboard: return
        rows = clipboard.split('\n')
        curr = self.table.currentItem()
        if not curr: return
        
        self.table.blockSignals(True)
        for i, row_text in enumerate(rows):
            r = curr.row() + i
            if r >= self.table.rowCount() or not row_text.strip(): continue
            cols = row_text.split('\t')
            for j, col_text in enumerate(cols):
                c = curr.column() + j
                # 금액 열이면서 자동계산 행이 아닐 때만 붙여넣기 허용
                if c == 1 and r not in self.protected_rows:
                    item = self.table.item(r, c)
                    if item: item.setData(Qt.EditRole, col_text.strip().replace(',', ''))
        self.table.blockSignals(False)
        self.calculate_totals()
