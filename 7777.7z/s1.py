import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QCursor, QPen

# [1] 천단위 콤마 표시용 아이템 (s2 참조)
class ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val: return "0"
            try:
                clean_val = str(val).replace(',', '')
                return format(int(float(clean_val)), ",")
            except:
                return val
        return super().data(role)

# [2] 입력 시 실시간 콤마 델리게이트 (s2 참조)
class RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        # 읽기 전용 행은 에디터 생성 안함
        if not (index.flags() & Qt.ItemIsEditable):
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        editor.textChanged.connect(lambda text: self.format_text(editor, text))
        return editor

    def format_text(self, editor, text):
        clean = text.replace(',', '')
        if not clean or clean == "-": return
        try:
            formatted = format(int(float(clean)), ",")
            if text != formatted:
                pos = editor.cursorPosition()
                old_len = len(text)
                editor.blockSignals(True)
                editor.setText(formatted)
                editor.setCursorPosition(pos + (len(formatted) - old_len))
                editor.blockSignals(False)
        except: pass

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet1Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.very_light_gray = QColor(252, 252, 252)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        title = QLabel(" (2) 인건비 집계를 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(60, 7)
        self.table.setHorizontalHeaderLabels([
            "인건비 항목", "판관비", "영업외비용", "제조원가", "타계정대체", "이익잉여금", "합계"
        ])

        # 델리게이트 설정
        self.delegate = RightAlignedDelegate(self.table)
        for i in range(1, 7):
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        self.table.itemChanged.connect(self.calculate_s1)
        
        # 스타일 설정
        # self.table.setStyleSheet("QTableWidget { gridline-color: #d0d0d0; }")


        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section { 
                background-color: #f4f4f4; font-weight: bold; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal; 
            }
            QScrollBar:vertical { background: #f1f1f1; width: 14px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 14px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            
        """)


        
        self.table.setColumnWidth(0, 250)
        for i in range(1, 7): self.table.setColumnWidth(i, 110)
        
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        
        # [수정] 제수당/인상률제외 삭제 -> 통상임금소송/기타제외 추가
        items = [
            "기본급", "인센티브 상여금", "그 외 상여금", "법정수당", # '제수당' 삭제됨
            "해외근무수당", "그 외 제수당", "퇴직급여(명예퇴직금 포함)", 
            "임원 인건비", "비상임이사 인건비", 
            "통상임금소송으로증가",  # [추가]
            "기타제외인건비",       # [추가]
            "기타항목",            # '인상률제외' 위치 근처
            "급료,임금,제수당 소계ⓐ",         # 행 번호는 그대로 12
            "사내근로복지기금출연금", "국민연금사용자부담분", "건강보험사용자부담분",
            "고용보험사용자부담분", "산재보험료사용자부담분", "급식비", "교통보조비",
            "자가운전보조금", "학자보조금", "건강진단비", "선택적복지", "행사비",
            "포상품(비)", "기념품(비)", "격려품(비)", "장기근속관련 비용",
            "육아보조비 및 출산장려금", "자기계발비", "특별근로의 대가", "피복비",
            "경로효친비", "통신비", "축하금/조의금", "기타 항목",
            "복리후생비 소계 ⓑ",              # 37
            "일반 급여 (1)", "  인센티브 상여금", "  순액",     # 38, 39, 40
            "청년인턴 급여 (2)", "  인센티브 상여금", "  순액", # 41, 42, 43
            "무기계약직 급여 (3)", "  인센티브 상여금", "  순액", # 44, 45, 46
            "소계 ⓒ=(1)+(2)+(3)",             # 47
            "인건비 총계 : ⓓ=ⓐ+ⓑ+ⓒ",         # 48
            "인센티브 상여금 ⓔ=ⓔ-1+ⓔ-2",      # 49
            "  - 인센티브 전환금 (ⓔ-1)",       # 50
            "  - 인센티브 추가금 (ⓔ-2)",       # 51
            "인건비 해당금액 : ⓓ-ⓔ"          # 52
        ]

        self.table.setRowCount(len(items))
        self.readonly_rows = [12, 37, 38, 41, 44, 47, 48, 49, 52] # 행 번호 유지

        
        
        # 더 연한 하늘색 적용 (원하실 경우)
        soft_sky_blue = QColor(235, 245, 252)

        for r, text in enumerate(items):
            # A열 설정
            name_item = QTableWidgetItem(text)
            name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            
            # 소계/결과 행은 A열도 파란색 적용
            if r in self.readonly_rows:
                name_item.setBackground(soft_sky_blue)
                name_item.setFont(QFont("맑은 고딕", 9, QFont.Bold))
            else:
                # 회색 주석 처리하셨으므로 흰색으로 설정
                name_item.setBackground(Qt.white)
                
            self.table.setItem(r, 0, name_item)

            for c in range(1, 7):
                cell = ThousandSeparatorItem("0")
                cell.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                
                # 결과 행 또는 G열(합계) 보호
                if r in self.readonly_rows or c == 6:
                    cell.setBackground(soft_sky_blue)
                    cell.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    cell.setBackground(Qt.white)
                    cell.setFlags(Qt.ItemIsEditable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                
                self.table.setItem(r, c, cell)

        self.table.blockSignals(False)

    def calculate_s1(self, item):
        col = item.column()
        if col == 0 or col == 6: return 
        
        self.table.blockSignals(True)
        try:
            def gv(r, c_idx=None):
                target_col = c_idx if c_idx is not None else col
                it = self.table.item(r, target_col)
                if not it or not it.text(): return 0.0
                try: return float(it.text().replace(',', ''))
                except: return 0.0

            # --- [세로 소계 계산] ---
            self.set_val(12, col, sum(gv(r) for r in range(12)))
            self.set_val(37, col, sum(gv(r) for r in range(13, 37)))
            
            self.set_val(38, col, gv(39) + gv(40))
            self.set_val(41, col, gv(42) + gv(43))
            self.set_val(44, col, gv(45) + gv(46))
            
            self.set_val(47, col, gv(38) + gv(41) + gv(44)) 
            self.set_val(48, col, gv(12) + gv(37) + gv(47))
            self.set_val(49, col, gv(50) + gv(51))
            self.set_val(52, col, gv(48) - gv(49))

            # --- [가로 합계 계산 (G열)] ---
            # [수정] items 대신 table.rowCount()를 사용하여 정의 에러 해결
            for r in range(self.table.rowCount()):
                row_sum = sum(gv(r, c) for c in range(1, 6))
                self.set_val(r, 6, row_sum)

        except Exception as e:
            print(f"계산 에러: {e}")
        finally:
            self.table.blockSignals(False)



            

    def set_val(self, r, c, val):
        """계산된 값을 테이블 셀에 안전하게 입력 (버리지 않고 사용!)"""
        it = self.table.item(r, c)
        if it:
            # ThousandSeparatorItem이 알아서 콤마를 찍어주므로 숫자만 입력
            it.setText(str(int(val)))

    # --- [3] 엑셀 호환 복사/붙여넣기 및 키 이벤트 (s2 로직 계승) ---
    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C:
            self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V:
            self.paste_selection()
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter):
            curr_row = self.table.currentRow()
            if curr_row < self.table.rowCount() - 1:
                self.table.setCurrentCell(curr_row + 1, self.table.currentColumn())
        else:
            super().keyPressEvent(event)

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        lines = []
        for r in range(min_r, max_r + 1):
            row_data = []
            for c in range(min_c, max_c + 1):
                it = self.table.item(r, c)
                val = it.text().replace(',', '') if it else ""
                row_data.append(val)
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        r_s, c_s = curr.row(), curr.column()
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = r_s + i, c_s + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    item = self.table.item(r, c)
                    # 수정 가능한 셀(파란색이 아닌 셀)에만 붙여넣기
                    if item and (item.flags() & Qt.ItemIsEditable):
                        item.setText(val.strip().replace(',', ''))
        self.table.blockSignals(False)
        
        # 붙여넣기 후 첫 번째 수정된 열을 기준으로 전체 재계산 트리거
        dummy_item = self.table.item(r_s, c_s)
        if dummy_item:
            self.calculate_s1(dummy_item)

    def contextMenuEvent(self, event):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu::item:selected { background-color: #0078d7; color: white; }")
        cp = menu.addAction("복사 (Ctrl+C)")
        ps = menu.addAction("붙여넣기 (Ctrl+V)")
        
        action = menu.exec_(QCursor.pos())
        if action == cp: self.copy_selection()
        elif action == ps: self.paste_selection()

# 만약 단독 실행 테스트를 원하시면 아래 코드를 추가하세요.
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Sheet1Page()
    window.resize(1000, 800)
    window.show()
    sys.exit(app.exec_())





















        
