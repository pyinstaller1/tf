import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from s1 import Sheet1Page
from s2 import Sheet2Page
from s3 import Sheet3Page
from s4 import Sheet4Page
from s5 import Sheet5Page
from s6 import Sheet6Page
from s7 import Sheet7Page
from s8 import Sheet8Page
from s9 import Sheet9Page
from s10 import Sheet10Page
from s11 import Sheet11Page
from s12 import Sheet12Page
from s13 import Sheet13Page
from s14 import Sheet14Page
from s15 import Sheet15Page
from s16 import Sheet16Page
from s17 import Sheet17Page
from s18 import Sheet18Page

import os
import json




class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4개 공통지표 점수로 인건비 집계")        
        self.setGeometry(150, 150, 1100, 850)
        self.setStyleSheet("background-color: white;") 
        
        widget = QWidget()
        self.setCentralWidget(widget)
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(10, 5, 10, 5)

        # 1. 상단 버튼바 (간격 최소화: spacing=2)
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(2) # 버튼 사이 간격을 2픽셀로 고정
        


        # 엑셀 버튼
        btn_excel = QPushButton("Excel 내보내기")
        btn_excel.setStyleSheet("""
            QPushButton {
                background-color: #217346; color: white; border-radius: 2px;
                padding: 3px 12px; font-weight: bold;
            }
            QPushButton:hover { background-color: #1a5a37; }
        """)
        nav_layout.addWidget(btn_excel)
        layout.addLayout(nav_layout)

        # 2. 하단 시트 탭
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.South)

        self.tabs.setStyleSheet("""
    QTabWidget::pane { 
        border: 1px solid #f2f2f2; /* 본문 테두리와 만나는 선을 아주 연하게 */
    }
    QTabBar::tab {
        background: #f8f8f8; 
        border: 1px solid #dcdcdc;
        padding: 6px 20px; 
        margin-right: 2px;
        color: #666;
    }
    QTabBar::tab:selected { 
        background: white; 
        border-bottom: 2px solid white; /* 선택된 탭이 본문과 연결된 느낌 */
        font-weight: bold;
        color: #000;
    }
""")
        # 각 번호에 맞는 시트 클래스를 연결
        for i in range(1, 19):


            '''
            if i == 1:
                page = Sheet1Page()
            elif i == 2:
                page = Sheet2Page()
            elif i == 3:
                page = Sheet3Page()
            elif i == 4:
                page = Sheet4Page()
            elif i == 5:
                page = Sheet5Page()                
            elif i == 6:
                page = Sheet6Page()                
            elif i == 7:
                page = Sheet7Page()
            elif i == 8:
                page = Sheet8Page()
            elif i == 9:
                page = Sheet9Page()
            elif i == 10:
                page = Sheet10Page()                  
            elif i == 11:
                page = Sheet11Page()
            elif i == 12:
                page = Sheet12Page()                
            elif i == 13:
                page = Sheet13Page()           
            elif i == 14:
                page = Sheet14Page()                                            
            elif i == 15:
                page = Sheet15Page()
            elif i == 16:
                page = Sheet16Page()
            elif i == 17:
                page = Sheet17Page()
            elif i == 18:
                page = Sheet18Page()                  
            else:
                page = QWidget() # 나머지는 아직 빈 페이지
            '''


            if i == 1:
                self.s2 = Sheet2Page()
                page = self.s2
            elif i == 2:
                self.s2 = Sheet2Page()
                page = self.s2
            elif i == 3:
                self.s3 = Sheet3Page()
                page = self.s3

            elif i == 4:
                self.s4 = Sheet4Page()
                page = self.s4
            elif i == 5:
                self.s5 = Sheet5Page()
                page = self.s5
            elif i == 6:
                self.s6 = Sheet6Page()
                page = self.s6
            elif i == 7:
                self.s7 = Sheet7Page()
                page = self.s7
            elif i == 8:
                self.s8 = Sheet8Page()
                page = self.s8
            elif i == 9:
                self.s9 = Sheet9Page()
                page = self.s9
            elif i == 10:
                self.s10 = Sheet10Page()
                page = self.s10
            elif i == 11:
                self.s11 = Sheet11Page()
                page = self.s11
            elif i == 12:
                self.s12 = Sheet12Page()
                page = self.s12
            elif i == 13:
                self.s13 = Sheet13Page()
                page = self.s13
            elif i == 14:
                self.s14 = Sheet14Page()
                page = self.s14
            elif i == 15:
                self.s15 = Sheet15Page()
                page = self.s15

            elif i == 17:
                self.s17 = Sheet17Page()
                page = self.s17
            elif i == 18:
                self.s18 = Sheet18Page()
                page = self.s18




            else:
                page = QWidget() # 나머지는 아직 빈 페이지



                
                
            self.tabs.addTab(page, f"Sheet{i}")

        self.tabs.setCurrentIndex(1)
        layout.addWidget(self.tabs)



        btn_style = """
            QPushButton {
                border: 1px solid #dcdcdc;
                border-radius: 2px;
                padding: 3px 8px;
                background-color: #f9f9f9;
            }
            QPushButton:hover { background-color: #f0f0f0; }
        """
        
        self.btns = {}

        for btn_name in ["열기", "저장", "다른 이름으로 저장"]:
            btn = QPushButton(btn_name)
            btn.setStyleSheet(btn_style)
            btn.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
            nav_layout.addWidget(btn)
            self.btns[btn_name] = btn

        nav_layout.addStretch(1)


        self.btns["열기"].clicked.connect(self.load_json)
        self.btns["저장"].clicked.connect(lambda: self.save_json(False))
        self.btns["다른 이름으로 저장"].clicked.connect(lambda: self.save_json(True))


        self.s7.table.itemChanged.connect(lambda: self.s3.sync_from_s7(self.s7.get_average_personnel_to3()))
        self.s5.table.itemChanged.connect(lambda: self.s6.sync_from_s5(self.s5.get_data_for_s6()))
        self.s6.table.itemChanged.connect(lambda: self.s7.sync_s7_data(self.s4.get_data_to7(), self.s6.get_data_to7()))



        # self.s8.table.itemChanged.connect(lambda: self.s3.sync_unit_price_from_s8(self.s8.get_unit_price_to3()))
        # self.s8.table.itemChanged.connect(lambda: self.s8.sync_from_s4(self.s4.get_avg_data_to8()))


        self.s4.table.itemChanged.connect(lambda: self.s7.sync_s7_data(self.s4.get_data_to7(), self.s6.get_data_to7()))



        # 1. 인원이 바뀌면 단가를 계산해라 (S4 -> S8)
        self.s4.table.itemChanged.connect(lambda: self.s8.sync_from_s4(self.s4.get_avg_data_to8()))

        # 2. 단가가 계산되면 요약표에 넣어라 (S8 -> S3)
        self.s8.table.itemChanged.connect(lambda: self.s3.sync_unit_price_from_s8(self.s8.get_unit_price_to3()))









    def save_json(self, is_save_as=False):
        import json, os
        
        if is_save_as or not hasattr(self, 'current_path') or not self.current_path:
            default_name = os.path.join(os.getcwd(), "budget_data.json")
            path, _ = QFileDialog.getSaveFileName(self, "데이터 저장", default_name, "JSON Files (*.json);;Text Files (*.txt)")
            if not path: return
            self.current_path = path
        else:
            path = self.current_path

        total_data = {}
        for i in range(self.tabs.count()):
            sheet_name = self.tabs.tabText(i)
            page = self.tabs.widget(i)
            
            if hasattr(page, 'table'):
                table = page.table
                rows_data = []
                for r in range(table.rowCount()):
                    cols_data = []
                    for c in range(table.columnCount()):
                        it = table.item(r, c)
                        cols_data.append(it.text() if it else "")
                    rows_data.append(cols_data)
                total_data[sheet_name] = rows_data

        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(total_data, f, ensure_ascii=False, indent=4)
            
            self.setWindowTitle(f"예산 관리 프로그램 - {os.path.basename(path)}")
            QMessageBox.information(self, "완료", "데이터가 안전하게 저장되었습니다.")
        except Exception as e:
            QMessageBox.critical(self, "오류", f"저장 실패: {e}")




    def load_json(self):
        import json, os
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        from PyQt5.QtCore import Qt

        path, _ = QFileDialog.getOpenFileName(self, "데이터 불러오기", os.getcwd(), "JSON Files (*.json)")
        if not path: return

        try:
            with open(path, 'r', encoding='utf-8') as f:
                total_data = json.load(f)

            for i in range(self.tabs.count()):
                sheet_name = self.tabs.tabText(i)
                if sheet_name in total_data:
                    page = self.tabs.widget(i)
                    table = page.table
                    sheet_content = total_data[sheet_name]

                    # 1. 데이터 입력 (신호 차단)
                    table.blockSignals(True)
                    for r_idx, row_values in enumerate(sheet_content):
                        if r_idx >= table.rowCount(): break
                        for c_idx, val in enumerate(row_values):
                            if c_idx >= table.columnCount(): break
                            item = table.item(r_idx, c_idx)
                            if item:
                                # [중요] Editable 체크를 빼야 ReadOnly 칸도 데이터를 불러옵니다.
                                item.setData(Qt.EditRole, val)
                    table.blockSignals(False)


                    # wage.py 의 load_json 함수 try 블록 맨 마지막
                    if hasattr(self, 's3'):
                        self.s3.calculate_s3(None) # 인자값으로 None을 주면 전체 계산 실행





                    # 2. 시트별 계산 함수 탐색
                    calc_func = None
                    for attr in dir(page):
                        if "calculate" in attr.lower():
                            calc_func = getattr(page, attr)
                            break
                    
                    if calc_func:
                        if calc_func.__name__ == "calculate_s3":
                            # 3번 시트 데이터 행: 표1(0~7), 표2(11~18)
                            active_rows = list(range(0, 8)) + list(range(11, 19))
                            
                            # 1. 모든 데이터 행의 가로 평균(14열) 계산 (행 순회)
                            for r in active_rows:
                                # 1월(2열) 데이터를 트리거로 던져서 해당 행의 가로 연산을 먼저 끝냄
                                trigger = table.item(r, 2)
                                if trigger:
                                    try: calc_func(trigger)
                                    except: pass

                            # 2. 모든 열의 세로 합계(8행, 19행) 계산 (열 순회)
                            # 2열(1월)부터 14열(평균/합계열)까지 순차적으로 트리거
                            for c in range(2, 15):
                                # 표1의 마지막 데이터(7행)와 표2의 마지막 데이터(18행)를 찔러서
                                # 하단의 '계' 행이 현재 채워진 모든 가로 데이터를 합산하게 만듦
                                t1, t2 = table.item(7, c), table.item(18, c)
                                try:
                                    if t1: calc_func(t1)
                                    if t2: calc_func(t2)
                                except: pass








                        elif calc_func.__name__ == "calculate_s4":
                            # 1. 가로 평균 계산을 위해 모든 데이터 행 순회
                            # 전년도(0~7), 당년도(11~18) -> 18행(별도직군)까지 포함해야 함
                            active_rows = list(range(0, 8)) + list(range(11, 19))
                            for r in active_rows:
                                # 2열(1월) 데이터를 트리거로 사용
                                trigger_item = table.item(r, 2)
                                if trigger_item:
                                    try: calc_func(trigger_item)
                                    except: pass

                            # 2. 세로 합계(계) 계산을 위해 각 월(열)별로 트리거 발송
                            # 1월(2열)부터 12월(13열)까지
                            for c in range(2, 14):
                                # 각 열의 첫 번째 행 데이터로 세로 합계 계산 유도
                                trigger_prev = table.item(0, c)  # 전년도용
                                trigger_curr = table.item(11, c) # 당년도용
                                try:
                                    if trigger_prev: calc_func(trigger_prev)
                                    if trigger_curr: calc_func(trigger_curr)
                                except: pass

                        elif calc_func.__name__ == "calculate_s5":
                        # elif calc_func.__name__ == "calculate_diff" and "5" in sheet_name:
                                # 5번 시트 특성: (정원, 현원, 복직자) 입력 시 해당 열의 누적차와 세로 합계가 동시에 돌아야 함
                                # 표 1 (상반기: 0~8행), 표 2 (하반기: 11~19행)
                                
                                # 1. 모든 데이터 행에 대해 가로 누적차 계산 트리거
                                # 데이터가 있는 행들만 골라서 각 월의 첫번째 데이터(정원) 셀을 트리거로 사용
                                rows_to_calc = list(range(0, 8)) + list(range(11, 19))
                                # 각 월의 시작 열 (1월~6월, 7월~12월 각각 4열씩 건너뜀)
                                month_cols = [2, 6, 10, 14, 18, 22] 

                                for r in rows_to_calc:
                                    for c in month_cols:
                                        trigger = table.item(r, c)
                                        if trigger:
                                            try: calc_func(trigger)
                                            except: pass
                                
                                # 2. 세로 합계(계 행)를 위한 추가 트리거 (필요 시)
                                # 5번 시트 calc_func 구조상 위에서 이미 세로 합계가 포함되었다면 생략 가능


                        elif calc_func.__name__ in ["calculate_s7", "calculate_s8"]:
                        # elif "s7" in sheet_name or "s8" in sheet_name:
                            # 7번 시트 특성: 1~12월 데이터를 기반으로 14열(평균)과 8행/19행(합계) 계산
                            # 표 1: 0~7행 데이터, 8행 합계 / 표 2: 11~18행 데이터, 19행 합계
                            
                            # 1. 모든 데이터 행에 대해 '가로 평균' 계산 트리거
                            active_rows = list(range(0, 8)) + list(range(11, 19))
                            for r in active_rows:
                                # 2열(1월) 아이템을 던져서 해당 행의 가로 평균(14열)을 계산하게 함
                                trigger = table.item(r, 2)
                                if trigger:
                                    try: calc_func(trigger)
                                    except: pass

                            # 2. 모든 열(1월~평균열)에 대해 '세로 합계' 계산 트리거
                            # 2열(1월)부터 14열(평균)까지
                            for c in range(2, 15):
                                # 표 1 합계 트리거 (0행의 셀을 던짐)
                                t1 = table.item(0, c)
                                if t1:
                                    try: calc_func(t1)
                                    except: pass
                                
                                # 표 2 합계 트리거 (11행의 셀을 던짐)
                                t2 = table.item(11, c)
                                if t2:
                                    try: calc_func(t2)
                                    except: pass


                        elif calc_func.__name__ == "calculate_s13":
                            # 데이터 행: 표1(0~7), 표2(11~18)
                            active_rows = list(range(0, 8)) + list(range(11, 19))
                            
                            # 1. 모든 데이터 행의 가로 평균(14열)부터 먼저 계산 (행 순회)
                            for r in active_rows:
                                # 1월(2열) 데이터를 트리거로 던져서 해당 행의 평균을 먼저 뽑음
                                trigger = table.item(r, 2)
                                if trigger:
                                    try: calc_func(trigger)
                                    except: pass

                            # 2. 가로 평균들이 다 계산된 후, 각 열의 세로 합계(8행, 19행) 계산 (열 순회)
                            # 1월(2열)부터 평균열(14열)까지 전체 순회
                            for c in range(2, 15):
                                # 상반기(8행)와 하반기(19행) 합계를 위해 데이터 끝 행인 7행과 18행을 트리거
                                t1, t2 = table.item(7, c), table.item(18, c)
                                try:
                                    if t1: calc_func(t1)
                                    if t2: calc_func(t2)
                                except: pass




                        elif calc_func.__name__ == "calculate_s14":
                            # 1. 가로 연산 (증감C, 효과E) 및 기본 합계 트리거
                            for r in range(8):
                                # 2열(개편)을 찔러서 가로 연산을 먼저 끝냄
                                trigger_main = table.item(r, 2)
                                if trigger_main:
                                    try: calc_func(trigger_main)
                                    except: pass
                                    
                            # 2. 단가 열(4열) 합계 트리거
                            # 4열 단가 데이터를 하나 찔러서 위에서 수정한 합계 루프(1~5열 전체)가 돌게 함
                            trigger_price = table.item(0, 4)
                            if trigger_price:
                                try: calc_func(trigger_price)
                                except: pass








            self.current_path = path
            self.setWindowTitle(f"예산 관리 프로그램 - {os.path.basename(path)}")
            QMessageBox.information(self, "성공", "4번 시트 포함 18개 시트 연산 완료")

        except Exception as e:
            QMessageBox.critical(self, "오류", f"불러오기 실패: {e}")



if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setFont(QFont("맑은 고딕", 9))
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
