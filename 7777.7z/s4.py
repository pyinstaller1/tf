from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

# [1] 천단위 콤마 아이템 (평균인원은 소수점 대응)
class S4ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                # 콤마 제거 후 숫자로 변환
                num = float(str(val).replace(',', ''))
                
                # 정수인지 소수인지 판별하여 포맷팅
                if num == int(num):
                    return format(int(num), ",") # 정수는 콤마만
                else:
                    return format(num, ",.2f")   # 소수는 소수점 2자리 유지
            except:
                return val
        return super().data(role)

    

# [2] 실시간 우측 정렬 델리게이트
class S4RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet4Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        # S2/S3와 동일한 기존 파란색 설정
        self.base_sky_blue = QColor(220, 235, 245) 
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("hwp 16페이지: (3-2) 직급별 평균인원 계산을 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(21, 15)
        
        months = [f"{i}월" for i in range(1, 13)]
        headers = ["구분", "직급"] + months + ["평균인원"]
        self.table.setHorizontalHeaderLabels(headers)

        # [1] 우클릭 메뉴 정책 설정 (이게 있어야 메뉴가 뜹니다)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # 스타일시트 적용
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section:horizontal {
                background-color: #f4f4f4; padding: 2px; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; padding-left: 5px; padding-right: 5px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)

        self.table.verticalHeader().setVisible(True)
        self.table.verticalHeader().setFixedWidth(25)
        self.table.verticalHeader().setDefaultSectionSize(26)
        
        self.delegate = S4RightAlignedDelegate(self.table)
        for i in range(2, 15): 
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        # 열 너비 설정
        self.table.setColumnWidth(0, 50)
        self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 50)
        self.table.setColumnWidth(14, 70)

        self.table.itemChanged.connect(self.calculate_s4)
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        # 0~7번은 직급명, 8번은 "계"
        ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "...", "별도직군", "계"]
        months_headers = [f"{i}월" for i in range(1, 13)]
        full_headers = ["구분", "직급"] + months_headers + ["평균인원"]
        
        comment_text = (
            " hwp 16페이지: (3-2) 직급별 평균인원 계산을 위한 Template\n\n"
            " * 각 직급별 매월 인원은 해당 월말 현재의 인원을 집계함...\n"
            " * 각 직급별 평균인원은 1월부터 12월까지의 인원 총계를 12로 나누어서 구하되 소수점 이하 둘째 자리에서 반올림함."
        )

        # 총 21행 구성: 0~8(전년도), 9(공백), 10(헤더), 11~19(당년도), 20(주석)
        for r in range(21):
            for c in range(15):
                # 1. 전년도/당년도 사이 공백 (9행)
                if r == 9:
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags)
                    item.setBackground(Qt.white)
                
                # 2. 당년도 표 헤더 (10행) - 기존 시트와 동일한 스타일 (사용자 지침 반영)
                elif r == 10:
                    item = QTableWidgetItem(full_headers[c])
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setBackground(QColor(240, 240, 240)) # 타이틀 바 스타일 통일
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                
                # 3. 주석 (20행)
                elif r == 20:
                    item = QTableWidgetItem(comment_text if c == 0 else "")
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                
                # 4. 데이터 영역 (0~8행: 전년도, 11~19행: 당년도)
                else:
                    item = S4ThousandSeparatorItem("0")
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)
                    
                    # [사용자 지침] 숫자 컬럼 구분선 및 배경색 스타일 (1열, 14열)
                    if c == 1 or c == 14:
                        item.setBackground(self.base_sky_blue)
                    
                    # [핵심] "계" 줄 강조 (8행: 전년도 계, 19행: 당년도 계)
                    if r == 8 or r == 19:
                        item.setBackground(self.base_sky_blue)
                        font = item.font()
                        font.setBold(True)
                        item.setFont(font)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

                    # 구분 열 (0열)
                    if c == 0:
                        item.setBackground(QColor(245, 245, 245))
                        if 0 <= r <= 8: item.setText("전년도")
                        elif 11 <= r <= 19: item.setText("당년도")
                    
                    # 직급 명칭 (1열)
                    if c == 1:
                        if 0 <= r <= 8: item.setText(ranks[r])
                        elif 11 <= r <= 19: item.setText(ranks[r-11])
                
                self.table.setItem(r, c, item)

        # [병합 및 레이아웃 재조정]
        self.table.setSpan(0, 0, 9, 1)    # 전년도 구분 (0~8행)
        self.table.setSpan(11, 0, 9, 1)   # 당년도 구분 (11~19행 - 계 포함 총 9줄)
        self.table.setSpan(20, 0, 1, 15)  # 주석

        self.table.setRowHeight(9, 15)    # 구분선 높이
        self.table.setRowHeight(20, 150)  # 주석 높이
        
        self.table.blockSignals(False)
        
        
        

        
    def calculate_s4(self, item):
        row, col = item.row(), item.column()
        
        # 1. 계산 제외 대상 필터링 (기존과 동일)
        # col < 2 (구분, 직급 열), col == 14 (평균인원 열), 특수 행들
        if col < 2 or col == 14 or row in [8, 9, 10, 19, 20]: 
            return 
        
        self.table.blockSignals(True)
        try:
            # 2. 범위 설정 (전년도 0~7행 데이터/8행 계, 당년도 11~18행 데이터/19행 계)
            if 0 <= row <= 7:
                start_r = 0
                last_data_r = 7 # 별도직군(마지막 데이터 행)
                sum_r = 8       # 계 행
            elif 11 <= row <= 18:
                start_r = 11
                last_data_r = 18
                sum_r = 19
            else:
                return

            # 3. [가로 계산] 해당 직급의 1~12월 평균인원 구하기
            # 기존 루프를 유지하면서 cell_value를 사용해 가독성을 높였습니다.
            row_sum = 0.0
            for c in range(2, 14):
                row_sum += self.cell_value(row, c)
            
            avg_val = round(row_sum / 12, 2)
            
            # 평균인원 셀(14열)에 값 입력 (setData를 써야 S8에서 숫자로 인식함)
            target_avg_item = self.table.item(row, 14)
            if target_avg_item:
                target_avg_item.setData(Qt.EditRole, avg_val)

            # 4. [세로 계산] '계' 행 업데이트 (누적 데이터 원칙: 마지막 행 복사)
            # 현재 수정된 달(col)의 합계를 구하는 대신, 마지막 직급(별도직군)의 인원을 복사합니다.
            last_month_val = self.cell_value(last_data_r, col)
            sum_item = self.table.item(sum_r, col)
            if sum_item:
                sum_item.setData(Qt.EditRole, int(last_month_val))

            # 5. [최종 합계] '계' 행의 '평균인원' 셀 업데이트
            # 이 역시 마지막 직급(별도직군)의 평균인원 값을 그대로 가져옵니다.
            last_row_avg = self.cell_value(last_data_r, 14)
            total_sum_item = self.table.item(sum_r, 14)
            if total_sum_item:
                total_sum_item.setData(Qt.EditRole, round(last_row_avg, 2))

        except Exception as e:
            print(f"S4 계산 상세 오류: {e}")
        finally:
            self.table.blockSignals(False)



    def cell_value(self, row, col):
        """테이블 아이템의 텍스트를 float으로 안전하게 변환 (모든 시트 공통)"""
        item = self.table.item(row, col)
        if item and item.text().strip():
            try:
                # 콤마 제거 후 숫자로 변환
                return float(item.text().replace(',', ''))
            except ValueError:
                return 0.0
        return 0.0

    def get_data_to7(self):
        """S4의 '당년도' 영역(11~18행) 데이터를 추출하여 S7로 전달"""
        data = [[0.0 for _ in range(12)] for _ in range(8)]
        
        # S4 구조: 당년도 데이터는 11행부터 시작, 1월은 2열부터 시작
        start_row = 11
        start_col = 2
        
        for r in range(8):
            for m in range(12):
                # 공통 cell_value 함수를 사용하여 안전하게 값 추출
                data[r][m] = self.cell_value(start_row + r, start_col + m)
        return data


    def get_avg_data_to8(self):
        """S8의 평균단가 계산을 위해 S4의 14열(평균인원) 데이터 추출 + 로그 출력"""
        prev_year = [self.cell_value(r, 14) for r in range(8)]      # 전년도 0~7행
        curr_year = [self.cell_value(11 + r, 14) for r in range(8)] # 당년도 11~18행
        
        return [prev_year, curr_year]
    

            
    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사 (Ctrl+C)")
        paste_action = menu.addAction("붙여넣기 (Ctrl+V)")
        
        # 마우스 위치에 메뉴 띄우기
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        
        if action == copy_action:
            self.copy_selection()
        elif action == paste_action:
            self.paste_selection()

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r = min(r.topRow() for r in selection)
        max_r = max(r.bottomRow() for r in selection)
        min_c = min(r.leftColumn() for r in selection)
        max_c = max(r.rightColumn() for r in selection)
        
        lines = []
        # 제목줄 포함 복사 (선택 범위에 상단 제목이 포함될 경우)
        if min_r == 0:
            headers = [self.table.horizontalHeaderItem(c).text().replace('\n', ' ') for c in range(min_c, max_c + 1)]
            lines.append("\t".join(headers))

        for r in range(min_r, max_r + 1):
            # [수정] 10행(index 9)과 20행(index 19)도 빈 줄로 포함하여 복사
            if r in [9, 19]:
                # 해당 범위만큼 빈 탭(\t)을 추가하여 엑셀에서 빈 줄로 인식하게 함
                empty_line = [""] * (max_c - min_c + 1)
                lines.append("\t".join(empty_line))
                continue

            row_data = []
            # 엑셀 수식용 상대 좌표 (전년도는 2행부터, 당년도는 13행부터 시작 가정)
            ex_row = (r + 2) if r <= 8 else (r + 1) # 행 번호에 맞춰 조정

            for c in range(min_c, max_c + 1):
                col_L = chr(ord('A') + c)
                # 수식 복사 로직 (평균 및 계)
                if c == 14 and r not in [8, 10, 18, 20]: # 일반 데이터 행 평균
                    val = f"=AVERAGE(C{ex_row}:N{ex_row})"
                elif (r == 8 or r == 18) and c >= 2: # 계 행 합계
                    val = f"=SUM({col_L}{ex_row-8}:{col_L}{ex_row-1})"
                else:
                    it = self.table.item(r, c)
                    # 콤마 제거하고 순수 텍스트만 추출
                    val = it.text().replace(',', '').strip() if it else ""
                row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))

        

    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    item = self.table.item(r, c)
                    # 수정 가능 여부 확인 (주석칸, 계, 평균열 등 제외)
                    if item and (item.flags() & Qt.ItemIsEditable):
                        item.setText(val.strip())
        self.table.blockSignals(False)
        self.calculate_s4(curr)

    # 키보드 단축키 지원
    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self.copy_selection()
        elif event.matches(QKeySequence.Paste):
            self.paste_selection()
        else:
            super().keyPressEvent(event)
