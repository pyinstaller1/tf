from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QPen
import re

# Sheet 3와 동일한 천단위 콤마 및 우측 정렬 로직 사용
class S12ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val or val == "n/a": return val
            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                return format(int(num), ",") if num == int(num) else format(num, ",.2f")
            except: return val
        return super().data(role)

class Sheet12Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # HWP 제목 명시
        title = QLabel("hwp 24페이지: 라. 별도직군의 승진시기 차이에 따른 인건비 효과")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        # 11행 8열 (직급, A, B, C, D, E, F, 인건비효과)
        self.table = QTableWidget(11, 8)
        
        # [제목줄 설정] 요청하신 순서대로 배치
        headers = [
            "직급", 
            "전년도\n미승진자\n평균인원(A)", "당년도\n미승진자\n평균인원(B)", "증감\n(C)=(B)-(A)",
            "전년도\n승진전\n평균단가(D)", "당년도\n승진전\n평균단가(E)", "증감\n(F)=(E)-(D)",
            "인건비 효과\n(C) × (F)"
        ]
        self.table.setHorizontalHeaderLabels(headers)
        self.table.horizontalHeader().setFixedHeight(70)
        
        # [스타일 원복] Sheet 9/Sheet 3 스타일 적용
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.verticalHeader().setFixedWidth(25)

        self.setup_content()
        
        # 컬럼 너비 최적화
        self.table.setColumnWidth(0, 70)
        for i in range(1, 7): self.table.setColumnWidth(i, 95)
        self.table.setColumnWidth(7, 130)

        self.table.itemChanged.connect(self.calculate_s12)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "... ...", "별도직군"]
        
        for r in range(11):
            for c in range(8):
                item = S12ThousandSeparatorItem("0") if c > 0 else QTableWidgetItem("")
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                
                if r < 8: # 데이터 행
                    if c == 0:
                        item.setText(ranks[r])
                        item.setTextAlignment(Qt.AlignCenter)
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    elif c in [3, 6, 7]: # 자동계산 열 (C, F, 인건비효과)
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                
                elif r == 8: # 합계 행
                    item.setBackground(self.base_sky_blue)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    if c == 0:
                        item.setText("계")
                        item.setTextAlignment(Qt.AlignCenter)
                
                elif r >= 9: # 하단 주석 영역
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    item.setBackground(Qt.white)
                
                self.table.setItem(r, c, item)

        self.table.setSpan(9, 0, 1, 8) # 빈 줄
        self.table.setRowHeight(9, 25)
        self.table.setSpan(10, 0, 1, 8) # 주석 줄
        note_text = (
            "hwp 24페이지: 라. 별도직군의 승진시기 차이에 따른 인건비 효과\n\n"
            "* 당년도 및 전년도 각 직급별 정원은 ‘가. 초임직급 정원 변동’의 평균정원을 기재함.\n\n"
            "* 전년도의 평균단가는 (3-4)직급별 평균단가 계산을 위한 Template에서 계산된 전년도 평균단가임."
        )
        n_it = QTableWidgetItem(note_text)
        n_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        n_it.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        # 주석 가독성을 위해 폰트와 행 높이 조절
        n_it.setFont(QFont("맑은 고딕", 9))
        self.table.setItem(10, 0, n_it)
        self.table.setRowHeight(10, 100) 
        
        self.table.blockSignals(False)



                                                   
        self.table.blockSignals(False)

    def calculate_s12(self, item):
        r, c = item.row(), item.column()
        if r >= 8 or c not in [1, 2, 4, 5]: return
        
        self.table.blockSignals(True)
        try:
            def gv(row, col):
                it = self.table.item(row, col)
                return float(it.text().replace(',', '')) if it and it.text() else 0.0

            # (C) = (B) - (A)
            vC = gv(r, 2) - gv(r, 1)
            self.table.item(r, 3).setData(Qt.EditRole, str(int(vC)))

            # (F) = (E) - (D)
            vF = gv(r, 5) - gv(r, 4)
            self.table.item(r, 6).setData(Qt.EditRole, str(int(vF)))

            # 인건비 효과 = (C) * (F)
            vEff = vC * vF
            self.table.item(r, 7).setData(Qt.EditRole, str(int(vEff)))

            # 합계 갱신
            for col_sum in [1, 2, 3, 7]:
                total = sum(gv(i, col_sum) for i in range(8))
                self.table.item(8, col_sum).setData(Qt.EditRole, str(int(total)))
        finally:
            self.table.blockSignals(False)

    def get_excel_col(self, n):
        res = ""; n += 1
        while n > 0: n, rem = divmod(n - 1, 26); res = chr(65 + rem) + res
        return res

    def copy_selection(self):
        ranges = self.table.selectedRanges()
        if not ranges: return
        r0, r1 = min(r.topRow() for r in ranges), max(r.bottomRow() for r in ranges)
        c0, c1 = min(r.leftColumn() for r in ranges), max(r.rightColumn() for r in ranges)
        lines = []

        if r0 == 0:
            h_row = [self.table.horizontalHeaderItem(c).text().replace('\n', ' ') for c in range(c0, c1 + 1)]
            lines.append("\t".join(h_row))

        for r in range(r0, r1 + 1):
            if r == 9: continue
            row_data = []
            xl_r = r + 2 if r0 == 0 else r + 1
            for c in range(c0, c1 + 1):
                it = self.table.item(r, c)
                val = it.text().replace(',', '').replace('\n', ' ') if it else ""
                
                # [수식 복사 로직]
                if r < 8:
                    if c == 3: val = f"=C{xl_r}-B{xl_r}"
                    elif c == 6: val = f"=F{xl_r}-E{xl_r}"
                    elif c == 7: val = f"=D{xl_r}*G{xl_r}" # 엑셀상 D*G가 (C)*(F) 위치
                elif r == 8 and c in [1, 2, 3, 7]:
                    col = self.get_excel_col(c)
                    val = f"=SUM({col}{xl_r-8}:{col}{xl_r-1})"
                
                row_data.append(val)
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))

    
    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사 (Ctrl+C)")
        paste_action = menu.addAction("붙여넣기 (Ctrl+V)")
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action: self.copy_selection()
        elif action == paste_action: self.paste_selection()
