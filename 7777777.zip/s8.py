from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

rank_count = 8

# [1] S8 전용 우측 정렬 델리게이트
class S8RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, parent):
        super().__init__(parent)
        # 생성 시 부모(TableWidget)에 이벤트 필터 설치 (평소 상태 감시)
        if parent:
            parent.installEventFilter(self)
            
    def createEditor(self, parent, option, index):
        if not (index.model().flags(index) & Qt.ItemIsEditable):
            return None # 권한 없으면 입력창 아예 안 만듦 (편집 원천 봉쇄)
        
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        # 입력 중(에디터 활성화)일 때 키 감시용 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # 데이터를 모델에 저장하기 위해 인덱스 변경
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나, 커서가 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나, 커서가 시작일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 인덱스만 변경 (자동 편집 X)"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)
        

# [2] S8 전용 천단위 콤마 아이템
class S8ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                if num == int(num): return format(int(num), ",")
                else: return format(num, ",.2f").rstrip('0').rstrip('.')
            except: return val
        return super().data(role)

class Sheet8Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        
        global rank_count
        rank_count = len(self.main_window.list_title_08)

        self.from_s4 = None
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("(3-4) 직급별 평균단가 계산")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)        

        # 열 구성: 구분(0), 직급(1), 1~12월(2-13), 인건비총계(14), 직급별평균단가(15)
        self.table = QTableWidget((rank_count*2) + 2, 16)
        self.table.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # [수정] 행 높이를 25px로 압축 (가장 슬림한 표준)
        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.verticalHeader().setFixedWidth(25)

        # 스타일 시트 (스크롤바 강조 및 여백 최소화)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertial { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar::handle:vertical:hover { background: #555555; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            QScrollBar::handle:horizontal:hover { background: #555555; }
            QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
        """)

        # [수정] 제목줄 1줄로 고정 (줄바꿈 제거)
        headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["인건비 총계", "직급별 평균단가"]
        self.table.setHorizontalHeaderLabels(headers)

        self.setup_content()

        self.delegate = S8RightAlignedDelegate(self.table)
        for i in range(2, 16):
            self.table.setItemDelegateForColumn(i, self.delegate)

        
        
        # 너비 설정
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 100)
        self.table.setColumnWidth(14, 120); self.table.setColumnWidth(15, 120)

        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Fixed)
        self.table.blockSignals(False)

        self.table.itemChanged.connect(self.calculate_s8)
        layout.addWidget(self.table)





    def setup_content(self):
        """테이블 초기 구조 생성"""
        self.table.blockSignals(True)
        
        # 전체 행수 자동 계산
        # 전년도(rank_count) + 구분선(1) + 제목줄(1) + 당년도(rank_count) + 구분선(1) + 주석(1) = (rank_count*2)+4
        self.table.setRowCount((rank_count * 2) + 4)
        self.table.setColumnCount(16)

        ranks = list(self.main_window.list_title_08)
        if len(ranks) < rank_count: ranks.append("계")
        full_headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["인건비 총계", "직급별 평균단가"]
        
        bold_font = QFont(); bold_font.setBold(True)

        # --- 1. 전년도 영역 (0 ~ rank_count-1) ---
        year_item1 = QTableWidgetItem("전\n년\n도")
        year_item1.setTextAlignment(Qt.AlignCenter); year_item1.setBackground(QColor(245, 245, 245))
        self.table.setItem(0, 0, year_item1)
        self.table.setSpan(0, 0, rank_count, 1)

        for r in range(rank_count):
            is_last = (r == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[r])
            it_rank.setTextAlignment(Qt.AlignCenter); it_rank.setBackground(self.base_sky_blue)
            if is_last: it_rank.setFont(bold_font)
            self.table.setItem(r, 1, it_rank)



            for c in range(2):
                item = self.table.item(r, c)
                if item:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable) # 입력 막기





            
            for c in range(2, 16):
                it = S8ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

                if is_last or c == 14 or c == 15:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집 불가
                    if is_last or c == 14:
                        it.setBackground(self.base_sky_blue)
                    elif c == 15:
                        it.setBackground(QColor(255, 255, 225)) # 노란색
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                    
                self.table.setItem(r, c, it)

        # --- 2. 중간 구분선 및 당년도 제목줄 ---
        # rank_count행: 구분선 / rank_count+1행: 제목줄
        self.table.setRowHeight(rank_count, 15)
        # self.table.setRowHeight(rank_count + 1, 45)
        for c in range(16):
            # 구분선
            self.table.setItem(rank_count, c, QTableWidgetItem(""))
            # 제목줄
            t_it = QTableWidgetItem(full_headers[c])
            t_it.setBackground(QColor(240, 240, 240)); t_it.setFont(bold_font); t_it.setTextAlignment(Qt.AlignCenter)
            t_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(rank_count + 1, c, t_it)

        # --- 3. 당년도 영역 (rank_count+2 ~ ) ---
        data2_start = rank_count + 2
        year_item2 = QTableWidgetItem("당\n년\n도")
        year_item2.setTextAlignment(Qt.AlignCenter); year_item2.setBackground(QColor(245, 245, 245))
        self.table.setItem(data2_start, 0, year_item2)
        self.table.setSpan(data2_start, 0, rank_count, 1)

        for i in range(rank_count):
            curr_r = data2_start + i
            is_last = (i == rank_count - 1)
            it_rank = QTableWidgetItem(ranks[i])
            it_rank.setTextAlignment(Qt.AlignCenter); it_rank.setBackground(self.base_sky_blue)
            it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            if is_last: it_rank.setFont(bold_font)
            self.table.setItem(curr_r, 1, it_rank)


            for c in range(2):
                item = self.table.item(curr_r, c)
                if item:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable) # 입력 막기


            
            for c in range(2, 16):
                it = S8ThousandSeparatorItem("0")
                it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

                if is_last or c == 14 or c == 15:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 편집 불가
                    if is_last or c == 14:
                        it.setBackground(self.base_sky_blue)
                    elif c == 15:
                        it.setBackground(QColor(255, 255, 225)) # 노란색
                else:
                    it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

                self.table.setItem(curr_r, c, it)

        # --- 4. 하단 주석 ---
        comment_start = (rank_count * 2) + 2
        self.table.setRowHeight(comment_start, 15)
        self.table.setRowHeight(comment_start + 1, 80)
        self.table.setSpan(comment_start + 1, 0, 1, 16)
        note = " * 전년도와 당년도 평균단가(인건비 총계 ÷ 12)를 계산하여... (이하 생략)"
        c_item = QTableWidgetItem(note)
        c_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(comment_start + 1, 0, c_item)
        
        self.table.blockSignals(False)

    def calculate_s8(self, item):
        """실시간 자동 계산 로직"""
        if item is None: return
        r, c = item.row(), item.column()
        if r in [rank_count, rank_count + 1]: return # 보호 행 제외

        self.table.blockSignals(True)
        try:
            if r < rank_count:
                start_r, last_r = 0, rank_count - 1
                manpower_list = self.from_s4[0] if self.from_s4 else None
            else:
                start_r = rank_count + 2
                last_r = start_r + rank_count - 1
                manpower_list = self.from_s4[1] if self.from_s4 else None

            # 1. 가로 총계 및 개별 평균단가
            if r != last_r:
                row_sum = sum(self.cell_value(r, col) for col in range(2, 14))
                self.table.item(r, 14).setData(Qt.EditRole, int(row_sum))
                if manpower_list and (r - start_r) < len(manpower_list):
                    man = manpower_list[r - start_r]
                    price = row_sum / man if man > 0 else 0.0
                    self.table.item(r, 15).setData(Qt.EditRole, int(round(price)))

            # 2. 세로 합계 (데이터 영역 '계' 갱신)
            if 2 <= c <= 14:
                col_total = sum(self.cell_value(start_r + i, c) for i in range(rank_count - 1))
                self.table.item(last_r, c).setData(Qt.EditRole, int(col_total))

            # 3. '계' 행의 최종 평균단가 (정석 계산: 총액 / 총인원)
            total_cost = self.cell_value(last_r, 14)
            if manpower_list:
                total_man = manpower_list[-1]
                avg_total = total_cost / total_man if total_man > 0 else 0.0
                self.table.item(last_r, 15).setData(Qt.EditRole, int(round(avg_total)))
        finally:
            self.table.blockSignals(False)   

    def cell_value(self, row, col):
        """테이블 아이템의 텍스트를 float으로 안전하게 변환"""
        item = self.table.item(row, col)
        if item and item.text().strip():
            try:
                # 콤마 제거 후 숫자로 변환
                return float(item.text().replace(',', ''))
            except ValueError:
                return 0.0
        return 0.0

            
    def sync_from_s4(self, s4_data):
        """MainWindow를 통해 S4의 평균인원 데이터를 주입받고 S8 전체를 재계산"""
        if not s4_data: return
        
        self.from_s4 = s4_data  # [전년도리스트, 당년도리스트]
        self.table.blockSignals(True)
        
        try:
            # 1. 계산할 행 범위 설정 (전년도: 0~rank_count-1, 당년도: rank_count+2 이후)
            data2_start = rank_count + 2
            target_rows = list(range(rank_count)) + list(range(data2_start, data2_start + rank_count))
            
            for r in target_rows:
                manpower = 0.0
                if r < rank_count: # 전년도 영역
                    if r < len(self.from_s4[0]): manpower = self.from_s4[0][r]
                else: # 당년도 영역
                    idx = r - data2_start
                    if idx < len(self.from_s4[1]): manpower = self.from_s4[1][idx]
                
                cost = self.cell_value(r, 14) # 인건비 총계
                unit_price = cost / manpower if manpower > 0 else 0.0
                
                it = self.table.item(r, 15)
                if it:
                    # 데이터 일관성을 위해 setData 사용
                    it.setData(Qt.EditRole, int(round(unit_price)))

            # 2. 단가가 바뀌었으므로 '계' 행들의 합계를 갱신하기 위해 로직 트리거
            self.table.blockSignals(False)
            
            # 전년도 '계' 행 트리거 (rank_count - 1)
            it_prev = self.table.item(rank_count - 1, 2)
            if it_prev: self.calculate_s8(it_prev)
            
            # 당년도 '계' 행 트리거 (data2_start + rank_count - 1)
            it_curr = self.table.item(data2_start + rank_count - 1, 2)
            if it_curr: self.calculate_s8(it_curr)
            
        except Exception as e:
            print(f"S8 Sync Error: {e}")
        finally:
            self.table.blockSignals(False)

    def get_unit_price_to3(self):
        """S3 연동을 위해 전년도 '순수 직급별' 평균단가 추출 (마지막 '계' 제외)"""
        data = []
        # rank_count가 9라면 0~7행(8개)만 추출하여 '계'는 자동으로 빠짐
        for i in range(rank_count - 1): 
            data.append(self.cell_value(i, 15))
        return data

    def get_unit_price_to10(self):
        """S10 연동을 위해 전년도 '순수 직급별' 평균단가 추출 (마지막 '계' 제외)"""
        # 위 함수와 동일한 로직 적용
        return [self.cell_value(i, 15) for i in range(rank_count - 1)]



    def copy_selection(self):
        """엑셀 복사용 수식 포함 데이터 추출"""
        selection = self.table.selectedRanges()
        if not selection: return
        
        data2_start = rank_count + 2
        this_year_sum_row = rank_count - 1
        last_year_sum_row = data2_start + rank_count - 1

        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []

        for r in range(min_r, max_r + 1):
            if r in [rank_count, rank_count + 1]: # 구분선, 제목줄은 텍스트로
                row_data = [ (self.table.item(r, c).text() if self.table.item(r, c) else "") for c in range(min_c, max_c+1) ]
                lines.append("\t".join(row_data))
                continue

            row_data = []
            is_total_row = (r == this_year_sum_row or r == last_year_sum_row)
            for c in range(min_c, max_c + 1):
                if c == 14: # 가로 총계 수식
                    row_data.append("=SUM(INDEX($1:$1048576,ROW(),COLUMN()-12):INDEX($1:$1048576,ROW(),COLUMN()-1))")
                elif is_total_row and 2 <= c <= 13: # 세로 합계 수식 (rank_count-1 만큼 위를 합산)
                    offset = rank_count - 1
                    row_data.append(f"=SUM(INDEX($1:$1048576,ROW()-{offset},COLUMN()):INDEX($1:$1048576,ROW()-1,COLUMN()))")
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    row_data.append(val)
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))


        
    def paste_selection(self):
        txt = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not txt or not curr: return
        
        self.table.blockSignals(True)
        affected_cells = [] 

        data2_start = rank_count + 2
        # 보호해야 할 행들 (구분선, 제목줄, 하단 구분선)
        protected_rows = [rank_count, rank_count + 1, data2_start + rank_count]

        try:
            for i, line in enumerate(txt.splitlines()):
                if any(h in line for h in ["구분", "직급", "월"]): continue
                for j, val in enumerate(line.split('\t')):
                    r, c = curr.row() + i, curr.column() + j
                    if r < self.table.rowCount() and c < self.table.columnCount():
                        # 입력 금지 구역: 직급열(0,1), 보호행, 수식/결과열(14,15)
                        if c < 2 or r in protected_rows or c >= 14: continue
                        
                        it = self.table.item(r, c)
                        if it and (it.flags() & Qt.ItemIsEditable):
                            try:
                                clean_val = val.strip().replace(',', '')
                                num_val = int(float(clean_val or 0))
                                it.setData(Qt.EditRole, num_val)
                                affected_cells.append((r, c))
                            except: pass
        finally:
            self.table.blockSignals(False)
            
            # 수정된 위치를 기반으로 계산 트리거 (중복 방지를 위해 열/영역 단위로 실행)
            processed_areas = set()
            for r, c in affected_cells:
                # 전년도(r < rank_count)와 당년도 구분하여 대표로 한 번씩만 계산
                area = "prev" if r < rank_count else "curr"
                if (area, c) not in processed_areas:
                    self.calculate_s8(self.table.item(r, c))
                    processed_areas.add((area, c))
            
            # S10 등 외부 연동을 위해 '계' 행 알림 발생
            for r in [rank_count - 1, data2_start + rank_count - 1]:
                target_item = self.table.item(r, 15)
                if target_item: self.table.itemChanged.emit(target_item)
                    
                    

    def show_context_menu(self, pos):
        menu = QMenu()
        cp = menu.addAction("복사 (Ctrl+C)"); ps = menu.addAction("붙여넣기 (Ctrl+V)")
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if act == cp: self.copy_selection()
        elif act == ps: self.paste_selection()

        

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
