from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QKeySequence, QFont
import re

class s10ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                num = float(str(val).replace(',', ''))
                return format(int(num), ",") if num == int(num) else format(num, ",.2f")
            except: return val
        return super().data(role)

class Sheet10Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("hwp 22페이지: 나. 별도직군 승진 가능 인원 내 미승진자 인원 계산")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        # 구분(1) + 직급(1) + (4항목 * 6개월) = 26열
        self.table = QTableWidget(18, 26)
        self.setup_style()
        self.setup_headers()
        self.setup_content()

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        self.table.itemChanged.connect(self.calculate_logic)
        layout.addWidget(self.table)

        # 제목바 및 행번호 열 스타일 (저장된 정보 준수)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertical { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
        """)

    def setup_style(self):
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.verticalHeader().setFixedWidth(25)

    def setup_headers(self):
        h_labels = ["구분", "직급"]
        for m in range(1, 7):
            h_labels.append(f"{m}월\n승진TO")
            h_labels.append(f"{m}월\n승진")
            h_labels.append("전년말\n미승진") # 월 표시 없음
            h_labels.append(f"{m}월\n미승진자")
        self.table.setHorizontalHeaderLabels(h_labels)
        self.table.horizontalHeader().setFixedHeight(45)
        self.table.setColumnWidth(0, 30); self.table.setColumnWidth(1, 60)
        for c in range(2, 26): self.table.setColumnWidth(c, 65)



    def create_row_items(self, row, rank):
        bold_f = QFont(); bold_f.setBold(True)
        it_rank = QTableWidgetItem(rank); it_rank.setTextAlignment(Qt.AlignCenter)
        it_rank.setBackground(self.base_sky_blue); it_rank.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(row, 1, it_rank)
        for c in range(2, 26):
            it = s10ThousandSeparatorItem("0"); it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if (c - 2) % 4 == 3 or rank == "계":
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable); it.setBackground(self.base_sky_blue); it.setFont(bold_f)
            self.table.setItem(row, c, it)



    def setup_content(self):
        self.table.blockSignals(True)
        # 1. 6직급 포함 리스트
        self.ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "... ...", "별도직군", "계"]
        
        # 전체 행 수 조정 (표1(9) + 구분선(1) + 표2제목(1) + 표2(9) + 구분선(1) + 주석(1) = 22행)
        self.table.setRowCount(22)

        # 상반기(1~6월) 데이터 영역 (0~8행)
        y1 = QTableWidgetItem("당\n년\n도"); y1.setTextAlignment(Qt.AlignCenter)
        y1.setBackground(QColor(245, 245, 245)); y1.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(0, 0, y1); self.table.setSpan(0, 0, 9, 1)
        for r, rank in enumerate(self.ranks): 
            self.create_row_items(r, rank)
        
        self.table.setRowHeight(9, 15) # 구분선

        # 하반기(7~12월) 제목줄 (10행)
        h_f = QFont(); h_f.setBold(True)
        for c in range(26):
            it = QTableWidgetItem()
            it.setBackground(QColor(240, 240, 240)); it.setFont(h_f); it.setTextAlignment(Qt.AlignCenter)
            if c == 0: it.setText("구분")
            elif c == 1: it.setText("직급")
            else:
                m, idx = 7 + (c - 2) // 4, (c - 2) % 4
                labels = ["승진TO", "승진", "전년말\n미승진", "미승진자"]
                it.setText(f"{m}월\n{labels[idx]}" if idx != 2 else labels[idx])
            self.table.setItem(10, c, it)
        self.table.setRowHeight(10, 45)

        # 하반기(7~12월) 데이터 영역 (11~19행)
        y2 = QTableWidgetItem("당\n년\n도"); y2.setTextAlignment(Qt.AlignCenter)
        y2.setBackground(QColor(245, 245, 245)); y2.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(11, 0, y2); self.table.setSpan(11, 0, 9, 1)
        for r, rank in enumerate(self.ranks): 
            self.create_row_items(11 + r, rank)

        self.table.setRowHeight(20, 15) # 구분선

        # 주석 (21행)
        note_text = (
            "hwp 22페이지: 나. 별도직군 승진 가능 인원 내 미승진자 인원 계산\n\n"
            "미승진자 = 승진 T.O – min{ 승진 T.O , (승진 – 전년도말 미승진) }\n\n"
            "* ‘승진 T.O’는 ‘가. 별도직군 승진 가능 인원(승진T.O) 계산’의 “승진T.O” 인원을 기입함.\n"
            "* ‘승진’은 해당 직급으로 실제 승진한 인원을 월별로 누적하여 기재함.\n"
            "* ‘전년말 미승진’은 ‘다. 미승진자 평균인원’의 전년도 12월 미승진자 인원을 기입함."
        )
        n_it = QTableWidgetItem(note_text)
        n_it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.table.setItem(21, 0, n_it)
        self.table.setSpan(21, 0, 1, 26)
        self.table.setRowHeight(21, 160)
        
        self.table.blockSignals(False)

    def calculate_logic(self, item):
        r, c = item.row(), item.column()
        # 입력 불가 영역 제외
        if c < 2 or (c - 2) % 4 == 3 or r in [9, 10, 20, 21]: return
        
        self.table.blockSignals(True)
        try:
            m_base = 2 + ((c - 2) // 4) * 4
            start_r = 0 if r < 9 else 11
            total_row = start_r + 8 # 계 행 (8 또는 19)
            
            # 1. 미승진자 계산 (데이터 8개 행)
            for row in range(start_r, start_r + 8):
                to = self.get_val(row, m_base)
                prom = self.get_val(row, m_base + 1)
                prev = self.get_val(row, m_base + 2)
                res = to - min(to, max(0, prom - prev)) # 음수 방지 max(0,...)
                
                res_it = self.table.item(row, m_base + 3)
                if res_it: res_it.setData(Qt.EditRole, int(res))
            
            # 2. 세로 합계 (데이터 8개 행 합산)
            for col in range(m_base, m_base + 4):
                v_sum = sum(self.get_val(start_r + i, col) for i in range(8))
                s_it = self.table.item(total_row, col)
                if s_it: s_it.setData(Qt.EditRole, int(v_sum))
        finally: 
            self.table.blockSignals(False)

    def copy_selection(self):
        ranges = self.table.selectedRanges()
        if not ranges: return
        r0, r1 = min(r.topRow() for r in ranges), max(r.bottomRow() for r in ranges)
        c0, c1 = min(r.leftColumn() for r in ranges), max(r.rightColumn() for r in ranges)
        lines = []

        # [헤더 복사]
        if r0 == 0:
            h_row = []
            for c in range(c0, c1 + 1):
                h_item = self.table.horizontalHeaderItem(c)
                h_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(h_row))

        for r in range(r0, r1 + 1):
            if r in [9, 10, 20]:
                row_data = []
                for c in range(c0, c1 + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data)); continue

            if r == 21: # 주석 반복 방지
                it = self.table.item(r, 0)
                val = it.text().strip() if it else ""
                lines.append(val + "\t" * (c1 - c0)); continue

            row_data = []
            is_first_table = r < 9
            is_total_row = (r == 8 or r == 19)
            excel_r = r + 2 # 헤더 포함 기준
            data_start_r = 2 if is_first_table else 13
            data_end_r = 9 if is_first_table else 20

            for c in range(c0, c1 + 1):
                col_let = self.get_excel_col(c)
                # 미승진자 수식 (공식: TO - MIN(TO, 승진-전년말))
                if c >= 2 and (c - 2) % 4 == 3 and not is_total_row:
                    c_to = self.get_excel_col(c - 3)
                    c_prom = self.get_excel_col(c - 2)
                    c_prev = self.get_excel_col(c - 1)
                    val = f"={c_to}{excel_r}-MIN({c_to}{excel_r}, MAX(0, {c_prom}{excel_r}-{c_prev}{excel_r}))"
                # 합계 수식
                elif is_total_row and c >= 2:
                    val = f"=SUM({col_let}{data_start_r}:{col_let}{data_end_r})"
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').replace('\n', ' ') if it else ""
                    if val.startswith(('=', '-', '+')): val = "'" + val
                row_data.append(val)
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))




    def get_excel_col(self, n):
        res = ""
        n += 1
        while n > 0:
            n, rem = divmod(n - 1, 26)
            res = chr(65 + rem) + res
        return res
        



    def get_val(self, r, c):
        it = self.table.item(r, c)
        if not it: return 0.0
        try: return float(re.sub(r'[^\d.-]', '', it.text()))
        except: return 0.0

    def show_context_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #c0c0c0;
            }
            QMenu::item {
                padding: 6px 25px;
                color: black;
            }
            QMenu::item:selected {
                background-color: #5fa8f5;
                color: white;
            }
        """)

        menu.addAction("복사", self.copy_selection)
        menu.addAction("붙여넣기", self.paste_selection)
        menu.exec_(self.table.viewport().mapToGlobal(pos))





    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable):
                        # 엑셀의 수식 결과값에서 숫자만 추출하여 입력
                        it.setText(re.sub(r'[^\d.-]', '', val))
        self.table.blockSignals(False)
        self.calculate_logic(curr)
