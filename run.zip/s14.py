from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QPen

# [1] Sheet 14 전용 (을) 표시 델리게이트 (S3SymbolDelegate 구조 유지)
class S14SymbolDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        painter.save()
        # 8행(합계), 5열(인건비 효과)에 "(을)" 그리기
        if index.row() == 8 and index.column() == 5:
            painter.setPen(QPen(QColor(40, 40, 40))) 
            font = painter.font()
            font.setFamily("맑은 고딕")
            font.setPointSize(15) 
            font.setBold(True)
            painter.setFont(font)
            # 숫자와 겹치지 않게 왼쪽 여백(8) 조정
            painter.drawText(option.rect.adjusted(8, -3, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(을)")
        painter.restore()

# [2] 천단위 콤마 아이템 (Sheet 3와 동일)
class S14ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val or val == "n/a": return val
            try:
                clean_val = str(val).replace(',', '')
                return format(int(float(clean_val)), ",")
            except: return val
        return super().data(role)

class Sheet14Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        title = QLabel("hwp 25페이지: 나. 초임직급 정원 변동에 따른 인건비 효과")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        # 11행 6열 구성
        self.table = QTableWidget(11, 6)
        
        # [제목줄 설정] 요청하신 순서
        headers = [
            "직급", "전년도\n정원(A)", "당년도\n정원(B)", 
            "증감\n(C)=(B)-(A)", "전년도\n평균단가(D)", "인건비 효과\n(E)=(C)×(D)"
        ]
        self.table.setHorizontalHeaderLabels(headers)
        
        # [스타일 복구] Sheet 3와 동일한 번호열 및 구분선 설정
        self.table.verticalHeader().setFixedWidth(25) # 번호열 너비 고정
        self.table.horizontalHeader().setFixedHeight(45)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)
        self.table.verticalHeader().setDefaultSectionSize(28)

        # 델리게이트 적용
        self.table.setItemDelegateForRow(8, S14SymbolDelegate(self.table))

        self.setup_content()
        
        # 컬럼 너비 설정
        self.table.setColumnWidth(0, 60)
        for i in range(1, 4): self.table.setColumnWidth(i, 70)
        self.table.setColumnWidth(4, 108)        
        self.table.setColumnWidth(5, 157)

        self.table.itemChanged.connect(self.calculate_s14)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "... ...", "별도직군"]
        
        for r in range(11):
            for c in range(6):
                # 데이터/합계는 "0", 그 외(주석/빈칸)는 빈 문자열
                val = "0" if r <= 8 and c > 0 else ""
                item = S14ThousandSeparatorItem(val)
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                
                if r < 8: # 데이터 행
                    if c == 0:
                        item.setText(ranks[r]); item.setTextAlignment(Qt.AlignCenter)
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    elif c in [3, 5]: # 자동계산 열 (C, E)
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                elif r == 8: # 합계 행
                    item.setBackground(self.base_sky_blue)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    if c == 0: item.setText("계"); item.setTextAlignment(Qt.AlignCenter)
                else: # 주석 영역
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    item.setBackground(Qt.white)
                    item.setText("") # 0 제거
                self.table.setItem(r, c, item)

        self.table.setSpan(9, 0, 1, 6) # 빈 줄
        self.table.setRowHeight(9, 15)
        self.table.setSpan(10, 0, 1, 6) # 주석 줄

        note_html = (
            "hwp 25페이지: 나. 초임직급 정원 변동에 따른 인건비 효과<br><br>"
            "<b><span style='font-size:16pt;'>(을)</span></b> : "
            "hwp 10페이지의 (3) 총인건비 인상률 지표 점수계산 "
            "Template의 &lt;주25&gt; 칸에 적음<br><br>"
            " * 당년도 및 전년도 각 직급별 정원은 ‘가. 초임직급 정원 변동’의 평균정원을 기재함.<br><br>"
            " * 전년도 평균단가는 Template에서 계산된 전년도 실집행 기준 평균단가임."
        )

        label = QLabel()
        label.setText(note_html)
        label.setTextFormat(Qt.RichText)   # HTML 해석
        label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        label.setWordWrap(True)            # 자동 줄바꿈

        self.table.setCellWidget(10, 0, label)

        self.table.item(10, 0).setTextAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.table.setRowHeight(10, 150)
        self.table.blockSignals(False)

    def calculate_s14(self, item):
        r, c = item.row(), item.column()
        if r >= 8 or c not in [1, 2, 4]: return
        self.table.blockSignals(True)
        try:
            def gv(row, col):
                it = self.table.item(row, col)
                return float(it.text().replace(',', '')) if it and it.text() else 0.0
            vC = gv(r, 2) - gv(r, 1)
            self.table.item(r, 3).setData(Qt.EditRole, str(int(vC)))
            vE = vC * gv(r, 4)
            self.table.item(r, 5).setData(Qt.EditRole, str(int(vE)))
            for cs in [1, 2, 3, 5]:
                total = sum(gv(i, cs) for i in range(8))
                self.table.item(8, cs).setData(Qt.EditRole, str(int(total)))
        finally: self.table.blockSignals(False)

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r = min(r.topRow() for r in selection)
        max_r = max(r.bottomRow() for r in selection)
        min_c = min(r.leftColumn() for r in selection)
        max_c = max(r.rightColumn() for r in selection)
        lines = []

        # [수정] Sheet 3 로직: 0번 행 선택 시 제목줄 포함 복사
        if min_r == 0:
            headers = []
            for c in range(min_c, max_c + 1):
                h_item = self.table.horizontalHeaderItem(c)
                headers.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(headers))

        for r in range(min_r, max_r + 1):
            if r == 9: continue
            row_data = []
            ex_r = r + 2 if min_r == 0 else r + 1 # 제목 포함 여부에 따른 엑셀 행 번호
            for c in range(min_c, max_c + 1):
                it = self.table.item(r, c)
                val = it.text().replace(',', '') if it and it.text() else ""
                # [수식 복사 로직 복구 및 강화]
                if r < 8:
                    if c == 3: val = f"=C{ex_r}-B{ex_r}"
                    elif c == 5: val = f"=D{ex_r}*E{ex_r}"
                elif r == 8 and c in [1, 2, 3, 5]: # 합계 수식
                    col_L = chr(ord('A') + c)
                    val = f"=SUM({col_L}{ex_r-8}:{col_L}{ex_r-1})"
                row_data.append(val)
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        r_s, c_s = curr.row(), curr.column()
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = r_s + i, c_s + j
                if r < 8 and c in [1, 2, 4]: # 입력 가능 셀만
                    item = self.table.item(r, c)
                    if item: item.setText(val.strip().replace(',', ''))
        self.table.blockSignals(False)
        self.calculate_s14(self.table.item(0, 1))

    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C: self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V: self.paste_selection()
        else: super().keyPressEvent(event)

    def show_context_menu(self, pos):
        menu = QMenu()
        menu.addAction("복사 (Ctrl+C)", self.copy_selection)
        menu.addAction("붙여넣기 (Ctrl+V)", self.paste_selection)
        menu.exec_(self.table.viewport().mapToGlobal(pos))
