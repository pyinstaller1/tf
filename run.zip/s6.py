from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

class S6RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent); editor.setAlignment(Qt.AlignRight)
        return editor
    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class S6ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                num = float(str(val).replace(',', ''))
                return format(int(num), ",") if num == int(num) else format(num, ",.2f")
            except: return val
        return super().data(role)

class Sheet6Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        # 구성: 데이터(7행) + 구분선(1행) + 주석(1행) = 총 9행
        # 열 구성: 구분(0), 직급(1), 1~12월(2~13) = 총 14열
        self.table = QTableWidget(9, 14)
        
        months = [f"{i}월" for i in range(1, 13)]
        headers = ["구분", "직급"] + months
        self.table.setHorizontalHeaderLabels(headers)

        # [복구] 우클릭 메뉴 정책 설정 및 연결
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.verticalHeader().setFixedWidth(25)
        title = QLabel("hwp 18페이지: 나. 근속승진")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0; font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertical { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
        """)

        self.delegate = S6RightAlignedDelegate(self.table)
        for i in range(2, 14): self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        # 너비 설정
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 50)

        self.table.itemChanged.connect(self.calculate_s6)
        layout.addWidget(self.table)




            

    def setup_content(self):
        self.table.blockSignals(True)
        # 1. 5, 6직급을 포함한 전체 직급 리스트 (데이터 8행 + 계 1행 = 총 9개)
        self.ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "... ...", "별도직군", "계"]
        
        # 전체 행 수 조정: 데이터(9행) + 구분선(1행) + 주석(1행) = 총 11행
        self.table.setRowCount(11)
        
        comment_text = (
            "hwp 18페이지: 나. 근속승진\n\n"
            " * 직급별 누적차가 음수인 직급의 경우 해당 누적차(양수)를 기재하며, 그 이하 직급의 경우에는 해당 누적차(음수)를 기재함.\n\n"
            "   예시 1) 특정월의 4직급의 누적차가 –2인 경우 해당월의 4직급 란에는 2를 기재하고, 5급직 란에는 –2를 기재함.\n"
            "   예시 2) 특정월의 3직급의 누적차가 –3이고, 4직급의 누적차가 –2인 경우 3직급 란에는 3을 기재하고, 4직급 란에 -1, 5직급 란에 -2 기재."
        )
        
        for r in range(11):
            for c in range(14):
                if r == 9: # 구분선 (인덱스 9)
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags); item.setBackground(Qt.white)
                elif r == 10: # 주석 (인덱스 10)
                    item = QTableWidgetItem(comment_text if c == 0 else "")
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    item = S6ThousandSeparatorItem("0")
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)
                    
                    # 직급열(1) 및 계 행(8) 강조
                    if c == 1 or r == 8: 
                        item.setBackground(self.base_sky_blue)
                        if r == 8:
                            font = item.font(); font.setBold(True); item.setFont(font)
                    
                    # 구분열(0) 설정
                    if c == 0:
                        item.setBackground(QColor(245, 245, 245))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r == 0: item.setText("당년도")

                    # 직급명 입력 (0~8행)
                    if c == 1: 
                        item.setText(self.ranks[r])
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

                self.table.setItem(r, c, item)

        # 병합 및 높이 설정
        self.table.setSpan(0, 0, 9, 1)  # 당년도 구분 병합 (0~8행)
        self.table.setSpan(10, 0, 1, 14) # 주석 병합
        self.table.setRowHeight(9, 10)
        self.table.setRowHeight(10, 200)
        self.table.blockSignals(False)

    def calculate_s6(self, item):
        row, col = item.row(), item.column()
        # 입력 범위(0~7행 데이터 영역, 2~13열 월별 데이터) 외에는 제외
        if col < 2 or row >= 8: return 
        
        self.table.blockSignals(True)
        try:
            # 0~7행(1~6직급, ..., 별도직군)까지 합산하여 8행(계)에 표시
            col_sum = sum(float(self.table.item(r, col).text().replace(',', '') or 0) for r in range(8))
            self.table.item(8, col).setText(str(int(col_sum)))
        except: pass
        finally: self.table.blockSignals(False)

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        lines = []

        # [추가] 선택 영역에 첫 번째 행(0번)이 포함되면 상단 타이틀(Header)도 복사
        if min_r == 0:
            header_row = []
            for c in range(min_c, max_c + 1):
                h_item = self.table.horizontalHeaderItem(c)
                header_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(header_row))
        
        for r in range(min_r, max_r + 1):
            if r == 9: # 구분선 공백 처리
                lines.append("\t".join([""] * (max_c - min_c + 1)))
                continue
                
            row_data = []
            for c in range(min_c, max_c + 1):
                # 8행(계) 복사 시 엑셀 SUM 수식으로 변환 (데이터가 1~8행이므로 SUM 범위 조정)
                # 헤더가 추가되었으므로 엑셀 기준 행 번호는 +2가 됩니다.
                if r == 8 and c >= 2:
                    col_letter = chr(65 + c)
                    # 헤더(1행) + 데이터(2~9행) -> 합계(10행) 기준 수식
                    row_data.append(f"=SUM({col_letter}2:{col_letter}9)")
                
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    # 엑셀 붙여넣기 시 수식/기호 오작동 방지
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))
        





    def paste_selection(self):
        txt = QApplication.clipboard().text(); curr = self.table.currentItem()
        if not txt or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(txt.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable): it.setText(val.strip())
        self.table.blockSignals(False); self.calculate_s6(curr)



    def show_context_menu(self, pos):
        menu = QMenu(); cp = menu.addAction("복사 (Ctrl+C)"); ps = menu.addAction("붙여넣기 (Ctrl+V)")
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if act == cp: self.copy_selection()
        elif act == ps: self.paste_selection()


    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self.copy_selection()
        elif event.matches(QKeySequence.Paste):
            self.paste_selection()
        else:
            super().keyPressEvent(event)
