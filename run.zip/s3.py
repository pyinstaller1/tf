from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QCursor, QPen



class S3SymbolDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        # 기본 내용(숫자/텍스트) 먼저 그리기
        super().paint(painter, option, index)
        
        painter.save()
        # 마지막 줄(8행), 마지막 열(5열)에만 "갑" 그리기
        if index.row() == 8 and index.column() == 5:
            # 1. 펜 설정 (약간 더 진하게)
            painter.setPen(QPen(QColor(40, 40, 40))) 
            
            # 2. 폰트 설정 (기존 9pt에서 18pt로 2배 확대)
            font = painter.font()
            font.setFamily("맑은 고딕")
            font.setPointSize(15) 
            font.setBold(True) # 크기가 커지니 굵게 해야 더 잘 보입니다
            painter.setFont(font)
            
            # 3. 위치 조정 (adjusted: 왼쪽여백, 위쪽여백, 오른쪽여백, 아래쪽여백)
            # 위쪽 여백을 5 정도로 주어 너무 위로 붙지 않게 조절했습니다.
            painter.drawText(option.rect.adjusted(8, -3, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(갑)")
            
        painter.restore()



# [1] 천단위 콤마 아이템
class S3ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val == "n/a" or not val: return val
            try:
                clean_val = str(val).replace(',', '')
                return format(int(float(clean_val)), ",")
            except: return val
        return super().data(role)

# [2] 실시간 콤마 델리게이트
class S3RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        editor.textChanged.connect(lambda text: self.format_text(editor, text))
        return editor

    def format_text(self, editor, text):
        clean = text.replace(',', '')
        if not clean or clean == "-": return
        try:
            formatted = format(int(float(clean)), ",")
            if text != formatted:
                pos = editor.cursorPosition()
                old_len = len(text)
                editor.blockSignals(True)
                editor.setText(formatted)
                editor.setCursorPosition(pos + (len(formatted) - old_len))
                editor.blockSignals(False)
        except: pass

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet3Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.very_light_gray = QColor(252, 252, 252)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("hwp 15페이지: (3-1) 증원요소 인건비 계산을 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)
        
        # [수정] 총 11행: 데이터(0~7), 합계(8), 빈줄(9), 주석(10)
        self.table = QTableWidget(11, 6) 
        
        headers = [
            "직급\n<주1>", "전년도\n인원\n(A)", "당년도\n인원\n(B)", 
            "인원 증감\n(C)=(B)-(A)\n<주2>", "전년도의\n평균단가\n(D) <주3>", "증원소요 인건비\n(C) × (D)"
        ]
        self.table.setHorizontalHeaderLabels(headers)
        self.table.verticalHeader().setFixedWidth(25)
        
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;
            }
        """)

        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        self.delegate = S3RightAlignedDelegate(self.table)
        self.symbol_delegate = S3SymbolDelegate(self.table)
        
        for i in range(1, 6):
            self.table.setItemDelegateForColumn(i, self.delegate)

        # 8행(합계)에만 "(갑)" 표시 델리게이트 적용
        self.table.setItemDelegateForRow(8, self.symbol_delegate)

        self.setup_content()
        
        self.table.setColumnWidth(0, 70)
        self.table.setColumnWidth(1, 75)
        self.table.setColumnWidth(2, 75) 
        self.table.setColumnWidth(3, 85) 
        self.table.setColumnWidth(4, 95) 
        self.table.setColumnWidth(5, 150)

        self.table.verticalHeader().setDefaultSectionSize(26)

        self.table.verticalHeader().setSectionResizeMode(10, QHeaderView.Fixed)
        self.table.setRowHeight(10, 380) # 주석 내용이 길어서 높게 설정
        
        self.table.itemChanged.connect(self.calculate_s3)
        self.table.itemClicked.connect(self.handle_click)
        
        layout.addWidget(self.table)



    def handle_click(self, item):
        row, col = item.row(), item.column()
        
        title = ""
        desc = ""
        
        # [1] 마지막 합계 행 (8행) - 모든 열 클릭 시 설명 출력

        if col == 0: # 특히 '갑'이 있는 마지막 칸
            title = "직급 "
            desc = ("<b>&lt;주1&gt;</b><br>"
                    "제시된 직급구분은 예시적인 것임.<br>직급은 모든 직원을 대상으로 하여 구분하되,<br>잡급(정원에 포함하지 않는 비정규직에 대한 인건비) 및 무기계약직은 그 대상에 포함하지 않음.")
        
        if row == 8:
            if col == 5: # 특히 '갑'이 있는 마지막 칸
                title = "증원소요 인건비 합계 (갑)"
                desc = ("<b>[산식]</b><br>"
                        "직급별 '인원 증감(D)'과 '전년도 평균단가(E)'를 곱한 금액의 총합계입니다.<br><br>"
                        "※ 이 금액 <b>(갑)</b>은 이전 Sheet(9p인상률점수)의 <b>'증원소요 인건비'</b> 항목에 자동 반영됩니다.")
                

                
            elif col not in [0, 5]:
                title = "항목별 총합계"
                desc = "해당 열의 직급별 데이터를 모두 합산한 결과값입니다."

        # [2] 일반 데이터 행 (0~7행) 중 A, D, F열만 허용
        elif row < 8:
            
            # D열 (index 3): 인원 증감 (자동계산)
            if col == 3:
                title = "인원 증감 (D) <주2>"
                desc = "<b><주2></b> 당년도 정원(C) - 전년도 정원(B) 산식에 의해 자동으로 계산되는 칸입니다."
            
            # F열 (index 5): 증원소요 인건비 (자동계산)
            elif col == 5:
                title = "증원소요 인건비 (F)"
                desc = "<b>[산식] 인원 증감(D) × 전년도 평균단가(E)</b><br>해당 직급의 증원에 따른 인건비 소요액을 자동으로 계산합니다."

        # 메시지 박스 출력 (위 조건에 해당하여 desc가 생성된 경우만)
        if desc:
            msg = QMessageBox(self)
            msg.setWindowTitle("항목 상세 설명")
            msg.setText(f"<div style='font-family: 맑은 고딕; font-size: 10pt;'>"
                        f"<b style='color: #0056b3;'>[{title}]</b><br><br>{desc}</div>")
            msg.setStandardButtons(QMessageBox.Ok)
            msg.exec_()
        

    def setup_content(self):
        self.table.blockSignals(True)
        ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "... ...", "별도직군"]
        
        for r in range(11): # 11행까지 생성
            for c in range(6):
                # 기본적으로 숫자가 들어가는 칸은 콤마 아이템 적용
                item = S3ThousandSeparatorItem("0") if c >= 1 else QTableWidgetItem("")
                
                # [1] 데이터 행 (0~7행)
                if r < 8:
                    if c in [0, 3, 5]: # 자동계산 및 제목 칸
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if c == 0:
                            item.setText(ranks[r] if r < len(ranks) else "")
                            item.setTextAlignment(Qt.AlignCenter)
                        else:
                            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    else: # 입력 가능 칸 (B, C, E열)
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

                # [2] 합계 행 (8행)
                elif r == 8:
                    item.setBackground(self.base_sky_blue)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    if c == 0:
                        item.setText("계")
                        item.setFont(QFont("맑은 고딕", 9, QFont.Bold))
                        item.setTextAlignment(Qt.AlignCenter)
                    else:
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

                # [3] 빈 줄 (9행)
                elif r == 9:
                    item.setFlags(Qt.NoItemFlags) # 선택/수정 불가
                    item.setBackground(Qt.white)

                # [4] 주석 행 (10행)
                elif r == 10:
                    if c == 0:
                        # 1. QLabel 생성 (HTML 태그 사용 가능)
                        note_text = """
                        <div style='line-height: 140%;'>
                            hwp 15페이지: (3-1) 증원소요 인건비 계산을 위한 Template<br>
                            마지막 셀 <b><font size=6>(갑)</font></b> 은 이전 Sheet (10p인상률점수)의 &lt;주23&gt; 의 셀에 적음.<br><br>



                        
                            <b>&lt;주1&gt;</b><br>
                            제시된 직급구분은 예시적인 것임.<br>직급은 모든 직원을 대상으로 하여 구분하되,<br>
                            잡급(정원에 포함하지 않는 비정규직에 대한 인건비) 및 무기계약직은 그 대상에 포함하지 않음.<br><br>
                            
                            <b>&lt;주2&gt;</b><br>
                            당년도 및 전년도 각 직급별 인원은 (3-3)의 “다. 증원소요인건비 대상 인원”을 기재함.<br><br>
                            
                            <b>&lt;주3&gt;</b><br>
                            전년도의 평균단가는 (3-4)직급별 평균단가 계산을 위한 Template에서 계산된 전년도 평균단가임.<br>
                            (별도직군의 경우 평균단가는 기재하지 않음)<br>
                            다만, 인상률 위반 기관의 경우 증원소요인건비 계산시 전년도 직급별 평균단가는 전년도 실집행액 인건비가 아닌 위반하지 않았을 경우 직급별 인건비를 기준으로 계산함. 
                            
                        </div>
                        """

                        note_label = QLabel(note_text)



                        
                        # 2. 스타일 설정 (글꼴, 자동 줄바꿈, 정렬)
                        note_label.setFont(QFont("맑은 고딕", 9))
                        note_label.setWordWrap(True) # 자동 줄바꿈 필수!
                        note_label.setAlignment(Qt.AlignLeft | Qt.AlignTop) # 왼쪽 상단 정렬
                        note_label.setStyleSheet("background-color: white; padding: 5px; border: none;")
                        
                        # 3. 셀에 위젯으로 박기
                        self.table.setCellWidget(10, 0, note_label)
                    
                    # 주석 칸은 아이템 자체는 빈 걸로 채워둠 (배경색 등 관리용)
                    item.setFlags(Qt.ItemIsEnabled)
                    item.setBackground(Qt.white)

                self.table.setItem(r, c, item)

        # --- 셀 병합 및 높이 조정 ---
        # 9행 (빈 줄) 병합 및 높이
        self.table.setSpan(9, 0, 1, 6)
        self.table.setRowHeight(9, 15)

        # 10행 (주석) 병합 및 높이
        self.table.setSpan(10, 0, 1, 6)


        self.table.blockSignals(False)








    def calculate_s3(self, item):
        row, col = item.row(), item.column()
        # 입력 범위(B, C, E열) 데이터 변경 시 계산 실행
        if col not in [1, 2, 4] or row >= 8: return  
        
        self.table.blockSignals(True)
        try:
            def gv(r, c):
                it = self.table.item(r, c)
                txt = it.text().replace(',', '') if it else ""
                try: return float(txt) if txt else 0.0
                except: return 0.0
            
            # 1. 인원 증감 (C) = 당년도(B) - 전년도(A)
            vA, vB = gv(row, 1), gv(row, 2)
            vC = vB - vA
            it_c = self.table.item(row, 3)
            if it_c:
                it_c.setData(Qt.EditRole, int(vC))
            
            # 2. 증원소요 인건비 = 인원 증감(C) * 평균단가(D)
            vD = gv(row, 4)
            vCost = vC * vD
            it_cost = self.table.item(row, 5)
            if it_cost:
                it_cost.setData(Qt.EditRole, int(vCost))
            
            # 3. 합계행(8행) 갱신
            sum_row = 8
            # [수정] 4번 열(평균단가)을 합계 대상에 추가함 [1, 2, 3, 4, 5]
            for c_sum in [1, 2, 3, 4, 5]:
                total = sum(gv(r, c_sum) for r in range(8))
                it_total = self.table.item(sum_row, c_sum)
                if it_total:
                    it_total.setData(Qt.EditRole, int(total))
                
        except Exception as e:
            print(f"Calculation Error: {e}")
        finally: 
            self.table.blockSignals(False)

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r = min(r.topRow() for r in selection)
        max_r = max(r.bottomRow() for r in selection)
        min_c = min(r.leftColumn() for r in selection)
        max_c = max(r.rightColumn() for r in selection)
        
        lines = []

        # [타이틀 복사] 첫 행 포함 시 헤더 추출
        if min_r == 0:
            headers = []
            for c in range(min_c, max_c + 1):
                h_item = self.table.horizontalHeaderItem(c)
                h_text = h_item.text().replace('\n', ' ') if h_item else f"열{c}"
                headers.append(h_text)
            lines.append("\t".join(headers))

        # [데이터 및 수식 복사]
        for r in range(min_r, max_r + 1):
            if r >= 9: # 빈줄/주석 제외 (필요 시 포함 가능)
                continue
                
            row_data = []
            # 헤더 포함 여부에 따른 엑셀 행 번호 계산
            excel_r = r + 2 if min_r == 0 else r + 1
            
            for c in range(min_c, max_c + 1):
                col_L = chr(ord('A') + c)
                val = ""
                
                # 데이터 행 수식 (0~7행)
                if r < 8:
                    if c == 3: # 인원 증감: C-B
                        val = f"=C{excel_r}-B{excel_r}"
                    elif c == 5: # 인건비: D*E
                        val = f"=D{excel_r}*E{excel_r}"
                    else:
                        it = self.table.item(r, c)
                        val = it.text().replace(',', '').strip() if it else ""
                
                # 합계 행 수식 (8행)
                elif r == 8:
                    if c >= 1: # 모든 숫자 열에 대해 SUM 적용
                        # 데이터 범위는 엑셀 행 기준으로 헤더 유무에 따라 계산
                        start_r = 2 if min_r == 0 else excel_r - 8
                        end_r = 9 if min_r == 0 else excel_r - 1
                        val = f"=SUM({col_L}{start_r}:{col_L}{end_r})"
                    else:
                        it = self.table.item(r, c)
                        val = it.text() if it else ""
                
                # 특수문자 처리
                if val.startswith(('=', '-', '+')) and not any(char.isdigit() for char in val):
                    val = "'" + val
                row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))























        







    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사 (Ctrl+C)")
        paste_action = menu.addAction("붙여넣기 (Ctrl+V)")
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action: self.copy_selection()
        elif action == paste_action: self.paste_selection()







    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        r_s, c_s = curr.row(), curr.column()
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = r_s + i, c_s + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    item = self.table.item(r, c)
                    if item and (item.flags() & Qt.ItemIsEditable):
                        item.setText(val.strip().replace(',', ''))
        self.table.blockSignals(False)
        self.calculate_s3(self.table.item(0, 1))

    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C: self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V: self.paste_selection()
        else: super().keyPressEvent(event)
