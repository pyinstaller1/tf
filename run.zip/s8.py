from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

# [1] S8 전용 우측 정렬 델리게이트
class S8RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor
    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

# [2] S8 전용 천단위 콤마 아이템
class S8ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if val is None or str(val).strip() == "": return ""
            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                if num == int(num): return format(int(num), ",")
                else: return format(num, ",.2f")
            except: return val
        return super().data(role)

class Sheet8Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("hwp 20페이지: (3-4) 직급별 평균단가 계산을 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)        

        # 열 구성: 구분(0), 직급(1), 1~12월(2-13), 인건비총계(14), 직급별평균단가(15)
        self.table = QTableWidget(18, 16)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # [수정] 행 높이를 25px로 압축 (가장 슬림한 표준)
        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.verticalHeader().setFixedWidth(25)

        # 스타일 시트 (스크롤바 강조 및 여백 최소화)
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section {
                background-color: #f4f4f4; padding: 2px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal;  /* 행 번호 글자 굵게 하지 않음 */
            }            
            QScrollBar:vertical { background: #f1f1f1; width: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar::handle:vertical:hover { background: #555555; }
            QScrollBar:horizontal { background: #f1f1f1; height: 16px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
            QScrollBar::handle:horizontal:hover { background: #555555; }
            QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
        """)

        # [수정] 제목줄 1줄로 고정 (줄바꿈 제거)
        headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["인건비 총계", "직급별 평균단가"]
        self.table.setHorizontalHeaderLabels(headers)

        self.delegate = S8RightAlignedDelegate(self.table)
        for i in range(2, 16):
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        # 너비 설정
        self.table.setColumnWidth(0, 50); self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 100)
        self.table.setColumnWidth(14, 120); self.table.setColumnWidth(15, 120)

        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Fixed)

        self.table.itemChanged.connect(self.calculate_s8)
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        # 1. 직급 리스트 확장
        ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "... ...", "별도직군", "계"]
        num_ranks = len(ranks) # 9개
        
        full_headers = ["구분", "직급"] + [f"{i}월" for i in range(1, 13)] + ["인건비 총계", "직급별 평균단가"]
        
        # 전체 행 수 조정 (전년도9 + 구분선1 + 제목1 + 당년도9 + 구분선1 + 주석1 = 22)
        self.table.setRowCount(22)

        for r in range(22):
            for c in range(16):
                # 특수 행 설정 (9:구분선, 10:중간제목, 20:구분선, 21:주석)
                if r in [9, 20]: 
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags); item.setBackground(Qt.white)
                elif r == 10: 
                    item = QTableWidgetItem(full_headers[c])
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setBackground(QColor(244, 244, 244))
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    f = item.font(); f.setBold(True); item.setFont(f)
                elif r == 21:
                    note = (
                        "hwp 20페이지: (3-4) 직급별 평균단가 계산을 위한 Template\n\n"
                        "* 전년도와 당년도 평균단가(인건비 총계 ÷ 12)를 계산하여 인상률 차등적용이 적절하게 이루어졌는지를 확인함.\n"
                        "* 각 직급별로 매월 지급된 인건비를 해당 월에 기입함.\n"
                        "* 직급별 평균단가는 1월부터 12월까지의 인건비 합계금액을 12로 나누어서 구함."
                    )
                    item = QTableWidgetItem(note)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignTop)
                else:
                    item = S8ThousandSeparatorItem("0")
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)
                    
                    # 계 행(8, 19) 및 계산 열(14, 15), 직급열(1) 배경색/잠금
                    if c == 1 or r == 8 or r == 19 or c >= 14:
                        item.setBackground(self.base_sky_blue)
                        if r in [8, 19] or c >= 14:
                            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                            f = item.font(); f.setBold(True); item.setFont(f)
                    
                    # 구분 열 (0열)
                    if c == 0:
                        item.setBackground(QColor(245, 245, 245))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r == 0: item.setText("전년도")
                        elif r == 11: item.setText("당년도")

                    # 직급 명칭 (1열)
                    if c == 1:
                        if 0 <= r <= 8: item.setText(ranks[r])
                        elif 11 <= r <= 19: item.setText(ranks[r-11])

                self.table.setItem(r, c, item)

        self.table.setSpan(0, 0, 9, 1); self.table.setSpan(11, 0, 9, 1); self.table.setSpan(21, 0, 1, 16)
        self.table.setRowHeight(9, 10); self.table.setRowHeight(20, 10); self.table.setRowHeight(21, 180)
        self.table.blockSignals(False)

    def calculate_s8(self, item):
        row, col = item.row(), item.column()
        # 입력 제외 행/열 필터링
        if col < 2 or col >= 14 or row in [8, 9, 10, 19, 20, 21]: return 
        self.table.blockSignals(True)
        try:
            # 데이터 범위 정의 (0~7행, 11~18행)
            if 0 <= row <= 7: data_rows, sum_row = list(range(8)), 8
            elif 11 <= row <= 18: data_rows, sum_row = list(range(11, 19)), 19
            else: return

            # 1. 가로 계산 (총계 및 평균단가)
            row_sum = sum(float(self.table.item(row, c).text().replace(',', '') or 0) for c in range(2, 14))
            self.table.item(row, 14).setData(Qt.EditRole, int(row_sum))
            self.table.item(row, 15).setData(Qt.EditRole, round(row_sum / 12, 2))

            # 2. 세로 합계 (월별/총계/평균단가 합산)
            col_sum = sum(float(self.table.item(r, col).text().replace(',', '') or 0) for r in data_rows)
            self.table.item(sum_row, col).setData(Qt.EditRole, int(col_sum))

            # 14, 15열(계산열)의 세로 합계 업데이트
            for target_col in [14, 15]:
                v_total = sum(float(self.table.item(r, target_col).text().replace(',', '') or 0) for r in data_rows)
                if target_col == 14: self.table.item(sum_row, target_col).setData(Qt.EditRole, int(v_total))
                else: self.table.item(sum_row, target_col).setData(Qt.EditRole, round(v_total, 2))
        finally: 
            self.table.blockSignals(False)

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        # 선택 영역 범위 계산
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        lines = []

        # 1. 제목줄 복사 (표 상단 0행 포함 시)
        if min_r == 0:
            h_row = []
            for c in range(min_c, max_c + 1):
                h_item = self.table.horizontalHeaderItem(c)
                h_row.append(h_item.text().replace('\n', ' ') if h_item else "")
            lines.append("\t".join(h_row))

        for r in range(min_r, max_r + 1):
            # 2. 중간 제목줄(10행) 및 구분선(9, 20행) 처리
            if r in [9, 10, 20]:
                row_data = []
                for c in range(min_c, max_c + 1):
                    it = self.table.item(r, c)
                    row_data.append(it.text().replace('\n', ' ') if it else "")
                lines.append("\t".join(row_data))
                continue

            # 3. 주석 행(21행) 처리 - 열마다 반복되는 문제 해결
            if r == 21:
                it = self.table.item(r, 0) # 주석은 0번 열에만 존재
                val = it.text().strip() if it else ""
                # 첫 열에만 주석 내용을 넣고 나머지는 탭으로 비움
                lines.append(val + "\t" * (max_c - min_c))
                continue
                
            # 4. 일반 데이터 행 처리
            row_data = []
            ex_r = r + 2 # 엑셀 행 번호 보정

            for c in range(min_c, max_c + 1):
                col_let = chr(65 + c)
                is_data = (0 <= r <= 7) or (11 <= r <= 18)
                
                # 가로 총계 (인건비 총계)
                if is_data and c == 14:
                    row_data.append(f"=SUM(C{ex_r}:N{ex_r})")
                # 가로 평균 (직급별 평균단가)
                elif is_data and c == 15:
                    row_data.append(f"=ROUND(O{ex_r}/12, 2)")
                # 전년도 세로 합계 (데이터 2~9행)
                elif r == 8 and c >= 2:
                    row_data.append(f"=SUM({col_let}2:{col_let}9)")
                # 당년도 세로 합계 (데이터 13~20행)
                elif r == 19 and c >= 2:
                    row_data.append(f"=SUM({col_let}13:{col_let}20)")
                else:
                    it = self.table.item(r, c)
                    val = it.text().replace(',', '').strip() if it else ""
                    if val.startswith(('=', '-', '+')): val = "'" + val
                    row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))


        

    def paste_selection(self):
        txt = QApplication.clipboard().text(); curr = self.table.currentItem()
        if not txt or not curr: return
        self.table.blockSignals(True)
        for i, line in enumerate(txt.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    it = self.table.item(r, c)
                    if it and (it.flags() & Qt.ItemIsEditable): it.setText(val.strip())
        self.table.blockSignals(False)
        self.calculate_s8(curr)

    def show_context_menu(self, pos):
        menu = QMenu()
        cp = menu.addAction("복사 (Ctrl+C)"); ps = menu.addAction("붙여넣기 (Ctrl+V)")
        act = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if act == cp: self.copy_selection()
        elif act == ps: self.paste_selection()

        

    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy): self.copy_selection()
        elif event.matches(QKeySequence.Paste): self.paste_selection()
        else: super().keyPressEvent(event)
