from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QCursor

# [1] 천단위 콤마 및 소수점 처리 아이템 (S15 로직 유지)
class ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            if not val or val == "n/a": return val
            try:
                clean_val = str(val).replace(',', '')
                table = self.tableWidget()
                # S16의 최종 지표 행 번호는 41
                if table and table.row(self) == 41: 
                    return format(float(clean_val), ",.2f")
                return format(int(float(clean_val)), ",")
            except: return val
        return super().data(role)

# [2] 실시간 입력 델리게이트 (S16 보호행 적용)
class RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        # S16 계산/결과 행 보호
        protected = [4, 8, 12, 21, 25, 29, 33, 37, 39, 41]
        if index.row() in protected or index.column() == 0:
            return None
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet16Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.target_light_blue = QColor(247, 250, 255)
        self.very_light_gray = QColor(252, 252, 252)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        title = QLabel("hwp 30페이지: (6) 일반관리비 관리 지표의 점수계산을 위한 Template(2)_준정부기관")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(42, 4)
        self.table.setHorizontalHeaderLabels(["구분", "2025", "2024", "2023"])
        self.table.verticalHeader().setFixedWidth(25)
        self.table.setColumnWidth(0, 450)
        for i in range(1, 4): self.table.setColumnWidth(i, 130)
        
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # S15 스타일 완벽 복구
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section { 
                background-color: #f4f4f4; font-weight: bold; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal; 
            }
            QScrollBar:vertical { background: #f1f1f1; width: 14px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:vertical { background: #888888; min-height: 30px; border-radius: 2px; }
            QScrollBar:horizontal { background: #f1f1f1; height: 14px; border: 1px solid #dcdcdc; }
            QScrollBar::handle:horizontal { background: #888888; min-width: 30px; border-radius: 2px; }
        """)

        self.delegate = RightAlignedDelegate(self.table)
        for i in range(1, 4): self.table.setItemDelegateForColumn(i, self.delegate)




        self.setup_content()
        self.table.itemClicked.connect(self.handle_help_popup)
        self.table.itemChanged.connect(self.calculate_totals)
        layout.addWidget(self.table)


        footer_note = QLabel(
            "<font color='#555555'>"
            "<b>&lt;주1&gt;</b> 인건비집계를 위한 template상의 (가)에 기입된 금액을 옮겨 적음 (hwp 7페이지)<br>"
            "<b>&lt;주2&gt;</b> 인건비집계를 위한 template상의 (다)에 기입된 금액을 옮겨 적음 (hwp 7페이지)<br>"
            "<b>&lt;주3&gt;</b> 인건비집계를 위한 template상의 잡급, 무기계약직의 일반급여 ㈆과 무기계약직급여 ㈈을 합한 금액 (hwp 7페이지)<br>"
            "<b>&lt;주4&gt;</b> 인건비집계를 위한 template상의 ㈂의 금액을 옮겨 적음 (hwp 6페이지)<br>"
            "<b>&lt;주5&gt;</b> 인건비집계를 위한 template상의 ㈃의 금액을 옮겨 적음 (hwp 6페이지)"
            "</font>"
        )
        footer_note.setStyleSheet("margin-top: 5px; padding: 5px; background-color: #fcfcfc; border: 1px solid #eeeeee;")
        layout.addWidget(footer_note)

        

    def setup_content(self):
        self.table.blockSignals(True)
        rows = [
            "1. 사업비(직접사업비와 사업비성 경비)와 판관비(또는 경비)", "  a. 손익계산서 등의 직접사업비<주1>", "  b. 손익계산서 등의 사업비성 경비<주1>", "  c. 손익계산서상의 판관비(또는 경비)", "▶ 사업비와 판관비 계: (A) = a+b+c", "2. 사업비 중 제외항목 <주2>", "  d. 직접사업비", "  e. 사업비성 경비", "▶ 제외항목 총계: (B) = d+e", "3. 비정규직 인건비 등 <주3>", "  f. 비정규직 인건비 등 총계", "  g. 비정규직 특수건강진단비", "▶ 차감 비정규직 인건비 등: (C) = f-g", "4. 비상임이사 인건비(D)<주4>", "5. 인상률 제외 인건비(E) <주5>", "6. 사내근로복지기금 집행액(F) <주6>", "7. 감가상각비", "  h. 사업비로 처리된 유형자산 감가상각비", "  i. 사업비로 처리된 무형자산 감가상각비", "  j. 판관비로 처리된 유형자산 감가상각비", "  k. 판관비로 처리된 무형자산 감가상각비", "▶ 감가상각비 총계: (G) = h+i+j+k", "8. 교육훈련비 <주7>", "  l. 사업비로 처리된 교육훈련비", "  m. 판관비로 처리된 교육훈련비", "▶ 교육훈련비 총계: (H) = l+m", "9. 연구비 및 경상개발비 <주7>", "  n. 사업비로 처리된 연구비 및 경상개발비", "  o. 판관비로 처리된 연구비 및 경상개발비", "▶ 연구비 및 경상개발비 총계: (I) = n+o", "10. 세금과공과 <주7, 8>", "  p. 사업비로 처리된 세금과공과", "  q. 판관비로 처리된 세금과공과", "▶ 세금과공과 총계: (J) = p+q", "11. 수선유지비 <주7, 9>", "  r. 사업비로 처리된 수선유지비", "  s. 판관비로 처리된 수선유지비", "▶ 수선유지비 총계: (K) = r+s", "12. 직장어린이집 설치비용(L) <주7, 10>", "■ 일반관리비: (M)=(A)-(B)+(C)+(D)+(E)+(F)-(G)-(H)-(I)-(J)-(K)-(L)", "매출액 (N)", "◎ 일반관리비 관리 지표 = (M)/(N)"
        ]
        for r, text in enumerate(rows):
            item_a = QTableWidgetItem(text)
            item_a.setBackground(self.very_light_gray)
            item_a.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            if any(mark in text for mark in ["▶", "■", "◎"]):
                item_a.setBackground(self.base_sky_blue)
                item_a.setFont(QFont("Malgun Gothic", 9, QFont.Bold))
            self.table.setItem(r, 0, item_a)
            for c in range(1, 4):
                item = ThousandSeparatorItem("0")
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if r in [4, 8, 12, 21, 25, 29, 33, 37, 39, 41]:
                    item.setBackground(self.target_light_blue)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self.table.setItem(r, c, item)
        self.table.blockSignals(False)

    def calculate_totals(self, item):
        col = item.column()
        if col == 0: return
        self.table.blockSignals(True)
        try:
            def gv(r):
                it = self.table.item(r, col)
                return float(it.text().replace(',', '')) if it and it.text() else 0.0
            
            # S16 계산 로직
            a, b, c = gv(1)+gv(2)+gv(3), gv(6)+gv(7), gv(10)-gv(11)
            g_tot = gv(17)+gv(18)+gv(19)+gv(20)
            h, i, j, k = gv(23)+gv(24), gv(27)+gv(28), gv(31)+gv(32), gv(35)+gv(36)
            m = a-b+c+gv(13)+gv(14)+gv(15)-g_tot-h-i-j-k-gv(38)
            
            res = {4:a, 8:b, 12:c, 21:g_tot, 25:h, 29:i, 33:j, 37:k, 39:m}
            for row, val in res.items(): self.table.item(row, col).setText(str(int(val)))
            if gv(40) != 0: self.table.item(41, col).setText(str(round(m/gv(40), 10)))
        except: pass
        finally: self.table.blockSignals(False)

    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사")
        paste_action = menu.addAction("붙여넣기")
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if action == copy_action: self.copy_selection()
        elif action == paste_action: self.paste_selection()

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)
        
        lines = []
        # [복구 및 개선] 헤더 포함 복사
        header_labels = [self.table.horizontalHeaderItem(c).text() for c in range(min_c, max_c + 1)]
        lines.append("\t".join(header_labels))

        for r in range(min_r, max_r + 1):
            row_data = []
            for c in range(min_c, max_c + 1):
                item = self.table.item(r, c)
                text = item.text() if item else ""
                if c >= 1:
                    col_L, ex_r = chr(ord('A') + c), r + 2
                    formulas = {
                        4:f"={col_L}{ex_r-3}+{col_L}{ex_r-2}+{col_L}{ex_r-1}",
                        8:f"={col_L}{ex_r-2}+{col_L}{ex_r-1}",
                        12:f"={col_L}{ex_r-2}-{col_L}{ex_r-1}",
                        21:f"={col_L}{ex_r-4}+{col_L}{ex_r-3}+{col_L}{ex_r-2}+{col_L}{ex_r-1}",
                        25:f"={col_L}{ex_r-2}+{col_L}{ex_r-1}",
                        29:f"={col_L}{ex_r-2}+{col_L}{ex_r-1}",
                        33:f"={col_L}{ex_r-2}+{col_L}{ex_r-1}",
                        37:f"={col_L}{ex_r-2}+{col_L}{ex_r-1}",
                        # (M) 공식 엑셀 고정 행 보정
                        39:f"={col_L}6-{col_L}10+{col_L}14+{col_L}15+{col_L}16+{col_L}17-{col_L}23-{col_L}27-{col_L}31-{col_L}35-{col_L}39-{col_L}40",
                        41:f"=IF({col_L}42=0,0,{col_L}41/{col_L}42)"
                    }
                    text = formulas.get(r, text.replace(',', ''))
                row_data.append(text)
            lines.append("\t".join(row_data))
        QApplication.clipboard().setText("\n".join(lines))

    def paste_selection(self):
        clipboard = QApplication.clipboard().text()
        if not clipboard: return
        rows = clipboard.split('\n')
        current = self.table.currentItem()
        if not current: return
        self.table.blockSignals(True)
        for i, row_text in enumerate(rows):
            if "\t" not in row_text: continue
            cols = row_text.split('\t')
            for j, col_text in enumerate(cols):
                r, c = current.row()+i, current.column()+j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    if c >= 1 and r not in [4, 8, 12, 21, 25, 29, 33, 37, 39, 41]:
                        item = self.table.item(r, c)
                        if item: item.setData(Qt.EditRole, col_text.strip().replace(',', ''))
        self.table.blockSignals(False)
        self.calculate_totals(current)

    def handle_help_popup(self, item):
        if item.column() != 0: return
        # 요청하신 주석 내용으로 맵핑
        helps = {
            1: "<b>&lt;주1&gt;</b><br> 인건비집계를 위한 template상의 (가)에 기입된 금액을 옮겨 적음. (hwp 7페이지)",
            2: "<b>&lt;주1&gt;</b><br> 인건비집계를 위한 template상의 (가)에 기입된 금액을 옮겨 적음. (hwp 7페이지)",
            5: "<b>&lt;주2&gt;</b><br> 인건비집계를 위한 template상의 (다)에 기입된 금액을 옮겨 적음. (hwp 7페이지)",
            9: "<b>&lt;주3&gt;</b><br> 인건비집계를 위한 template상의 잡급 및 무기계약직의 일반급여 ㈆과 무기계약직급여 ㈈을 합한 금액",
            13: "<b>&lt;주4&gt;</b><br> 인건비집계를 위한 template상의 ㈂의 금액을 옮겨 적음. (hwp 6페이지)",
            14: "<b>&lt;주5&gt;</b><br> 인건비집계를 위한 template상의 ㈃의 금액을 옮겨 적음. (hwp 6페이지)"
        }
        row = item.row()
        if row in helps:
            QMessageBox.information(self, "항목 상세 설명", f"<b>[{item.text()}]</b><br><br>{helps[row]}")
            

    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier:
            if event.key() == Qt.Key_C: self.copy_selection()
            elif event.key() == Qt.Key_V: self.paste_selection()
        else: super().keyPressEvent(event)
