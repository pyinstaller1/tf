from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QKeySequence

# [1] 천단위 콤마 아이템 (평균인원은 소수점 대응)
class S4ThousandSeparatorItem(QTableWidgetItem):
    def data(self, role):
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)
            # 수정: 값이 없거나 None이면 빈 문자열 반환 (0 방지)
            if val is None or str(val).strip() == "": return ""
            if val == "0": return "0"
            try:
                clean_val = str(val).replace(',', '')
                num = float(clean_val)
                if num == int(num): return format(int(num), ",")
                else: return format(num, ",.1f")
            except: return val
        return super().data(role)

    

# [2] 실시간 우측 정렬 델리게이트
class S4RightAlignedDelegate(QStyledItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

    def setModelData(self, editor, model, index):
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)

class Sheet4Page(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        # S2/S3와 동일한 기존 파란색 설정
        self.base_sky_blue = QColor(220, 235, 245) 
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel("hwp 16페이지: (3-2) 직급별 평균인원 계산을 위한 Template")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget(21, 15)
        
        months = [f"{i}월" for i in range(1, 13)]
        headers = ["구분", "직급"] + months + ["평균인원"]
        self.table.setHorizontalHeaderLabels(headers)

        # [1] 우클릭 메뉴 정책 설정 (이게 있어야 메뉴가 뜹니다)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)

        # 스타일시트 적용
        self.table.setStyleSheet("""
            QTableWidget { gridline-color: #d0d0d0; border: 1px solid #d0d0d0; }
            QHeaderView::section:horizontal {
                background-color: #f4f4f4; padding: 2px; border: 0px;
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; padding-left: 5px; padding-right: 5px;
                border: 0px; border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
            }
        """)

        self.table.verticalHeader().setVisible(True)
        self.table.verticalHeader().setFixedWidth(25)
        self.table.verticalHeader().setDefaultSectionSize(26)
        
        self.delegate = S4RightAlignedDelegate(self.table)
        for i in range(2, 15): 
            self.table.setItemDelegateForColumn(i, self.delegate)

        self.setup_content()
        
        # 열 너비 설정
        self.table.setColumnWidth(0, 50)
        self.table.setColumnWidth(1, 60)
        for i in range(2, 14): self.table.setColumnWidth(i, 50)
        self.table.setColumnWidth(14, 70)

        self.table.itemChanged.connect(self.calculate_s4)
        layout.addWidget(self.table)

    def setup_content(self):
        self.table.blockSignals(True)
        ranks = ["1직급", "2직급", "3직급", "4직급", "5직급", "6직급", "...", "별도직군", "계"]
        months_headers = [f"{i}월" for i in range(1, 13)]
        full_headers = ["구분", "직급"] + months_headers + ["평균인원"]
        
        comment_text = (
            "hwp 16페이지: (3-2) 직급별 평균인원 계산을 위한 Template\n\n"
            "* 각 직급별 매월 인원은 해당 월말 현재의 인원을 집계함. 임금피크제 대상자 중 별도직군 전환 인력은\n"
            "  임금피크제 적용 전 직급(1,2급 등)에서 제외하여 별도직군에 기입하고, 그 외 인력은 종전직급에 포함하여 기입함.\n\n"
            "* 유연근무제 근로자의 경우 노동생산성의 평균인원 산정방식을 동일하게 적용함.\n\n"
            "* 각 직급별 평균인원은 1월부터 12월까지의 인원 총계를 12로 나누어서 구하되 소수점 이하 둘째 자리에서 반올림함."
        )

        for r in range(21):
            for c in range(15):
                if r in [9, 19]: # 구분선
                    item = QTableWidgetItem("")
                    item.setFlags(Qt.NoItemFlags)
                    item.setBackground(Qt.white)
                elif r == 10: # 당년도 제목줄
                    item = QTableWidgetItem(full_headers[c])
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setBackground(QColor(244, 244, 244))
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                elif r == 20: # 주석
                    item = QTableWidgetItem(comment_text if c == 0 else "")
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    item.setBackground(Qt.white)
                    item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                else:
                    item = S4ThousandSeparatorItem("0")
                    item.setTextAlignment(Qt.AlignCenter if c < 2 else Qt.AlignRight | Qt.AlignVCenter)
                    if c == 1 or r == 8 or r == 18 or c == 14:
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r in [8, 18] or c == 14:
                            font = item.font()
                            font.setBold(True)
                            item.setFont(font)
                    if c == 0:
                        item.setBackground(QColor(245, 245, 245))
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                        if r == 0: item.setText("전년도")
                        elif r == 11: item.setText("당년도")
                    if c == 1:
                        if 0 <= r <= 8: item.setText(ranks[r])
                        elif 11 <= r <= 18: item.setText(ranks[r-11])
                self.table.setItem(r, c, item)

        self.table.setSpan(20, 0, 1, 15)
        self.table.setSpan(0, 0, 9, 1)   
        self.table.setSpan(11, 0, 8, 1)  
        
        # [최종 높이 조절]
        self.table.setRowHeight(9, 12)   # 구분선
        self.table.setRowHeight(19, 12)  # 구분선
        self.table.setRowHeight(10, 26)  # 당년도 제목 (S3 데이터행과 통일)
        self.table.setRowHeight(20, 150) # 주석 칸
        
        self.table.setWordWrap(True)
        self.table.blockSignals(False)
        
        

        
    def calculate_s4(self, item):
        row, col = item.row(), item.column()
        # 입력 가능한 데이터 영역이 아니면 무시 (제목줄, 구분선, 합계행, 평균열 제외)
        if col < 2 or col == 14 or row in [8, 9, 10, 18, 19, 20]: return 
        
        self.table.blockSignals(True)
        try:
            # [1] 범위 설정
            if 0 <= row <= 7:  # 전년도 데이터 영역 (1~8행)
                is_prev = True
                start_r = 0
                sum_r = 8
            elif 11 <= row <= 17:  # 당년도 데이터 영역 (12~18행)
                is_prev = False
                start_r = 11   # index 11 (12행)부터 데이터 시작
                sum_r = 18    # index 18 (19행)이 합계행
            else:
                return

            # [2] 가로 평균 계산 (해당 행의 1~12월 평균)
            row_sum = 0
            for c in range(2, 14):
                val_str = self.table.item(row, c).text().replace(',', '').strip()
                row_sum += float(val_str or 0)
            
            avg_val = round(row_sum / 12, 2)
            self.table.item(row, 14).setText(str(avg_val))

            # [3] 세로 합계 계산 (해당 월의 전 직급 합계)
            col_sum = 0
            for r in range(start_r, sum_r):
                val_str = self.table.item(r, col).text().replace(',', '').strip()
                col_sum += float(val_str or 0)
            
            self.table.item(sum_r, col).setText(str(int(col_sum)))

            # [4] 우측 하단 최종 평균인원 합계
            total_avg = 0
            for r in range(start_r, sum_r):
                val_str = self.table.item(r, 14).text().replace(',', '').strip()
                total_avg += float(val_str or 0)
            
            self.table.item(sum_r, 14).setText(str(round(total_avg, 2)))

        except Exception as e:
            print(f"계산 오류: {e}")
        finally:
            self.table.blockSignals(False)

    def show_context_menu(self, pos):
        menu = QMenu()
        copy_action = menu.addAction("복사 (Ctrl+C)")
        paste_action = menu.addAction("붙여넣기 (Ctrl+V)")
        
        # 마우스 위치에 메뉴 띄우기
        action = menu.exec_(self.table.viewport().mapToGlobal(pos))
        
        if action == copy_action:
            self.copy_selection()
        elif action == paste_action:
            self.paste_selection()

    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r = min(r.topRow() for r in selection)
        max_r = max(r.bottomRow() for r in selection)
        min_c = min(r.leftColumn() for r in selection)
        max_c = max(r.rightColumn() for r in selection)
        
        lines = []
        # 제목줄 포함 복사 (선택 범위에 상단 제목이 포함될 경우)
        if min_r == 0:
            headers = [self.table.horizontalHeaderItem(c).text().replace('\n', ' ') for c in range(min_c, max_c + 1)]
            lines.append("\t".join(headers))

        for r in range(min_r, max_r + 1):
            # [수정] 10행(index 9)과 20행(index 19)도 빈 줄로 포함하여 복사
            if r in [9, 19]:
                # 해당 범위만큼 빈 탭(\t)을 추가하여 엑셀에서 빈 줄로 인식하게 함
                empty_line = [""] * (max_c - min_c + 1)
                lines.append("\t".join(empty_line))
                continue

            row_data = []
            # 엑셀 수식용 상대 좌표 (전년도는 2행부터, 당년도는 13행부터 시작 가정)
            ex_row = (r + 2) if r <= 8 else (r + 1) # 행 번호에 맞춰 조정

            for c in range(min_c, max_c + 1):
                col_L = chr(ord('A') + c)
                # 수식 복사 로직 (평균 및 계)
                if c == 14 and r not in [8, 10, 18, 20]: # 일반 데이터 행 평균
                    val = f"=AVERAGE(C{ex_row}:N{ex_row})"
                elif (r == 8 or r == 18) and c >= 2: # 계 행 합계
                    val = f"=SUM({col_L}{ex_row-8}:{col_L}{ex_row-1})"
                else:
                    it = self.table.item(r, c)
                    # 콤마 제거하고 순수 텍스트만 추출
                    val = it.text().replace(',', '').strip() if it else ""
                row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))

        

    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        self.table.blockSignals(True)
        for i, line in enumerate(text.splitlines()):
            for j, val in enumerate(line.split('\t')):
                r, c = curr.row() + i, curr.column() + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    item = self.table.item(r, c)
                    # 수정 가능 여부 확인 (주석칸, 계, 평균열 등 제외)
                    if item and (item.flags() & Qt.ItemIsEditable):
                        item.setText(val.strip())
        self.table.blockSignals(False)
        self.calculate_s4(curr)

    # 키보드 단축키 지원
    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Copy):
            self.copy_selection()
        elif event.matches(QKeySequence.Paste):
            self.paste_selection()
        else:
            super().keyPressEvent(event)
