import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from s2 import Sheet2Page
from s3 import Sheet3Page
from s4 import Sheet4Page
from s5 import Sheet5Page
from s6 import Sheet6Page
from s7 import Sheet7Page
from s8 import Sheet8Page
from s9 import Sheet9Page
from s10 import Sheet10Page
from s11 import Sheet11Page
from s12 import Sheet12Page
from s13 import Sheet13Page
from s14 import Sheet14Page
from s15 import Sheet15Page
from s16 import Sheet16Page
from s17 import Sheet17Page
from s18 import Sheet18Page




class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4개 공통지표 점수로 인건비 집계")        
        self.setGeometry(150, 150, 1100, 850)
        self.setStyleSheet("background-color: white;") 
        
        widget = QWidget()
        self.setCentralWidget(widget)
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(10, 5, 10, 5)

        # 1. 상단 버튼바 (간격 최소화: spacing=2)
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(2) # 버튼 사이 간격을 2픽셀로 고정
        
        btn_style = """
            QPushButton {
                border: 1px solid #dcdcdc;
                border-radius: 2px;
                padding: 3px 8px;
                background-color: #f9f9f9;
            }
            QPushButton:hover { background-color: #f0f0f0; }
        """
        
        # 버튼명 수정: "다른 이름으로 저장"
        for btn_name in ["열기", "저장", "다른 이름으로 저장", "초기화"]:
            btn = QPushButton(btn_name)
            btn.setStyleSheet(btn_style)
            btn.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
            nav_layout.addWidget(btn)

        nav_layout.addStretch(1)

        # 엑셀 버튼
        btn_excel = QPushButton("Excel 내보내기")
        btn_excel.setStyleSheet("""
            QPushButton {
                background-color: #217346; color: white; border-radius: 2px;
                padding: 3px 12px; font-weight: bold;
            }
            QPushButton:hover { background-color: #1a5a37; }
        """)
        nav_layout.addWidget(btn_excel)
        layout.addLayout(nav_layout)

        # 2. 하단 시트 탭
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.South)

        self.tabs.setStyleSheet("""
    QTabWidget::pane { 
        border: 1px solid #f2f2f2; /* 본문 테두리와 만나는 선을 아주 연하게 */
    }
    QTabBar::tab {
        background: #f8f8f8; 
        border: 1px solid #dcdcdc;
        padding: 6px 20px; 
        margin-right: 2px;
        color: #666;
    }
    QTabBar::tab:selected { 
        background: white; 
        border-bottom: 2px solid white; /* 선택된 탭이 본문과 연결된 느낌 */
        font-weight: bold;
        color: #000;
    }
""")
        # 각 번호에 맞는 시트 클래스를 연결
        for i in range(1, 19):
            if i == 2:
                page = Sheet2Page()
            elif i == 3:
                page = Sheet3Page()
            elif i == 4:
                page = Sheet4Page()
            elif i == 5:
                page = Sheet5Page()                
            elif i == 6:
                page = Sheet6Page()                
            elif i == 7:
                page = Sheet7Page()
            elif i == 8:
                page = Sheet8Page()
            elif i == 9:
                page = Sheet9Page()
            elif i == 10:
                page = Sheet10Page()                  
            elif i == 11:
                page = Sheet11Page()
            elif i == 12:
                page = Sheet12Page()                
            elif i == 13:
                page = Sheet13Page()           
            elif i == 14:
                page = Sheet14Page()                                            
            elif i == 15:
                page = Sheet15Page()
            elif i == 16:
                page = Sheet16Page()
            elif i == 17:
                page = Sheet17Page()
            elif i == 18:
                page = Sheet18Page()                  
            else:
                page = QWidget() # 나머지는 아직 빈 페이지
                
            self.tabs.addTab(page, f"Sheet{i}")

        self.tabs.setCurrentIndex(1)
        layout.addWidget(self.tabs)

















if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setFont(QFont("맑은 고딕", 9))
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
