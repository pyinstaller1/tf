from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QRect
from PyQt5.QtGui import QColor, QFont, QCursor, QPen

# [1] 기호 드로잉 델리게이트: ①, (Ⅰ), (Ⅱ), (Ⅲ) 표시
class SymbolDelegate(QStyledItemDelegate):
    def __init__(self, year, parent=None):
        super().__init__(parent)
        self.year = year
    
    def paint(self, painter, option, index):
        # 기존 정렬 및 기본 그리기 유지
        option.displayAlignment = Qt.AlignRight | Qt.AlignVCenter
        super().paint(painter, option, index)
        
        painter.save()
        painter.setPen(QPen(QColor(60, 60, 60)))
        font = painter.font()
        font.setBold(False)
        painter.setFont(font)
        
        row = index.row()
        col = index.column()



        if self.year == '2025':
            if row == 30 and col == 3:
                painter.drawText(option.rect.adjusted(1, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(갑)")
            if row == 31 and col == 3:
                painter.drawText(option.rect.adjusted(1, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(갑)")
            if row == 32 and col == 3:
                painter.drawText(option.rect.adjusted(1, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(을)")

            if row == 29 and col == 2:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "①")
            if row == 29 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "②")
            if row == 29 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "③")
            if row == 30 and col == 3:
                painter.drawText(option.rect.adjusted(20, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "④")
            if row == 30 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑤")


            if row == 31 and col == 3:
                painter.drawText(option.rect.adjusted(20, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑥")
            if row == 31 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑦")
            if row == 32 and col == 3:
                painter.drawText(option.rect.adjusted(20, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑧")
            if row == 32 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑨")
            if row == 33 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑩")
            if row == 33 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑪")           

            if row == 34 and col == 2:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑫")

            if row == 35 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑬")
            if row == 35 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑭")
            if row == 36 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑮")
            if row == 36 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑯") 


                
            if row == 37 and col == 2:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑰")
            elif row == 38 and col == 2:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅰ)")
            elif row == 38 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅱ)")
            elif row == 40 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅱ)")
            elif row == 41 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅲ)")


            # B열(col 1)의 43, 44행 우측에 수식을 그림으로 그립니다.
            if col == 1:
                # 글자 크기를 살짝 줄여서 수식 느낌을 냅니다.
                font.setPointSize(font.pointSize() - 1)
                painter.setFont(font)
                
                if row == 43:
                    # 셀 오른쪽 끝에서 5픽셀 띄우고 수식 그리기
                    painter.drawText(option.rect.adjusted(0, 0, -5, 0), Qt.AlignRight | Qt.AlignVCenter, "[(Ⅰ)-(Ⅱ)]/(Ⅱ)")
                elif row == 44:
                    # 셀 오른쪽 끝에서 5픽셀 띄우고 수식 그리기
                    painter.drawText(option.rect.adjusted(0, 0, -5, 0), Qt.AlignRight | Qt.AlignVCenter, "[(Ⅰ)-(Ⅲ)]/(Ⅲ)")




        if self.year == '2024':

            '''
            if row == 31 and col == 3:
                painter.drawText(option.rect.adjusted(1, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(갑)")
            if row == 33 and col == 3:
                painter.drawText(option.rect.adjusted(1, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(을)")
            '''

            if row == 30 and col == 2:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "①")
            if row == 30 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "②")
            if row == 30 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "③")
            if row == 31 and col == 3:
                painter.drawText(option.rect.adjusted(20, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "④")
            if row == 31 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑤")


            if row == 32 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑥")
            if row == 32 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑦")
            if row == 33 and col == 3:
                painter.drawText(option.rect.adjusted(20, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑧")
            if row == 33 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑨")
            if row == 34 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑩")
            if row == 34 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑪")           

            if row == 35 and col == 2:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑫")

            if row == 36 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑬")
            if row == 36 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑭")
            if row == 37 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑮")
            if row == 37 and col == 4:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑯") 


                
            if row == 38 and col == 2:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑰")
            elif row == 39 and col == 2:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅰ)")
            elif row == 39 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅱ)")
            elif row == 41 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅱ)")
            elif row == 42 and col == 3:
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅲ)")


            if col == 1:
                # 글자 크기를 살짝 줄여서 수식 느낌을 냅니다.
                font.setPointSize(font.pointSize() - 1)
                painter.setFont(font)
                
                if row == 44:
                    # 셀 오른쪽 끝에서 5픽셀 띄우고 수식 그리기
                    painter.drawText(option.rect.adjusted(0, 0, -5, 0), Qt.AlignRight | Qt.AlignVCenter, "[(Ⅰ)-(Ⅱ)]/(Ⅱ)")
                elif row == 55:
                    # 셀 오른쪽 끝에서 5픽셀 띄우고 수식 그리기
                    painter.drawText(option.rect.adjusted(0, 0, -5, 0), Qt.AlignRight | Qt.AlignVCenter, "[(Ⅰ)-(Ⅲ)]/(Ⅲ)")


        if self.year == '2023':
            # 1. (갑), (을) 위치 (2024년 대비 3행 위로)
            if row == 28 and col == 3: # 2024년 31행 -> 2023년 28행
                painter.drawText(option.rect.adjusted(1, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(갑)")
            if row == 30 and col == 3: # 2024년 33행 -> 2023년 30행
                painter.drawText(option.rect.adjusted(1, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(을)")

            # 2. 원문자 기호 ① ~ ⑪ (발생액/소계 라인: 2024년 30행 -> 2023년 27행부터 시작)
            if row == 27 and col == 2: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "①")
            if row == 27 and col == 3: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "②")
            if row == 27 and col == 4: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "③")
            
            if row == 28 and col == 3: painter.drawText(option.rect.adjusted(20, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "④")
            if row == 28 and col == 4: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑤")

            if row == 29 and col == 3: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑥")
            if row == 29 and col == 4: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑦")
            
            if row == 30 and col == 3: painter.drawText(option.rect.adjusted(20, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑧")
            if row == 30 and col == 4: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑨")
            
            if row == 31 and col == 3: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑩")
            if row == 31 and col == 4: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑪")

            # 3. 원문자 기호 ⑫ ~ ⑰ (조정 항목 라인: 2024년 35행 -> 2023년 32행부터 시작)
            if row == 32 and col == 2: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑫")
            if row == 33 and col == 3: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑬")
            if row == 33 and col == 4: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑭")
            if row == 34 and col == 3: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑮")
            if row == 34 and col == 4: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑯")
            if row == 35 and col == 2: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "⑰")

            # 4. 로마자 및 최종 지표 (2024년 39행 -> 2023년 36행)
            if row == 36 and col == 2: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅰ)")
            elif row == 36 and col == 3: painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅱ)")
            elif row == 38 and col == 3: # 2024년 41행 -> 2023년 38행
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅱ)")
            elif row == 39 and col == 3: # 2024년 42행 -> 2023년 39행
                painter.drawText(option.rect.adjusted(5, 0, 0, 0), Qt.AlignLeft | Qt.AlignVCenter, "(Ⅲ)")

            # 5. 수식 텍스트 (B열: 2024년 44행 -> 2023년 41행)
            if col == 1:
                font.setPointSize(font.pointSize() - 1)
                painter.setFont(font)
                if row == 41:
                    painter.drawText(option.rect.adjusted(0, 0, -5, 0), Qt.AlignRight | Qt.AlignVCenter, "[(Ⅰ)-(Ⅱ)]/(Ⅱ)")
                elif row == 42: # 2024년 45행 -> 2023년 42행
                    painter.drawText(option.rect.adjusted(0, 0, -5, 0), Qt.AlignRight | Qt.AlignVCenter, "[(Ⅰ)-(Ⅲ)]/(Ⅲ)")


                    
        painter.restore()

    def createEditor(self, parent, option, index):

        if self.year == '2025':        
            if index.row() == 37 and index.column() in [3, 4]:
                return None
            # 계산 결과 및 상한액 셀 입력 방지
            if index.row() in [38, 40, 41, 43, 44] and index.column() >= 2:
                return None
            
        if self.year == '2024':        
            if index.row() == 38 and index.column() in [3, 4]:
                return None
            # 계산 결과 및 상한액 셀 입력 방지
            if index.row() in [39, 41, 42, 44, 45] and index.column() >= 2:
                return None

        if self.year == '2023':
            # 1. 특정 소계 셀 입력 방지 (2024년 38행 -> 2023년 35행)
            if index.row() == 35 and index.column() in [3, 4]:
                return None
            
            # 2. 계산 결과 및 최종 지표 셀 입력 방지
            if index.row() in [36, 38, 39, 41, 42] and index.column() >= 2:
                return None




        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        return editor

class ThousandSeparatorItem(QTableWidgetItem):

    def __init__(self, text, year): # year 추가
        super().__init__(text)
        self.year = year


    
    def data(self, role):

        if role == Qt.ForegroundRole:
            val = super().data(Qt.EditRole)
            try:
                if val is not None and float(str(val).replace(',', '')) < 0:
                    return QColor(Qt.red)
            except:
                pass
            return super().data(role) # 음수가 아니면 기본 색상

        
        if role == Qt.DisplayRole:
            val = super().data(Qt.EditRole)

            if val is None or val == "" or val == "n/a":
                return val

            try:
                table = self.tableWidget()
                index = table.indexFromItem(self) if table else None
                row = index.row() if index else -1
                col = index.column() if index else -1


                if self.year == '2025':        

                    # 🔹 44행 3열은 항상 빈칸
                    if row == 44 and col == 3:
                        return ""

                    num = float(val)

                    # 🔥 인상률 행 (43, 44)
                    if row in (43, 44):
                        if num == 0:
                            return "0.0"
                        return f"{round(num, 5)}"



                if self.year == '2024':        
                    if row == 45 and col == 3:
                        return ""

                    num = float(val)

                    if row in (44, 45):
                        if num == 0:
                            return "0.0"
                        return f"{round(num, 5)}"

                if self.year == '2023':        
                    if row == 42 and col == 3:
                        return ""

                    num = float(val)

                    if row in (41, 42):
                        if num == 0:
                            return "0.0"
                        return f"{round(num, 5)}"


                # 🔥 나머지: 정수 + 천단위 콤마
                return format(int(num), ",")

            except Exception:
                return val

        return super().data(role)





    


class RightAlignedDelegate(QStyledItemDelegate):
    def __init__(self, year, parent):
        super().__init__(parent)
        self.year = year # 내부에 저장
        if parent:
            parent.installEventFilter(self)



    def createEditor(self, parent, option, index):


        if self.year == '2025':
            # [기존 유지] 특정 셀 편집 방지 로직 (37행 3, 4열)
            if index.row() == 37 and index.column() in [3, 4]: 
                return None


        if self.year == '2024':
            # [기존 유지] 특정 셀 편집 방지 로직 (37행 3, 4열)
            if index.row() == 38 and index.column() in [3, 4]: 
                return None

        if self.year == '2023':
            # 2024년의 38행에 대응하는 2023년의 행은 35행입니다.
            if index.row() == 35 and index.column() in [3, 4]: 
                return None
            
        editor = QLineEdit(parent)
        editor.setAlignment(Qt.AlignRight)
        
        # 실시간 콤마 포맷팅 연결
        editor.textChanged.connect(lambda text: self.format_text(editor, text))
        
        # 입력 중(에디터 활성화)일 때 키 감시용 설치
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if event.type() == event.KeyPress:
            # 1. 엔터 키: 아래 셀로 이동 (단순 선택, 데이터 저장 보장)
            if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
                table = self.parent()
                curr = table.currentIndex()
                next_row = curr.row() + 1
                if next_row < table.rowCount():
                    # setCurrentIndex를 호출해야 작성 중인 데이터가 반영됩니다.
                    next_idx = table.model().index(next_row, curr.column())
                    table.setCurrentIndex(next_idx)
                return True

            # 2. 오른쪽 방향키
            elif event.key() == Qt.Key_Right:
                # 입력창이 아니거나(테이블), 커서가 끝일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == len(obj.text()):
                    self.move_focus(forward=True)
                    return True

            # 3. 왼쪽 방향키
            elif event.key() == Qt.Key_Left:
                # 입력창이 아니거나(테이블), 커서가 앞일 때 이동
                if not isinstance(obj, QLineEdit) or obj.cursorPosition() == 0:
                    self.move_focus(forward=False)
                    return True

        return super().eventFilter(obj, event)

    def move_focus(self, forward=True):
        """좌우 이동 시 인덱스만 변경 (자동 편집 제거)"""
        table = self.parent()
        curr_idx = table.currentIndex()
        next_col = curr_idx.column() + 1 if forward else curr_idx.column() - 1
        
        if 0 <= next_col < table.columnCount():
            next_idx = table.model().index(curr_idx.row(), next_col)
            table.setCurrentIndex(next_idx)

    def format_text(self, editor, text):
        clean = text.replace(',', '')
        if not clean or clean == "-": return
        try:
            formatted = format(int(float(clean)), ",")
            if text != formatted:
                pos = editor.cursorPosition()
                old_len = len(text)
                editor.blockSignals(True)
                editor.setText(formatted)
                editor.setCursorPosition(pos + (len(formatted) - old_len))
                editor.blockSignals(False)
        except: pass

    def setModelData(self, editor, model, index):
        # 콤마 제거 후 숫자 데이터 저장
        raw_text = editor.text().replace(',', '')
        model.setData(index, raw_text, Qt.EditRole)


        

class Sheet2Page(QWidget):
    def __init__(self, company, year, list_years2, list_years3, check_3_5, check_3_6, check_4, parent=None):
        super().__init__(parent)
        self.base_sky_blue = QColor(220, 235, 245)
        self.target_light_blue = QColor(238, 238, 255)
        self.very_light_gray = QColor(252, 252, 252)

        self.company = company
        self.year = year
        self.list_years2 = list_years2
        self.list_years3 = list_years3
        self.check_3_5 = check_3_5
        self.check_3_6 = check_3_6
        self.check_4 = check_4

        self.initUI()

    def initUI(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)


        title = QLabel("(3) 총인건비 인상률 지표의 점수계산")
        title.setFont(QFont("Malgun Gothic", 12, QFont.Bold))
        layout.addWidget(title)



        if self.year == '2025': self.table = QTableWidget(55, 5)
        if self.year == '2024': self.table = QTableWidget(56, 5)
        if self.year == '2023': self.table = QTableWidget(53, 5)

        

        list_label = ["구분", "항목명"]
        years = list(self.list_years3)

        # 3개가 될 때까지 부족한 연도 채우기
        while len(years) < 3:
            if not years:
                import datetime
                years.append(str(datetime.datetime.now().year))
            else:
                last_year = int(years[-1])
                years.append(str(last_year - 1))

        list_label.extend(years)

        self.table.setHorizontalHeaderLabels(list_label)

        # self.table.setHorizontalHeaderLabels(["구분", "항목명", "2025", "2024", "2023"])
        
        self.right_delegate = RightAlignedDelegate(self.year, self.table)
        
        for i in range(2, 5): 
            self.table.setItemDelegateForColumn(i, self.right_delegate)

        self.symbol_delegate = SymbolDelegate(self.year, self.table)
        # 델리게이트 적용 (기호가 그려질 행들)


        if self.year == '2025':    
            for r in [37, 38, 40, 41, 29, 30, 31, 32, 33, 34, 35, 36]:
                self.table.setItemDelegateForRow(r, self.symbol_delegate)

        if self.year == '2024':    
            for r in [38, 39, 41, 42, 30, 31, 32, 33, 34, 35, 36, 37]:
                self.table.setItemDelegateForRow(r, self.symbol_delegate)

        if self.year == '2023':    
            for r in [35, 36, 38, 39, 27, 28, 29, 30, 31, 32, 33, 34]:
                self.table.setItemDelegateForRow(r, self.symbol_delegate)






        self.table.setItemDelegateForColumn(1, self.symbol_delegate) 

        self.table.setShowGrid(True)
        self.table.setGridStyle(Qt.SolidLine)


        self.table.verticalHeader().setFixedWidth(25)


        self.table.setStyleSheet("""
            QTableWidget { 
                gridline-color: #d0d0d0; 
                border: 1px solid #d0d0d0; 
            }
            QHeaderView::section {
                background-color: #f4f4f4; 
                padding: 4px;
                border: 0px; 
                border-right: 1px solid #d0d0d0;
                border-bottom: 1px solid #d0d0d0;
                font-weight: bold;
            }
            QScrollBar:vertical {
                background: #f1f1f1;
                width: 16px;
                margin: 0px 0px 0px 0px;
                border: 1px solid #dcdcdc;
            }
            QScrollBar::handle:vertical {
                background: #888888;
                min-height: 30px;
                border-radius: 2px;
            }
            QScrollBar::handle:vertical:hover {
                background: #555555;
            }
            QScrollBar:horizontal {
                background: #f1f1f1;
                height: 16px;
                margin: 0px 0px 0px 0px;
                border: 1px solid #dcdcdc;
            }
            QScrollBar::handle:horizontal {
                background: #888888;
                min-width: 30px;
                border-radius: 2px;
            }
            QScrollBar::handle:horizontal:hover {
                background: #555555;
            }
            QScrollBar::add-line, QScrollBar::sub-line {
                width: 0px;
                height: 0px;
            }
            QHeaderView::section:vertical {
                background-color: #f4f4f4; border: 0px; 
                border-right: 1px solid #d0d0d0; border-bottom: 1px solid #d0d0d0;
                font-weight: normal; /* 번호열 글자 굵게 하지 않음 */
            }  
        """)



        title_font = QFont("맑은 고딕", 9)
        title_font.setBold(True)
        
        for c in range(self.table.columnCount()):
            item = self.table.horizontalHeaderItem(c)
            if item:
                item.setFont(title_font) # 헤더 텍스트 굵게

        
        self.table.verticalHeader().setDefaultSectionSize(26)
        self.table.setColumnWidth(0, 70)  
        self.table.setColumnWidth(1, 460)
        for i in range(2, 5): self.table.setColumnWidth(i, 128)   # 115

        self.setup_content()
        
        self.table.itemChanged.connect(self.calculate_s2)
        layout.addWidget(self.table)










    def setup_content(self):
        self.table.blockSignals(True)


        if self.year == '2025':
            # 1. 테이블 초기화 및 기본 정렬/배경 세팅
            for r in range(self.table.rowCount()):
                for c in range(5):
                    item = ThousandSeparatorItem("", self.year) if c >= 2 else QTableWidgetItem("")
                    self.table.setItem(r, c, item)
                    if (r in [1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 13, 14] and c == 2) or (r in [30, 31, 32] and c==3):
                        item.setBackground(QColor(255, 255, 225)) # 연한 노란색
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) 
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)            
                    if r == 45:
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)                
                    if c == 0: item.setTextAlignment(Qt.AlignCenter)
                    elif c == 1: 
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                        item.setBackground(self.very_light_gray)
                    else: 
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                        item.setText("0")

            self.table.item(43, 2).setData(Qt.EditRole, 0.0)
            self.table.item(44, 2).setData(Qt.EditRole, 0.0)
            self.table.item(43, 3).setText("")

            fixed_item = self.table.item(43, 3)
            fixed_item.setText("2.469%")
            fixed_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)


            # 2. A열 병합 및 대분류 텍스트
            self.table.setSpan(0, 0, 30, 1) 
            self.table.item(0, 0).setText("실집행액 기준 총인건비 발생액 산출")
            self.table.setSpan(30, 0, 9, 1)
            self.table.item(30, 0).setText("전년대비 조정된 총인건비 발생액 산출")
            self.table.setSpan(39, 0, 6, 1)
            self.table.item(39, 0).setText("당해연도 총인건비 인상률 계산")

            for r in [0, 30, 39]:
                it = self.table.item(r, 0)
                if it:
                    it.setBackground(self.base_sky_blue)
                    it.setFont(QFont("맑은 고딕", 8, QFont.Bold))



        if self.year == '2024':
            # 1. 테이블 초기화 및 기본 정렬/배경 세팅
            for r in range(self.table.rowCount()):
                for c in range(5):
                    item = ThousandSeparatorItem("", self.year) if c >= 2 else QTableWidgetItem("")
                    self.table.setItem(r, c, item)
                    if (r in [1, 2, 3, 4, 5, 8, 9, 10, 12, 13, 14, 15] and c == 2):
                        item.setBackground(QColor(255, 255, 225)) # 연한 노란색
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) 
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)            
                    if r == 46:
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)                
                    if c == 0: item.setTextAlignment(Qt.AlignCenter)
                    elif c == 1: 
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                        item.setBackground(self.very_light_gray)
                    else: 
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                        item.setText("0")

            self.table.item(44, 2).setData(Qt.EditRole, 0.0)
            self.table.item(45, 2).setData(Qt.EditRole, 0.0)
            self.table.item(44, 3).setText("")

            fixed_item = self.table.item(44, 3)
            # fixed_item.setText("2.469%")
            fixed_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)


            # 2. A열 병합 및 대분류 텍스트
            self.table.setSpan(0, 0, 30, 1) 
            self.table.item(0, 0).setText("실집행액 기준 총인건비 발생액 산출")
            self.table.setSpan(31, 0, 9, 1)
            self.table.item(31, 0).setText("전년대비 조정된 총인건비 발생액 산출")
            self.table.setSpan(40, 0, 6, 1)
            self.table.item(40, 0).setText("당해연도 총인건비 인상률 계산")

            for r in [0, 31, 40]:
                it = self.table.item(r, 0)
                if it:
                    it.setBackground(self.base_sky_blue)
                    it.setFont(QFont("맑은 고딕", 8, QFont.Bold))


        if self.year == '2023':
            # 1. 테이블 초기화 및 기본 정렬/배경 세팅
            for r in range(self.table.rowCount()):
                for c in range(5):
                    item = ThousandSeparatorItem("", self.year) if c >= 2 else QTableWidgetItem("")
                    self.table.setItem(r, c, item)
                    # [기존 유지] 배경색 및 플래그 세팅 (행 번호 변경 없음 - 상단 공통 영역)
                    if (r in [1, 2, 3, 4, 5, 8, 9, 10, 12, 13, 14, 15] and c == 2):
                        item.setBackground(QColor(255, 255, 225)) # 연한 노란색
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) 
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)            
                    
                    # [변경] 하단 고정 행 플래그 (2024년 46행 -> 2023년 43행)
                    if r == 43:
                        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)                
                    
                    if c == 0: item.setTextAlignment(Qt.AlignCenter)
                    elif c == 1: 
                        item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                        item.setBackground(self.very_light_gray)
                    else: 
                        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                        item.setText("0")

            # [변경] 인상률 결과 셀 초기화 (2024년 44, 45행 -> 2023년 41, 42행)
            self.table.item(41, 2).setData(Qt.EditRole, 0.0)
            self.table.item(42, 2).setData(Qt.EditRole, 0.0)
            self.table.item(41, 3).setText("")

            fixed_item = self.table.item(41, 3)
            fixed_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)


            # 2. A열 병합 및 대분류 텍스트 (항목 감소에 따른 Span 조정)
            # [변경] 첫 번째 섹션: 2024년 30행 -> 2023년 27행까지 (30-3)
            self.table.setSpan(0, 0, 27, 1) 
            self.table.item(0, 0).setText("실집행액 기준 총인건비 발생액 산출")
            
            # [변경] 두 번째 섹션: 2024년 31행 시작, 9개행 -> 2023년 28행 시작, 9개행
            self.table.setSpan(28, 0, 9, 1)
            self.table.item(28, 0).setText("전년대비 조정된 총인건비 발생액 산출")
            
            # [변경] 세 번째 섹션: 2024년 40행 시작, 6개행 -> 2023년 37행 시작, 6개행
            self.table.setSpan(37, 0, 6, 1)
            self.table.item(37, 0).setText("당해연도 총인건비 인상률 계산")

            # [변경] 배경색 적용 행 리스트 (0, 31, 40 -> 0, 28, 37)
            for r in [0, 28, 37]:
                it = self.table.item(r, 0)
                if it:
                    it.setBackground(self.base_sky_blue)
                    it.setFont(QFont("맑은 고딕", 8, QFont.Bold))






        if self.year == '2025':
            # 3. B열 항목명 정의
            b_dict = {
                0: "1. 인센티브 상여금을 제외한 인건비 총액",
                1: "  a. 판관비로 처리한 인건비 <주1>",
                2: "  b. 영업외비용으로 처리한 인건비 <주2>",
                3: "  c. 제조원가로 처리한 인건비 <주3>",
                4: "  d. 타계정대체로 처리한 인건비 <주4>",
                5: "  e. 이익잉여금의 증감으로 처리한 인건비 <주5>",
                6: "▶ 소계 : (A)=a+b+c+d+e",
                7: "2. 총인건비 인상률 계산에서 제외(조정)되는 인건비",
                8: "  f. 퇴직급여(명예퇴직금 포함) <주6>",
                9: "  g. 임원 인건비<주7>",
                10: "  h. 비상임이사 인건비<주8>",
                11: "  i. 인상률 제외 인건비<주9>",
                12: "  j. 사내근로복지기금출연금<주10>",
                13: "  k. 잡급 및 무기계약직 인건비 <주11>",
                14: "  l. 공적보험 사용자부담분<주12>",
                15: "  m. 연월차수당 등 조정(㉠-㉡+㉢)<주13>",
                16: "    - 연월차수당 등 발생액(㉠)",
                17: "    - 연월차수당 등 지급액(㉡)",
                18: "    - 종업원 저리 대여금 이자 관련 인건비(㉢)",
                19: "  n. 저리·무상대여 이익<주14>",
                20: "  o. 지방이전 관련 직접 인건비<주15>",
                21: "  p. 법령에 따른 특수건강진단비<주16>",
                22: "  q. 해외근무수당<주17>",
                23: "  r. 직무발명보상금<주18>",
                24: "  s. 자녀수당 및 출산축하금<주19>",
                25: "  t. 야간간호특별수당<주20>",
                26: "  u. 비상진료체계 운영에 따른 특별수당 등<주21>",
                27: "  v. 통상임금 판례 영향 법정수당 증가분 <주22>",
                28: "▶ 소계 : (B)=f+g+h+i+j+k+l+m-n+o+p+q+r+s+t+u+v",
                29: "3. 실집행액기준 총인건비 발생액 (C)=(A)-(B)",
                30: "4. 연도별 증원소요 인건비의 영향을 제거하기 위한 인건비의 조정(D) <주23>",
                31: "5. 별도직군 승진시기 차이에 따른 인건비 효과 조정(E) <주24>",
                32: "6. 초임직급 정원 변동에 따른 인건비 효과 조정(F) <주25>",
                33: "7. 정년이후 재고용을 전제로 전환된 정원외인력의 인건비 효과 조정(G) <주26>",
                34: "8. 생산량증가로 인하여 ’25년도’에 추가로 지급된 인건비의 영향 제거(H) <주27>",
                35: "9. 최저임금 지급 직원에 대한 인건비 효과 조정(I) <주28>",
                36: "10. 파업 등에 따른 인건비 효과 조정(J) <주29>",
                37: "11. 통상임금 판단기준 변경 판례의 영향으로 인한 법정수당 증가분(2025년 귀속분) (K) <주30>",
                38: "12. 총인건비 인상률 계산대상 총인건비 발생액\n  = (C)+(D)+(E)-(F)-(G)-(H)+(I)+(J)-(K) <주31>",
                39: "13. 총인건비 인상률 가이드라인에 따른 총인건비 상한액 <주32>",
                40: "  (1) ’24년도 총인건비 인상률 가이드라인을 준수한 경우",
                41: "  (2) ’24년도 총인건비 인상률 가이드라인을 준수하지 않은 경우",
                42: "14. 총인건비 인상률 산출(’25년도 총인건비 인상률 가이드라인 = 3.0%) <주33>",
                43: "  (1) ’24년도 총인건비 인상률 가이드라인을 준수한 경우",
                44: "  (2) ’24년도 총인건비 인상률 가이드라인을 준수하지 않은 경우"
            }


        if self.year == '2024':
            # 3. B열 항목명 정의
            b_dict = {
                0: "1. 인센티브 상여금을 제외한 인건비 총액",
                1: "  a. 판관비로 처리한 인건비 <주1>",
                2: "  b. 영업외비용으로 처리한 인건비 <주2>",
                3: "  c. 제조원가로 처리한 인건비 <주3>",
                4: "  d. 타계정대체로 처리한 인건비 <주4>",
                5: "  e. 이익잉여금의 증감으로 처리한 인건비 <주5>",
                6: "▶ 소계 : (A)=a+b+c+d+e",
                7: "2. 총인건비 인상률 계산에서 제외(조정)되는 인건비",
                8: "  f. 퇴직급여(명예퇴직금 포함) <주6>",
                9: "  g. 임원 인건비<주7>",
                10: "  h. 비상임이사 인건비<주8>",
                
                11: "  i. 인상률 제외 인건비 (통상)",
                12: "  i. 인상률 제외 인건비 (기타)",

                13: "  j. 사내근로복지기금출연금<주10>",
                14: "  k. 잡급 및 무기계약직 인건비 <주11>",
                15: "  l. 공적보험 사용자부담분<주12>",
                16: "  m. 연월차수당 등 조정(㉠-㉡+㉢)<주13>",
                17: "    - 연월차수당 등 발생액(㉠)",
                18: "    - 연월차수당 등 지급액(㉡)",
                19: "    - 종업원 저리 대여금 이자 관련 인건비(㉢)",
                20: "  n. 저리·무상대여 이익<주14>",
                21: "  o. 지방이전 관련 직접 인건비<주15>",
                22: "  p. 법령에 따른 특수건강진단비<주16>",


                23: "  q. 코로나19 대응을 위한 시간외근로수당 등",
                24: "  r. 해외근무수당",
                25: "  s. 직무발명보상금",
                26: "  t. 공무원 수준 내 지급되는 자녀수당 및 출산축하금",
                27: "  u. 야간간호특별수당",
                28: "  v. 비상진료체계 운영에 따른 특별수당 등",
                29: "▶ 소계 : (B)=f+g+h+i+j+k+l+m-n+o+p+q+r+s+t+u+v",

                
                30: "3. 실집행액기준 총인건비 발생액 (C)=(A)-(B)",
                31: "4. 연도별 증원소요 인건비의 영향을 제거하기 위한 인건비의 조정(D) <주23>",
                32: "5. 별도직군 승진시기 차이에 따른 인건비 효과 조정(E) <주24>",
                33: "6. 초임직급 정원 변동에 따른 인건비 효과 조정(F) <주25>",
                34: "7. 정년이후 재고용을 전제로 전환된 정원외인력의 인건비 효과 조정(G) <주26>",
                35: "8. 생산량증가로 인하여 ’25년도’에 추가로 지급된 인건비의 영향 제거(H) <주27>",
                36: "9. 최저임금 지급 직원에 대한 인건비 효과 조정(J) <주28>",
                37: "10. 파업 등에 따른 인건비 효과 조정(K) <주29>",
                38: "11. 코로나19로 인한 휴업의 인건비 효과 조정 (K)",
                39: "12. 총인건비 인상률 계산대상 총인건비 발생액\n  = (C)+(D)+(E)-(F)-(G)-(H)+(I)+(J)+(K) <주31>",
                40: "13. 총인건비 인상률 가이드라인에 따른 총인건비 상한액 <주32>",
                41: "  (1) ’24년도 총인건비 인상률 가이드라인을 준수한 경우",
                42: "  (2) ’24년도 총인건비 인상률 가이드라인을 준수하지 않은 경우",
                43: "14. 총인건비 인상률 산출(’25년도 총인건비 인상률 가이드라인 = 3.0%) <주33>",
                44: "  (1) ’24년도 총인건비 인상률 가이드라인을 준수한 경우",
                45: "  (2) ’24년도 총인건비 인상률 가이드라인을 준수하지 않은 경우"
            }



        if self.year == '2023':
            # 3. B열 항목명 정의 (2024년 대비 t, u, v 3개 항목 제외 및 인덱스 조정)
            b_dict = {
                0: "1. 인센티브 상여금을 제외한 인건비 총액",
                1: "  a. 판관비로 처리한 인건비 <주1>",
                2: "  b. 영업외비용으로 처리한 인건비 <주2>",
                3: "  c. 제조원가로 처리한 인건비 <주3>",
                4: "  d. 타계정대체로 처리한 인건비 <주4>",
                5: "  e. 이익잉여금의 증감으로 처리한 인건비 <주5>",
                6: "▶ 소계 : (A)=a+b+c+d+e",
                7: "2. 총인건비 인상률 계산에서 제외(조정)되는 인건비",
                8: "  f. 퇴직급여(명예퇴직금 포함) <주6>",
                9: "  g. 임원 인건비<주7>",
                10: "  h. 비상임이사 인건비<주8>",
                11: "  i. 인상률 제외 인건비 (통상)",
                12: "  i. 인상률 제외 인건비 (기타)",
                13: "  j. 사내근로복지기금출연금<주10>",
                14: "  k. 잡급 및 무기계약직 인건비 <주11>",
                15: "  l. 공적보험 사용자부담분<주12>",
                16: "  m. 연월차수당 등 조정(㉠-㉡+㉢)<주13>",
                17: "    - 연월차수당 등 발생액(㉠)",
                18: "    - 연월차수당 등 지급액(㉡)",
                19: "    - 종업원 저리 대여금 이자 관련 인건비(㉢)",
                20: "  n. 저리·무상대여 이익<주14>",
                21: "  o. 지방이전 관련 직접 인건비<주15>",
                22: "  p. 법령에 따른 특수건강진단비<주16>",
                23: "  q. 코로나19 대응을 위한 시간외근로수당 등",
                24: "  r. 해외근무수당",
                25: "  s. 직무발명보상금",
                # 🔥 t, u, v 항목(26, 27, 28번) 제외
                26: "▶ 소계 : (B)=f+g+h+i+j+k+l+m-n+o+p+q+r+s", # 수식에서 t, u, v 제거
                
                # 🔥 이후 인덱스는 2024년 대비 -3 적용
                27: "3. 실집행액기준 총인건비 발생액 (C)=(A)-(B)",
                28: "4. 연도별 증원소요 인건비의 영향을 제거하기 위한 인건비의 조정(D) <주23>",
                29: "5. 별도직군 승진시기 차이에 따른 인건비 효과 조정(E) <주24>",
                30: "6. 초임직급 정원 변동에 따른 인건비 효과 조정(F) <주25>",
                31: "7. 정년이후 재고용을 전제로 전환된 정원외인력의 인건비 효과 조정(G) <주26>",
                32: "8. 생산량증가로 인하여 ’24년도’에 추가로 지급된 인건비의 영향 제거(H) <주27>",
                33: "9. 최저임금 지급 직원에 대한 인건비 효과 조정(J) <주28>",
                34: "10. 파업 등에 따른 인건비 효과 조정(K) <주29>",
                35: "11. 코로나19로 인한 휴업의 인건비 효과 조정 (K)",
                36: "12. 총인건비 인상률 계산대상 총인건비 발생액\n  = (C)+(D)+(E)-(F)-(G)-(H)+(I)+(J)+(K) <주31>",
                37: "13. 총인건비 인상률 가이드라인에 따른 총인건비 상한액 <주32>",
                38: "  (1) ’23년도 총인건비 인상률 가이드라인을 준수한 경우",
                39: "  (2) ’23년도 총인건비 인상률 가이드라인을 준수하지 않은 경우",
                40: "14. 총인건비 인상률 산출(’24년도 총인건비 인상률 가이드라인 = 2.5%) <주33>",
                41: "  (1) ’23년도 총인건비 인상률 가이드라인을 준수한 경우",
                42: "  (2) ’23년도 총인건비 인상률 가이드라인을 준수하지 않은 경우"
            }



            





        if self.year == '2025':
            
            # 4. B열 항목 적용 및 읽기전용 설정
            for r, text in b_dict.items():
                it = self.table.item(r, 1)
                if it:
                    it.setText(text)
                    # B열은 클릭 시 안내창 팝업을 위해 수정 불가(읽기전용)로 설정
                    it.setFlags(it.flags() & ~Qt.ItemIsEditable)

                    # 제목줄 배경색 및 폰트 설정
                    if r in [0, 6, 7, 15, 28, 29, 38, 39, 42]: 
                        bg = self.base_sky_blue if r in [0, 7, 29, 38, 39, 42] else self.target_light_blue
                        it.setBackground(bg)
                        it.setFont(QFont("맑은 고딕", 9, QFont.Bold))
                        
                        for c in range(2, 5):
                            target_item = self.table.item(r, c)
                            if target_item:
                                target_item.setBackground(bg)
                                # [핵심] 15번도 이제 여기서 직접 입력을 막습니다.
                                if r != 39 and r != 42:
                                    target_item.setFlags(target_item.flags() & ~Qt.ItemIsEditable)
         

            # 5. n/a 처리 및 기타 행 설정
            # 막아야 할 (행, 열) 좌표들을 리스트에 담습니다.
            na_list = [
                (37, 3), (37, 4), (27, 3), (27, 4), (34, 3), (34, 4), 
                (39, 2), (40, 2), (41, 2), (39, 3), (39, 4), (40, 4), (41, 4),
                (42, 2), (42, 3), (42, 4), (43, 4), (44, 4)
            ]

            for target_r, target_c in na_list:
                na_item = self.table.item(target_r, target_c)
                if na_item:
                    na_item.setText("n/a")
                    na_item.setBackground(self.base_sky_blue)
                    na_item.setFlags(na_item.flags() & ~Qt.ItemIsEditable)
                    na_item.setTextAlignment(Qt.AlignCenter)

            target_rows = [40, 41, 42, 43, 44]
            
            for r in target_rows:
                # 2번 열(C열)부터 4번 열(E열)까지 모두 파란색 및 입력 차단
                for c in range(1, 5):
                    item = self.table.item(r, c)
                    if item:
                        item.setBackground(self.base_sky_blue) # 파란색 배경
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable) # 입력 막기


            '''
            item = self.table.item(30, 2)
            item.setBackground(self.base_sky_blue) # 파란색 배경
            item.setFlags(item.flags() & ~Qt.ItemIsEditable) # 입력 막기
            item.setText("")

            item = self.table.item(32, 2)
            item.setBackground(self.base_sky_blue) # 파란색 배경
            item.setFlags(item.flags() & ~Qt.ItemIsEditable) # 입력 막기
            item.setText("")
            '''

            self.table.setRowHeight(38, 48)
            self.table.setRowCount(47)

            # 6. 안내 문구 (인덱스 46)
            self.table.setSpan(45, 0, 1, 5)
            self.table.setRowHeight(45, 10) 


            footer_text = (
                "’25년도(Ⅰ) = ①－⑫－⑰\n"
                "‘24년도 총인건비 인상률 준수기관(Ⅱ) = ②+④+⑥-⑧-⑩+⑬+⑮\n"
                "‘24년도 총인건비 인상률 위반기관(Ⅲ) = {(③+⑤+⑦-⑨-⑪+⑭+⑯)×(1+0.025)}+④+⑥-⑧-⑩+⑬+⑮\n\n"
                "※ 총인건비 인상률 산출계산 방법 <주33>\n"
                "(1) ‘24년도 총인건비인상률 준수기관 = [(Ⅰ)-(Ⅱ)]/(Ⅱ)\n"
                "(2) ‘24년도 총인건비인상률 위반기관 = [(Ⅰ)-(Ⅲ)]/(Ⅲ)\n\n"
                "※ 2024년 미위반기관은 2025년과 2024년만 기재\n\n"
                
            )
            it_footer = QTableWidgetItem(footer_text)
            it_footer.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 수정 불가
            it_footer.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            self.table.setItem(46, 0, it_footer)
            self.table.setSpan(46, 0, 1, 5)
            self.table.setRowHeight(46, 180)






        if self.year == '2024':
            
            # 4. B열 항목 적용 및 읽기전용 설정
            for r, text in b_dict.items():
                it = self.table.item(r, 1)
                if it:
                    it.setText(text)
                    # B열은 클릭 시 안내창 팝업을 위해 수정 불가(읽기전용)로 설정
                    it.setFlags(it.flags() & ~Qt.ItemIsEditable)

                    # 제목줄 배경색 및 폰트 설정
                    if r in [0, 6, 7, 16, 29, 30, 39, 40, 43]: 
                        bg = self.base_sky_blue if r in [0, 7, 30, 39, 40, 43] else self.target_light_blue
                        it.setBackground(bg)
                        it.setFont(QFont("맑은 고딕", 9, QFont.Bold))
                        
                        for c in range(2, 5):
                            target_item = self.table.item(r, c)
                            if target_item:
                                target_item.setBackground(bg)
                                # [핵심] 15번도 이제 여기서 직접 입력을 막습니다.
                                if r != 40 and r != 43:
                                    target_item.setFlags(target_item.flags() & ~Qt.ItemIsEditable)
         

            # 5. n/a 처리 및 기타 행 설정
            # 막아야 할 (행, 열) 좌표들을 리스트에 담습니다.
            na_list = [
                (40, 2), (41, 2), (42, 2), (40, 3), (40, 4), (41, 4), (42, 4),
                (43, 2), (43, 3), (43, 4), (44, 4), (45, 4)
            ]

            for target_r, target_c in na_list:
                na_item = self.table.item(target_r, target_c)
                if na_item:
                    na_item.setText("n/a")
                    na_item.setBackground(self.base_sky_blue)
                    na_item.setFlags(na_item.flags() & ~Qt.ItemIsEditable)
                    na_item.setTextAlignment(Qt.AlignCenter)

            target_rows = [41, 42, 43, 44, 45]
            
            for r in target_rows:
                # 2번 열(C열)부터 4번 열(E열)까지 모두 파란색 및 입력 차단
                for c in range(1, 5):
                    item = self.table.item(r, c)
                    if item:
                        item.setBackground(self.base_sky_blue) # 파란색 배경
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable) # 입력 막기


            self.table.setRowHeight(39, 48)
            self.table.setRowCount(48)

            # 6. 안내 문구 (인덱스 46)
            self.table.setSpan(46, 0, 1, 5)
            self.table.setRowHeight(46, 10) 

            footer_text = (
                "’25년도(Ⅰ) = ①－⑫－⑰\n"
                "‘24년도 총인건비 인상률 준수기관(Ⅱ) = ②+④+⑥-⑧-⑩+⑬+⑮\n"
                "‘24년도 총인건비 인상률 위반기관(Ⅲ) = {(③+⑤+⑦-⑨-⑪+⑭+⑯)×(1+0.025)}+④+⑥-⑧-⑩+⑬+⑮\n\n"
                "※ 총인건비 인상률 산출계산 방법 <주33>\n"
                "(1) ‘24년도 총인건비인상률 준수기관 = [(Ⅰ)-(Ⅱ)]/(Ⅱ)\n"
                "(2) ‘24년도 총인건비인상률 위반기관 = [(Ⅰ)-(Ⅲ)]/(Ⅲ)\n\n"
                "※ 2024년 미위반기관은 2025년과 2024년만 기재\n\n"
                
            )
            it_footer = QTableWidgetItem(footer_text)
            it_footer.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable) # 수정 불가
            it_footer.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            self.table.setItem(47, 0, it_footer)
            self.table.setSpan(47, 0, 1, 5)
            self.table.setRowHeight(47, 180)


        if self.year == '2023':
            # 4. B열 항목 적용 및 읽기전용 설정
            for r, text in b_dict.items():
                it = self.table.item(r, 1)
                if it:
                    it.setText(text)
                    it.setFlags(it.flags() & ~Qt.ItemIsEditable)

                    # 제목줄 배경색 및 폰트 설정 (2024년 [0, 6, 7, 16, 29, 30, 39, 40, 43] -> 2023년 -3 반영)
                    # 단, 상단 공통부분(0~16)은 유지하되 29번부터 -3 적용
                    if r in [0, 6, 7, 16, 26, 27, 36, 37, 40]: 
                        bg = self.base_sky_blue if r in [0, 7, 27, 36, 37, 40] else self.target_light_blue
                        it.setBackground(bg)
                        it.setFont(QFont("맑은 고딕", 9, QFont.Bold))
                        
                        for c in range(2, 5):
                            target_item = self.table.item(r, c)
                            if target_item:
                                target_item.setBackground(bg)
                                if r != 37 and r != 40: # 40->37, 43->40
                                    target_item.setFlags(target_item.flags() & ~Qt.ItemIsEditable)

            # 5. n/a 처리 및 기타 행 설정 (Offset -3 반영)
            na_list = [
                (37, 2), (38, 2), (39, 2), (37, 3), (37, 4), (38, 4), (39, 4),
                (40, 2), (40, 3), (40, 4), (41, 4), (42, 4)
            ]

            for target_r, target_c in na_list:
                na_item = self.table.item(target_r, target_c)
                if na_item:
                    na_item.setText("n/a")
                    na_item.setBackground(self.base_sky_blue)
                    na_item.setFlags(na_item.flags() & ~Qt.ItemIsEditable)
                    na_item.setTextAlignment(Qt.AlignCenter)

            target_rows = [38, 39, 40, 41, 42] # 41~45 -> 38~42
            for r in target_rows:
                for c in range(1, 5):
                    item = self.table.item(r, c)
                    if item:
                        item.setBackground(self.base_sky_blue)
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)

            self.table.setRowHeight(36, 48) # 39 -> 36
            self.table.setRowCount(45) # 전체 행수 조정 (48-3)

            # 6. 안내 문구 (인덱스 43 / 2024년 46에서 -3)
            self.table.setSpan(43, 0, 1, 5)
            self.table.setRowHeight(43, 10) 

            # 2023년 기준 수식 및 연도 조정
            footer_text = (
                "’24년도(Ⅰ) = ①－⑫－⑰\n"
                "‘23년도 총인건비 인상률 준수기관(Ⅱ) = ②+④+⑥-⑧-⑩+⑬+⑮\n"
                "‘23년도 총인건비 인상률 위반기관(Ⅲ) = {(③+⑤+⑦-⑨-⑪+⑭+⑯)×(1+0.017)}+④+⑥-⑧-⑩+⑬+⑮\n\n"
                "※ 총인건비 인상률 산출계산 방법 <주33>\n"
                "(1) ‘23년도 총인건비인상률 준수기관 = [(Ⅰ)-(Ⅱ)]/(Ⅱ)\n"
                "(2) ‘23년도 총인건비인상률 위반기관 = [(Ⅰ)-(Ⅲ)]/(Ⅲ)\n\n"
                "※ 2023년 미위반기관은 2024년과 2023년만 기재\n\n"
            )
            # 당시 위반기관 보정치(0.017) 등 지침서 수치를 반영하였습니다.
            
            it_footer = QTableWidgetItem(footer_text)
            it_footer.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            it_footer.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            self.table.setItem(44, 0, it_footer) # 47 -> 44
            self.table.setSpan(44, 0, 1, 5)
            self.table.setRowHeight(44, 180)



        self.table.blockSignals(False)




    def calculate_s2(self, item):
        col = item.column()
        if col < 2: return  

        self.table.blockSignals(True)
        try:
            def gv(r, c=None):
                target_col = c if c is not None else col
                it = self.table.item(r, target_col)
                if not it: return 0.0
                txt = it.text().strip().replace(',', '')
                if not txt or txt in ["n/a", "-", ""]: return 0.0
                try: return float(txt)
                except: return 0.0

            # ==========================================================
            # [CASE 1] 2025년 계산 로직 (기존 코드 100% 보존)
            # ==========================================================
            if self.year == '2025':
                sum_a = sum(gv(r) for r in range(1, 6))
                self.table.item(0, col).setText("")
                self.table.item(6, col).setText(format(int(sum_a), ","))

                val_m = gv(16) - gv(17) + gv(18)
                self.table.item(15, col).setText(format(int(val_m), ","))

                sum_b = gv(8)+gv(9)+gv(10)+gv(11)+gv(12)+gv(13)+gv(14)+gv(15)-gv(19)+gv(20)+gv(21)+gv(22)+gv(23)+gv(24)+gv(25)+gv(26)+gv(27)
                self.table.item(7, col).setText("")
                self.table.item(28, col).setText(format(int(sum_b), ","))

                sum_c = sum_a - sum_b
                self.table.item(29, col).setText(format(int(sum_c), ","))

                v_i = gv(29, 2) - gv(34, 2) - gv(37, 2)
                v_ii = gv(29, 3) + gv(30, 3) + gv(31, 3) - gv(32, 3) - gv(33, 3) + gv(35, 3) + gv(36, 3)
                v_ii_2023 = gv(29, 4) + gv(30, 4) + gv(31, 4) - gv(32, 4) - gv(33, 4) + gv(35, 4) + gv(36, 4)

                self.table.item(38, 2).setText(format(int(v_i), ","))
                self.table.item(38, 3).setText(format(int(v_ii), ","))
                self.table.item(38, 4).setText(format(int(v_ii_2023), ","))
                self.table.item(40, 3).setText(format(int(v_ii), ","))

                v_iii = (v_ii_2023 * 1.025) + gv(30, 3) + gv(31, 3) - gv(32, 3) - gv(33, 3) + gv(35, 3) + gv(36, 3)
                if self.table.item(41, 3).text() == '':
                    self.table.item(41, 3).setText('')
                else:
                    self.table.item(41, 3).setText(format(int(v_iii), ","))

                if not v_ii:
                    self.table.item(43, 2).setText('0.0')
                else:
                    self.table.item(43, 2).setText(format((((v_i - v_ii)/v_ii))).rstrip('.'))

                if self.table.item(41, 3).text() == '':
                    self.table.item(44, 2).setText('')
                else:
                    if v_iii == 0: self.table.item(44, 2).setText('0.0')
                    else: self.table.item(44, 2).setText(format((((v_i - v_iii)/v_iii))).rstrip('.'))

            # ==========================================================
            # [CASE 2] 2024년 계산 로직 (부호 정밀 교정)
            # ==========================================================
            elif self.year == '2024':
                # 소계(A)
                sum_a = sum(gv(r) for r in range(1, 6))
                self.table.item(0, col).setText("")
                self.table.item(6, col).setText(format(int(sum_a), ","))

                # 연월차(16)
                val_m = gv(17) - gv(18) + gv(19)
                self.table.item(16, col).setText(format(int(val_m), ","))

                # 소계(B)
                sum_b = (gv(8)+gv(9)+gv(10)+gv(11)+gv(12)+gv(13)+gv(14)+gv(15)+gv(16)
                         - gv(20)+gv(21)+gv(22)+gv(23)+gv(24)+gv(25)+gv(26)+gv(27)+gv(28))
                self.table.item(7, col).setText("")
                self.table.item(29, col).setText(format(int(sum_b), ","))

                # (C) 실집행액
                sum_c = sum_a - sum_b
                self.table.item(30, col).setText(format(int(sum_c), ","))

                # 12번 산식 반영: (C)30 + (D)31 + (E)32 - (F)33 - (G)34 - (H)35 + (I)36 + (J)37 + (K)38
                def get_v_logic_24(c_idx):
                    return (gv(30, c_idx) + gv(31, c_idx) + gv(32, c_idx) # C, D, E (+)
                            - gv(33, c_idx) - gv(34, c_idx) - gv(35, c_idx) # F, G, H (-)
                            + gv(36, c_idx) + gv(37, c_idx) + gv(38, c_idx)) # I, J, K (+)

                v_i = get_v_logic_24(2)
                v_ii = get_v_logic_24(3)
                v_ii_2023 = get_v_logic_24(4)

                self.table.item(39, 2).setText(format(int(v_i), ","))
                self.table.item(39, 3).setText(format(int(v_ii), ","))
                self.table.item(39, 4).setText(format(int(v_ii_2023), ","))
                self.table.item(41, 3).setText(format(int(v_ii), ","))

                # (III) 보정 계산
                v_iii = (v_ii_2023 * 1.025) + gv(31, 3) + gv(32, 3) - gv(33, 3) - gv(34, 3) + gv(36, 3) + gv(37, 3)
                if self.table.item(42, 3).text() == '':
                    self.table.item(42, 3).setText('')
                else:
                    self.table.item(42, 3).setText(format(int(v_iii), ","))

                # 최종 인상률 산출
                if not v_ii:
                    self.table.item(44, 2).setText('0.0')
                else:
                    self.table.item(44, 2).setText(f"{((v_i - v_ii)/v_ii):.3f}")

                self.table.item(41, 3).setText(format(int(v_ii * (1 + gv(44,2))), ","))

                if self.table.item(42, 3).text() == '':
                    self.table.item(45, 2).setText('')
                else:
                    if v_iii == 0: self.table.item(45, 2).setText('0.0')
                    else: self.table.item(45, 2).setText(format((((v_i - v_iii)/v_iii))).rstrip('.'))

            # ==========================================================
            # [CASE 3] 2023년 계산 로직 (2024년 산식 복제 + 행 번호 -3)
            # ==========================================================
            elif self.year == '2023':
                # 소계(A)
                sum_a = sum(gv(r) for r in range(1, 6))
                self.table.item(0, col).setText("")
                self.table.item(6, col).setText(format(int(sum_a), ","))

                # 연월차(16)
                val_m = gv(17) - gv(18) + gv(19)
                self.table.item(16, col).setText(format(int(val_m), ","))

                # 소계(B): t,u,v 제외하여 25행까지
                sum_b = (gv(8)+gv(9)+gv(10)+gv(11)+gv(12)+gv(13)+gv(14)+gv(15)+gv(16)
                         - gv(20)+gv(21)+gv(22)+gv(23)+gv(24)+gv(25))
                self.table.item(7, col).setText("")
                self.table.item(26, col).setText(format(int(sum_b), ",")) 

                # (C) 실집행액
                sum_c = sum_a - sum_b
                self.table.item(27, col).setText(format(int(sum_c), ",")) 

                # 12번 산식 반영 (-3 오프셋): (C)27 + (D)28 + (E)29 - (F)30 - (G)31 - (H)32 + (I)33 + (J)34 + (K)35
                def get_v_logic_23(c_idx):
                    return (gv(27, c_idx) + gv(28, c_idx) + gv(29, c_idx) # C, D, E (+)
                            - gv(30, c_idx) - gv(31, c_idx) - gv(32, c_idx) # F, G, H (-)
                            + gv(33, c_idx) + gv(34, c_idx) + gv(35, c_idx)) # I, J, K (+)

                v_i = get_v_logic_23(2)
                v_ii = get_v_logic_23(3)
                v_ii_2022 = get_v_logic_23(4)

                # 결과값 기록
                self.table.item(36, 2).setText(format(int(v_i), ","))
                self.table.item(36, 3).setText(format(int(v_ii), ","))
                self.table.item(36, 4).setText(format(int(v_ii_2022), ","))
                self.table.item(38, 3).setText(format(int(v_ii), ","))

                # (III) 보정 계산
                v_iii = (v_ii_2022 * 1.025) + gv(28, 3) + gv(29, 3) - gv(30, 3) - gv(31, 3) + gv(33, 3) + gv(34, 3)
                
                if self.table.item(39, 3).text() == '':
                    self.table.item(39, 3).setText('')
                else:
                    self.table.item(39, 3).setText(format(int(v_iii), ","))

                # 최종 인상률 산출
                if not v_ii:
                    self.table.item(41, 2).setText('0.0')
                else:
                    self.table.item(41, 2).setText(f"{((v_i - v_ii)/v_ii):.5f}") 

                # 상한액 반영
                self.table.item(38, 3).setText(format(int(v_ii * (1 + gv(41, 2))), ","))

                if self.table.item(39, 3).text() == '':
                    self.table.item(42, 2).setText('')
                else:
                    if v_iii == 0: self.table.item(42, 2).setText('0.0')
                    else: self.table.item(42, 2).setText(f"{((v_i - v_iii)/v_iii):.5f}")






            if self.year == '2025':
                target_rows = [43, 44]
            elif self.year == '2024':
                target_rows = [44, 45]
            elif self.year == '2023':
                target_rows = [41, 42]
            else:
                target_rows = [] # 예외 케이스 대비

            for row in target_rows:
                it = self.table.item(row, 2)
                if it: 
                    it.setTextAlignment(Qt.AlignCenter)









        except Exception as e:
            print(f"!!! 계산 에러 !!!: {e}")
        finally:
            self.table.blockSignals(False)
            self.table.viewport().update()






    def sync_from_s1(self, data_list):
        """S1에서 받은 리스트를 지정된 행 위치에 매핑하여 주입"""
        if not data_list or len(data_list) < 12: return


        # print(data_list)
        
        self.table.blockSignals(True)
        try:
            # ------------------------------------------------------
            # [CASE 1] 2025년 매핑 (기존 로직 유지)
            # ------------------------------------------------------
            if self.year == '2025':
                # 1. 주1 ~ 주5 (index 0~4) -> 1 ~ 5행
                for i in range(0, 5):
                    item = self.table.item(i + 1, 2)
                    if item: item.setText(format(int(round(data_list[i]+0.000001)), ","))

                # 2. 주6 ~ 주10 (index 5~9) -> 8 ~ 12행
                for i in range(5, 10):
                    item = self.table.item(i + 3, 2)
                    if item: item.setText(format(int(round(data_list[i]+0.000001)), ","))

                # 3. 주11 (index 10) -> 14행
                item_11 = self.table.item(14, 2)
                if item_11: item_11.setText(format(int(round(data_list[10]+0.000001)), ","))

                # 4. 주12 (index 11) -> 13행
                item_12 = self.table.item(13, 2)
                if item_12: item_12.setText(format(int(round(data_list[11]+0.000001)), ","))


            '''
            # ------------------------------------------------------
            # [CASE 2] 2024년 매핑 (지침 변경에 따른 행 주소 보정)
            # ------------------------------------------------------
            elif self.year == '2024':
                # 1. 주1 ~ 주5 (index 0~4) -> 1 ~ 5행 (동일)
                for i in range(0, 5):
                    item = self.table.item(i + 1, 2)
                    if item: item.setText(format(int(round(data_list[i]+0.000001)), ","))

                # 2. 주6 ~ 주10 (index 5~9) -> 8 ~ 12행 (동일)
                for i in range(5, 8):
                    item = self.table.item(i + 3, 2)
                    if item: item.setText(format(int(round(data_list[i]+0.000001)), ","))

                for i in range(8, 10):
                    item = self.table.item(i + 4, 2)
                    if item: item.setText(format(int(round(data_list[i]+0.000001)), ","))
                    

                # 3. 주11 (index 10) -> 15행 (2025년 14행에서 1칸 밀림)
                item_11 = self.table.item(15, 2)
                if item_11: item_11.setText(format(int(round(data_list[10]+0.000001)), ","))

                # 4. 주12 (index 11) -> 14행 (2025년 13행에서 1칸 밀림)
                item_12 = self.table.item(14, 2)
                if item_12: item_12.setText(format(int(round(data_list[11]+0.000001)), ","))



            # ------------------------------------------------------
            # [CASE 3] 2023년 매핑 (t, u, v 부재에 따른 행 주소 보정)
            # ------------------------------------------------------
            elif self.year == '2023':
                # 1. 주1 ~ 주5 (index 0~4) -> 1 ~ 5행 (상단은 2024년과 동일)
                for i in range(0, 5):
                    item = self.table.item(i + 1, 2)
                    if item: item.setText(format(int(round(data_list[i]+0.000001)), ","))

                # 2. 주6 ~ 주10 (index 5~9) -> 8 ~ 12행 (상단은 2024년과 동일)
                for i in range(5, 8):
                    item = self.table.item(i + 3, 2)
                    if item: item.setText(format(int(round(data_list[i]+0.000001)), ","))


                for i in range(8, 10):
                    item = self.table.item(i + 4, 2)
                    if item: item.setText(format(int(round(data_list[i]+0.000001)), ","))



                # 3. 주11 (index 10) -> 15행 (기존 유지)
                item_11 = self.table.item(15, 2)
                if item_11: item_11.setText(format(int(round(data_list[10]+0.000001)), ","))

                # 4. 주12 (index 11) -> 14행 (기존 유지)
                item_12 = self.table.item(14, 2)
                if item_12: item_12.setText(format(int(round(data_list[11]+0.000001)), ","))

                # 5. 이후 항목 매핑 (필요 시 2024년 로직을 따라가되, 
                # t, u, v가 시작되는 지점부터는 인덱스를 신중히 매핑해야 합니다.)
            '''










        finally:
            self.table.blockSignals(False)
            
        # Sheet2 전체 계산 로직 호출 (기준 셀 전달)
        self.calculate_s2(self.table.item(1, 2))



            

    def sync_from_s3(self, gab_value):
        """MainWindow를 통해 S3의 (갑) 데이터를 주입받음"""
        self.table.blockSignals(True)
        try:
            # 1. 데이터 전처리 (공통)
            val = float(str(gab_value).replace(',', '')) if gab_value else 0.0




            # ------------------------------------------------------
            # [2025년] 기존 지침서 30행 타격 (원본 코드 100% 보존)
            # ------------------------------------------------------
            if self.year == '2025':
                # 원본 코드 그대로 유지
                item = self.table.item(30, 3)
                if item:
                    item.setText(format(int(round(val+0.000001)), ",d"))
                
                # 원본 트리거 로직 그대로 유지
                trigger_item = self.table.item(30, 3)
                if trigger_item:
                    self.calculate_s2(trigger_item)





            '''
            # ------------------------------------------------------
            # [2024년] 11번 분리로 인해 지침서 31행 타격
            # ------------------------------------------------------
            if self.year == '2024':
                item_24 = self.table.item(31, 3)
                if item_24:
                    item_24.setText(format(int(round(val + 0.000001)), ",d"))
                    # 2024년 기준 31행으로 계산기 실행
                    self.calculate_s2(item_24)


            # ------------------------------------------------------
            # [2023년] t, u, v 제외로 인해 지침서 28행으로 상향
            # ------------------------------------------------------
            if self.year == '2023':
                # 2024년의 31행은 2023년에서 28행입니다. (31 - 3 = 28)
                item_23 = self.table.item(28, 3)
                if item_23:
                    # 기존의 round 처리와 천단위 콤마 포맷(,d)을 엄격히 유지합니다.
                    item_23.setText(format(int(round(val + 0.000001)), ",d"))
                    
                    # 2023년 기준 위치인 28행 아이템을 인자로 계산 로직을 실행합니다.
                    self.calculate_s2(item_23)
            '''

















                
        finally:
            self.table.blockSignals(False)
            self.table.viewport().update()


    def sync_eul_from_s10(self, eul_value):
        """
        Sheet10에서 계산된 (을) 값을 Sheet2의 해당 연도 위치에 주입
        """
        if eul_value is None:
            return

        self.table.blockSignals(True) # 주입 중 무한 루프 방지
        
        try:
            # 연도별 (을) 항목 위치 결정 (Offset -3 반영)
            if self.year == '2025': target_row = 32
            elif self.year == '2024': target_row = 33
            # 🔥 2023년: 2024년 33행에서 3행을 뺀 30행이 (을) 위치입니다.
            elif self.year == '2023': target_row = 30

            target_col = 3   # 데이터 주입 열 (동일)
            
            item = self.table.item(target_row, target_col)
            if not item:
                item = ThousandSeparatorItem("0", self.year)
                self.table.setItem(target_row, target_col, item)
            
            # 숫자 변환 및 반올림 처리 (기존 로직 엄격 유지)
            try:
                numeric_val = float(str(eul_value).replace(',', ''))
                # 대국민 서비스의 계산 일관성을 위해 +0.000001 보정 및 round 유지
                formatted_val = format(int(round(numeric_val + 0.000001)), ",")
                item.setText(formatted_val)
            except (ValueError, TypeError):
                item.setText("0")

            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            
        except Exception as e:
            print(f"Sheet2 데이터 주입 실패: {e}")
            
        finally:
            self.table.blockSignals(False)
            
        # [핵심] 값이 주입된 후 각 연도별 올바른 위치의 아이템으로 계산 로직 호출
        if self.year == '2025': 
            self.calculate_s2(self.table.item(32, 3))
        elif self.year == '2024': 
            self.calculate_s2(self.table.item(33, 3))
        # 🔥 2023년용 계산 호출 추가
        elif self.year == '2023': 
            self.calculate_s2(self.table.item(30, 3))






    def copy_selection(self):
        selection = self.table.selectedRanges()
        if not selection: return
        
        min_r, max_r = min(r.topRow() for r in selection), max(r.bottomRow() for r in selection)
        min_c, max_c = min(r.leftColumn() for r in selection), max(r.rightColumn() for r in selection)

        # 2줄 제외 로직 유지
        # max_r = max_r - 2 
        
        lines = []
        if min_r == 0:
            headers = [self.table.horizontalHeaderItem(c).text() for c in range(min_c, max_c + 1)]
            lines.append("\t".join(headers))

        for r in range(min_r, max_r + 1):
            row_data = []
            for c in range(min_c, max_c + 1):
                def idx(target_r, target_c=None):
                    r_diff = target_r - r 
                    target_col_idx = target_c if target_c is not None else c
                    c_diff = target_col_idx - c
                    return f"INDEX($1:$1048576,ROW()+({r_diff}),COLUMN()+({c_diff}))"

                val = ""



                # ==========================================================
                # [CASE 3] 2023년 수식 (t, u, v 제외 반영: -3 오프셋)
                # ==========================================================
                if self.year == '2023':
                    # n/a 처리 (2024년 기준 위치에서 -3 보정)
                    # 2024년 [(28,3),(28,4), (35,3),(35,4), (38,3),(38,4)]
                    na_list_23 = [(25, 3), (25, 4), (32, 3), (32, 4), (35, 3), (35, 4)]
                    if (r, c) in na_list_23: val = "n/a"
                    
                    elif c >= 2:
                        if r == 0 or r == 6: val = f"=SUM({idx(1)}:{idx(5)})" # 소계A
                        elif r == 16: val = f"={idx(17)}-{idx(18)}+{idx(19)}" # 연월차(m)
                        elif r == 7 or r == 26: # 소계B (29 -> 26)
                            # 20~28에서 t,u,v 제외하여 20~25로 조정
                            val = f"=SUM({idx(8)}:{idx(16)})+SUM({idx(20)}:{idx(25)})"
                        elif r == 27: val = f"={idx(6)}-{idx(26)}" # 발생액(C) (30 -> 27)
                        elif r == 36: # 총인건비 발생액 (39 -> 36)
                            if c == 2: val = f"={idx(27)}-{idx(32)}-{idx(35)}"
                            else: val = f"={idx(27)}+{idx(28)}+{idx(29)}-{idx(30)}-{idx(31)}+{idx(33)}+{idx(34)}"
                        elif r == 38 and c == 3: val = f"={idx(36, 3)}" # 비교대상(1) (41 -> 38)
                        elif r == 39 and c == 3: # 비교대상(2) (42 -> 39)
                            # 2023년 기준 전년도(2022) 보정 수식 (당시 보정치 1.7% 가정)
                            v22 = f"({idx(27, 4)}+{idx(28, 4)}+{idx(29, 4)}-{idx(30, 4)}-{idx(31, 4)}+{idx(33, 4)}+{idx(34, 4)})"
                            v23 = f"({idx(28, 3)}+{idx(29, 3)}-{idx(30, 3)}-{idx(31, 3)}+{idx(33, 3)}+{idx(34, 3)})"
                            val = f"=({v22}*1.017)+{v23}"
                        elif r == 41: val = f"=IFERROR(({idx(36, 2)}-{idx(38, 3)})/{idx(38, 3)}, 0)" # 44 -> 41
                        elif r == 42: val = f"=IFERROR(({idx(36, 2)}-{idx(39, 3)})/{idx(39, 3)}, 0)" # 45 -> 42


                
                # ==========================================================
                # [CASE 1] 2024년 수식 (지침 변경 반영: +1행씩 밀림)
                # ==========================================================
                elif self.year == '2024':
                    # n/a 처리 (2024년 기준 위치 보정 필요시 여기서 수정)
                    na_list_24 = [(28, 3), (28, 4), (35, 3), (35, 4), (38, 3), (38, 4)] # 예시
                    if (r, c) in na_list_24: val = "n/a"
                    
                    elif c >= 2:
                        if r == 0 or r == 6: val = f"=SUM({idx(1)}:{idx(5)})" # 소계A
                        elif r == 16: val = f"={idx(17)}-{idx(18)}+{idx(19)}" # 연월차(m)
                        elif r == 7 or r == 29: # 소계B
                            val = f"=SUM({idx(8)}:{idx(16)})+SUM({idx(20)}:{idx(28)})"
                        elif r == 30: val = f"={idx(6)}-{idx(29)}" # 발생액(C)
                        elif r == 39: # 총인건비 발생액
                            if c == 2: val = f"={idx(30)}-{idx(35)}-{idx(38)}"
                            else: val = f"={idx(30)}+{idx(31)}+{idx(32)}-{idx(33)}-{idx(34)}+{idx(36)}+{idx(37)}"
                        elif r == 41 and c == 3: val = f"={idx(39, 3)}" # 비교대상(1)
                        elif r == 42 and c == 3: # 비교대상(2)
                            v23 = f"({idx(30, 4)}+{idx(31, 4)}+{idx(32, 4)}-{idx(33, 4)}-{idx(34, 4)}+{idx(36, 4)}+{idx(37, 4)})"
                            v24 = f"({idx(31, 3)}+{idx(32, 3)}-{idx(33, 3)}-{idx(34, 3)}+{idx(36, 3)}+{idx(37, 3)})"
                            val = f"=({v23}*1.025)+{v24}"
                        elif r == 44: val = f"=IFERROR(({idx(39, 2)}-{idx(41, 3)})/{idx(41, 3)}, 0)"
                        elif r == 45: val = f"=IFERROR(({idx(39, 2)}-{idx(42, 3)})/{idx(42, 3)}, 0)"

                # ==========================================================
                # [CASE 2] 2025년 수식 (기존 코드 100% 보존)
                # ==========================================================
                elif self.year == '2025':
                    na_list = [(27, 3), (27, 4), (34, 3), (34, 4), (37, 3), (37, 4),
                               (39, 2), (39, 3), (39, 4), (40, 2), (40, 4), (41, 2), (41, 4),
                               (42, 2), (42, 3), (42, 4), (43, 4), (44, 4)]
                    if (r, c) in na_list: val = "n/a"
                    elif c >= 2:
                        if r == 0 or r == 6: val = f"=SUM({idx(1)}:{idx(5)})"
                        elif r == 15: val = f"={idx(16)}-{idx(17)}+{idx(18)}"
                        elif r == 7 or r == 28:
                            val = f"=SUM({idx(8)}:{idx(14)})+{idx(15)}+SUM({idx(19)}:{idx(27)})"
                        elif r == 29: val = f"={idx(6)}-{idx(28)}"
                        elif r == 38:
                            if c == 2: val = f"={idx(29)}-{idx(34)}-{idx(37)}"
                            else: val = f"={idx(29)}+{idx(30)}+{idx(31)}-{idx(32)}-{idx(33)}+{idx(35)}+{idx(36)}"
                        elif r == 40 and c == 3: val = f"={idx(38, 3)}"
                        elif r == 41 and c == 3:
                            v23 = f"({idx(29, 4)}+{idx(30, 4)}+{idx(31, 4)}-{idx(32, 4)}+{idx(33, 4)}+{idx(35, 4)}+{idx(36, 4)})"
                            v24 = f"({idx(30, 3)}+{idx(31, 3)}-{idx(32, 3)}+{idx(33, 3)}+{idx(35, 3)}+{idx(36, 3)})"
                            val = f"=({v23}*1.025)+{v24}"
                        elif r == 43: val = f"=IFERROR(({idx(38, 2)}-{idx(40, 3)})/{idx(40, 3)}, 0)"
                        elif r == 44: val = f"=IFERROR(({idx(38, 2)}-{idx(41, 3)})/{idx(41, 3)}, 0)"

                # --- [공통: 일반 값 처리] ---
                if val == "":
                    it = self.table.item(r, c)
                    if it:
                        txt = it.text().replace(',', '').strip()
                        if c < 2:
                            val = "'" + txt if txt.startswith(('-', '+', '=')) else txt
                        else:
                            val = txt if txt else "0"
                    else:
                        val = "0"
                
                row_data.append(val)
            lines.append("\t".join(row_data))
            
        QApplication.clipboard().setText("\n".join(lines))

        


    def paste_selection(self):
        text = QApplication.clipboard().text()
        curr = self.table.currentItem()
        if not text or not curr: return
        
        r_s, c_s = curr.row(), curr.column()
        self.table.blockSignals(True)
        
        changed_cols = set()
        
        # ------------------------------------------------------
        # [CASE 1] 2024년 보호 행 (지침서 행 번호 1:1 매칭)
        # ------------------------------------------------------
        if self.year == '2024':
            # 2025년 대비 7행 이후부터 1칸씩 밀림 (11번 분리 반영)
            protected_rows = [0, 6, 7, 16, 29, 30, 39, 40, 41, 42, 43, 44, 45]
            
        # ------------------------------------------------------
        # [CASE 2] 2025년 보호 행
        # ------------------------------------------------------
        elif self.year == '2025':
            protected_rows = [0, 6, 7, 15, 28, 29, 38, 39, 40, 41, 42, 43, 44]

        # ------------------------------------------------------
        # [CASE 3] 2023년 보호 행 (t, u, v 제외 반영: Offset -3)
        # ------------------------------------------------------
        elif self.year == '2023':
            protected_rows = [0, 6, 7, 16, 26, 27, 36, 37, 38, 39, 40, 41, 42]



        
        else:
            self.table.blockSignals(False)
            return

        lines = text.splitlines()
        for i, line in enumerate(lines):
            parts = line.split('\t')
            for j, val in enumerate(parts):
                r, c = r_s + i, c_s + j
                if r < self.table.rowCount() and c < self.table.columnCount():
                    if c < 2: continue
                    changed_cols.add(c)
                    # 설정된 연도별 보호 행에 포함되지 않을 때만 값 주입
                    if r not in protected_rows:
                        item = self.table.item(r, c)
                        if item and (item.flags() & Qt.ItemIsEditable):
                            item.setText(val.strip().replace(',', ''))
        
        self.table.blockSignals(False)
        
        # 붙여넣기 후 모든 변경된 열에 대해 계산 강제 실행
        for col_idx in sorted(changed_cols):
            trigger = self.table.item(1, col_idx) 
            if trigger:
                self.calculate_s2(trigger)
                


                
    def keyPressEvent(self, event):
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C: self.copy_selection()
        elif event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_V: self.paste_selection()
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter):
            curr_row = self.table.currentRow()
            if curr_row < self.table.rowCount() - 1:
                self.table.setCurrentCell(curr_row + 1, self.table.currentColumn())
        else: super().keyPressEvent(event)







    def contextMenuEvent(self, event):
        menu = QMenu(self)
        
        # --- [스타일 적용: 선택 시 파란 배경, 하얀 글씨] ---
        menu.setStyleSheet("""
            QMenu::item:selected {
                background-color: #0078d7; /* 파란색 하이라이트 */
                color: white;              /* 하얀색 글자 */
            }
        """)
        
        cp = menu.addAction("복사")
        ps = menu.addAction("붙여넣기")
        
        # 메뉴 실행
        action = menu.exec_(QCursor.pos())
        
        if action == cp: 
            self.copy_selection()
        elif action == ps: 
            self.paste_selection()




