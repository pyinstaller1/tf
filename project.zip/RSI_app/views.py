from django.shortcuts import render
from RSI_app.kiwoom.main import *
from RSI_app.kiwoom.util import *

def index(request):
    kospi_df = get_kospi300_code()
    kospi = kospi_df.to_dict('records')
    return render(request, 'index.html', {'kospi': kospi, 'ilbong': None})

def partial_kospi(request):
    kospi_df = get_kospi300_code()
    kospi = kospi_df.to_dict('records')
    return render(request, '_partial_kospi.html', {'kospi': kospi})

def partial_detail(request):
    code = request.GET.get('code')
    json_ilbong = '[]'
    json_basic = '[]'

    df_ilbong = get_ilbong_data(code)
    json_ilbong = df_ilbong.to_json(orient='records')

    df_basic = get_basic_data(code)
    json_basic = df_basic.to_json(orient='records')

    return render(request, '_partial_detail.html', {
        'code': code,
        'json_ilbong': json_ilbong,
        'json_basic': json_basic
    })



def rsi_chart(request):
    param_high = request.GET.get('high', 'high')  # 기본값은 'high'
    list_rsi = get_rsi(high=param_high)
    return render(request, 'rsi_chart.html', {'data': list_rsi})



def macd_chart(request):
    param_high = request.GET.get('high', 'high')  # 기본값은 'high'
    list_macd = get_macd(high=param_high)
    return render(request, 'macd_chart.html', {'data': list_macd})



















