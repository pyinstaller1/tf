
from PyQt5.QAxContainer import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import time
from datetime import datetime
import pandas as pd
import numpy as np
from urllib3.connection import RECENT_DATE



from RSI_app.kiwoom.util.const import *
from RSI_app.kiwoom.util.db import *

'''
from util.const import *
from db import *
'''


class Kiwoom(QAxWidget):   # QAxWidget: Open API 연결
    def __init__(self):
        super().__init__()
        self._make_kiwoom_instance()
        self._set_signal_slots()
        self._comm_connect()

        self.account_number = self.get_account_number()
        self.tr_event_loop = QEventLoop()

        self.order = {}
        self.balance = {}
        self.universe_realtime_transaction_info = {}

    def _make_kiwoom_instance(self):
        self.setControl("KHOPENAPI.KHOpenAPICtrl.1")   # QAxContainer.QAxWidget의 setControl

    def _set_signal_slots(self):
        self.OnEventConnect.connect(self._login_slot)   # 로그인 결과를 받는 슬롯
        self.OnReceiveTrData.connect(self._on_receive_tr_data)
        self.OnReceiveMsg.connect(self._on_receive_msg)
        self.OnReceiveChejanData.connect(self._on_chejan_slot)
        self.OnReceiveRealData.connect(self._on_receive_real_data)

    def _comm_connect(self):
        self.dynamicCall("CommConnect()")   # 로그인 팝업
        self.login_event_loop = QEventLoop()
        self.login_event_loop.exec_()   # 로그인 입력 후 응답 대기


    def _login_slot(self, err_code):
        if err_code == 0:
            print("connected")
        else:
            print("not connected")
        self.login_event_loop.exit()
        

    def _on_receive_tr_data(self, screen_no, rqname, trcode, record_name, next, unused1, unused2, unused3, unused4):
        # print("slot [tr_" + trcode + "]")
        tr_data_cnt = self.dynamicCall("GetRepeatCnt(QString, QString)", trcode, rqname)

        if next=='2':
            self.has_next_tr_data = True
        else:
            self.has_next_tr_data = False

        if rqname == "opt10081_req": # 일봉 600건
            ohlcv = {'date':[], 'open':[], 'high':[], 'low':[], 'close':[], 'volume':[]}

            # for i in range(tr_data_cnt):
            for i in range(300):
                date = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, i, "일자")
                open = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, i, "시가")
                high = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, i, "고가")
                low = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, i, "저가")
                close = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, i, "현재가")
                volume = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, i, "거래량")


                try:
                    ohlcv['date'].append(date.strip())
                    ohlcv['open'].append((int(open)))
                    ohlcv['high'].append((int(high)))
                    ohlcv['low'].append((int(low)))
                    ohlcv['close'].append((int(close)))
                    ohlcv['volume'].append((int(volume)))

                except ValueError:
                    if ohlcv['date']:
                        ohlcv['date'].pop()                    
                    print(f"[경고] {i}번째 데이터 변환 실패 (상장 초기 데이터일 가능성 있음)")
                    break
                

            self.tr_data = ohlcv




        elif rqname == "opt10081_req_1day":
            ohlcv = {'date':[], 'open':[], 'high':[], 'low':[], 'close':[], 'volume':[]}

            date = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, 0, "일자")
            open = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, 0, "시가")
            high = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, 0, "고가")
            low = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, 0, "저가")
            close = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, 0, "현재가")
            volume = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, 0, "거래량")

            ohlcv['date'].append(date.strip())
            ohlcv['open'].append((int(open)))
            ohlcv['high'].append((int(high)))
            ohlcv['low'].append((int(low)))
            ohlcv['close'].append((int(close)))
            ohlcv['volume'].append((int(volume)))

            self.tr_data = ohlcv

        elif rqname == "opw00001_req":
            deposit = self.dynamicCall("GetCommData(QString, QString, int, QString", trcode, rqname, 0, "주문가능금액")
            self.tr_data = int(deposit)
            print(self.tr_data)

        elif rqname=="opt10075_req":
            for i in range(tr_data_cnt):
                code = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "종목코드")
                code_name = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "종목명")
                order_number = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "주문번호")
                order_status = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "주문상태")
                order_quantity = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "주문수량")
                order_price = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "주문가격")
                current_price = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "현재가")
                order_type = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "주문구분")
                left_quantity = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "미체결수량")
                executed_quantity = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "체결량")
                ordered_at = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "시간")
                fee = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "수수료")
                tax = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "세금")

                code = code.strip()
                code_name = code_name.strip()
                order_number = str(int(order_number.strip()))
                order_status = order_status.strip()
                order_quantity = int(order_quantity.strip())
                order_price = int(order_price.strip())
                current_price = int(current_price.strip().lstrip('+').lstrip('-'))
                order_type = order_type.strip().lstrip('+').lstrip('-')
                left_quantity = int(left_quantity.strip())
                expected_quantity = int(expected_quantity.strip())
                ordered_at = ordered_at.strip()
                fee = int(fee)
                tax = int(tax)

                self.order[code] = {
                    '종목코드': code,
                    '종목명': code_name,
                    '주문번호': order_number,
                    '주문수량': order_quantity,
                    '주문가격': order_price,
                    '현재가': current_price,
                    '주문구분': order_type,
                    '미체결수량': left_quantity,
                    '체결량': excuted_quantity,
                    '주문시간': ordered_at,
                    '당일매매수수료': fee,
                    '당일매매세금': tax,
                }
            self.tr_data = self.order

        elif rqname == "opw00018_req":
            for i in range(tr_data_cnt):
                code = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "종목코드")
                code_name = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "종목명")
                quantity = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "보유수량")
                purchase_price = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "매입가")
                return_rate = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "수익률(%)")
                current_price = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "현재가")
                total_purchase_price = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "매입금액")
                available_quantity = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "매매가능수량")

                code = code.strip()[1:]
                code_name = code_name.strip()
                quantity = int(quantity)
                purchase_price = int(purchase_price)
                return_rate = float(return_rate)
                current_price = int(current_price)
                total_purchase_price = int(total_purchase_price)
                available_quantity = int(available_quantity)

                self.balance[code] = {
                    '종목명': code_name,
                    '보유수량': quantity,
                    '매입가': purchase_price,
                    '수익률': return_rate,
                    '현재가': current_price,
                    '매입금액': total_purchase_price,
                    '매매가능수량': available_quantity,
                }
            self.tr_data = self.balance



        elif rqname == "opt10059_req8":  # 수급 데이터 처리
            investor_data = {'date': [], '개인': [], '외국인': [], '기관': [], '연기금': []}

            for i in range(tr_data_cnt):
                date = self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "일자").strip()
                개인 = int(self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "개인투자자"))
                외국인 = int(self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "외국인투자자"))
                기관 = int(self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "기관투자자"))
                연기금 = int(self.dynamicCall("GetCommData(QString, QString, int, QString)", trcode, rqname, i, "연기금"))

                # 값이 빈


                investor_data['date'].append(date)
                investor_data['개인'].append(개인)
                investor_data['외국인'].append(외국인)
                investor_data['기관'].append(기관)
                investor_data['연기금'].append(연기금)

            self.tr_data = investor_data
            time.sleep(0.3)



        if rqname == "opt10059_req":
            investor_data = {'date': [], '개인': [], '외국인': [], '기관': [], '연기금': []}
            for i in range(tr_data_cnt):  # 최대 10개의 데이터를 가져오는 예시
                date = self.CommGetData(trcode, "", rqname, i, "일자")
                개인 = self.CommGetData(trcode, "", rqname, i, "개인투자자")
                외국인 = self.CommGetData(trcode, "", rqname, i, "외국인투자자")
                기관 = self.CommGetData(trcode, "", rqname, i, "기관계")
                연기금 = self.CommGetData(trcode, "", rqname, i, "연기금등")

                investor_data['date'].append(date)
                investor_data['개인'].append(개인)
                investor_data['외국인'].append(외국인)
                investor_data['기관'].append(기관)
                investor_data['연기금'].append(연기금)

            self.tr_data = investor_data
            time.sleep(0.3)






        self.tr_event_loop.exit()
        time.sleep(0.5)




    def _on_receive_msg(self, screen_no, rqname, trcode, msg):
        print("[tr_"+trcode + "] MSG: " + msg)

    def _on_chejan_slot(self, s_gubun, n_item_cnt, s_fid_list):
        print("[" + s_gubun + "] " + str(n_item_cnt) + " " + str(s_fid_list))

        for fid in s_fid_list.split(";"):
            if fid in FID_CODES:
                code = self.dynamicCall("GetChejanData(int)", '9001')[1:]
                data = self.dynamicCall("GetChejanFata(int)", fid)

                data = data.strip().lstrip('+').lstrip('-')
                if data.isdigit():
                    data = int(data)
                item_name = FID_CODES[fid]         # fid=9201 => 계좌번호
                print(item_name + ": " + data)   # 주문가격: 37,6000

                if int(s_gubun) == 0:   # 0이면 접수체결 self.order, 1이면 잔고이동 self.balance
                    if code not in self.order.keys():   # order에 종목이 없으면 신규 생성
                        self.order[code] = {}           # self.order['007700']   {'007700': {}}
                    self.order[code].update({item_name: data})   # {'주문상태':'접수'} => {'007700': {'주문상태':'접수'}}   {'007700': {'주문상태':'체결'}}
                elif int(s_gubun) == 1:
                    if code not in self.balance.keys(): # balance에 종목이 없으면 신규 생성
                        self.balance[code] = {}
                    self.balance[code].update({item_name: data})
            if int(s_gubun)==0:
                print("* 주문출력(self.order)")
                print(self.order)
            elif int(s_gubun)==1:
                print("* 잔고출력(self.balance)")
                print(self.balance)


    def _on_receive_real_data(self, s_code, real_type, real_data):
        if real_type == "장시작시간":
            pass
        if real_data == "주식체결":
            signed_at = self.dynamicCall("GetCommRealData(QString, int)", s_code, get_fid("체결시간"))
            close = self.dynamicCall("GetCommRealData(QString, int)", s_code, get_fid("현재가"))
            close = absent(int(close))
            close = self.dynamicCall("GetCommRealData(QString, int)", s_code, get_fid("현재가"))
            close = absent(int(close))

            high = self.dynamicCall("GetCommRealData(QString, int)", s_code, get_fid("고가"))
            high = abs(int(high))

            open = self.dynamicCall("GetCommRealData(QString, int)", s_code, get_fid("시가"))
            open = abs(int(open))

            low = self.dynamicCall("GetCommRealData(QString, int)", s_code, get_fid("저가"))
            low = abs(int(low))

            top_priority_ask = self.dynamicCall("GetCommRealData(QString, int)", s_code, get_fid("(최우선)매도호가"))
            top_priority_ask = abs(int(top_priority_ask))

            top_priority_bid = self.dynamicCall("GetCommRealData(QString, int)", s_code, get_fid("(최우선)매수호가"))
            top_priority_bid = abs(int(top_priority_bid))

            accum_volume = self.dynamicCall("GetCommRealData(QString, int)", s_code, get_fid("누적거래량"))
            accum_volume = abs(int(accum_volume))

            print(s_code, signed_at, close, high, open, low, top_priority_ask, top_priority_bid, accum_volume)

            if s_code not in self.universe_realtime_transaction_info:
                self.universe_realtime_transaction_info.update({s_code:{}})

            self.universe_realtime_transaction_info[s_code].update({
                "체결시간":signed_at,
                "시가":open,
                "고가":high,
                "저가":low,
                "현재가":close,
                "(최우선)매도호가":top_priority_ask,
                "(최우선)매수호가":top_priority_bid,
                "누적거래량":accum_volume,
            })



















    def get_account_number(self, tag="ACCNO"):
        account_list = self.dynamicCall("GetLoginInfo(QString)", tag)
        account_number = account_list.split(';')[0]
        print(account_number)
        return account_number

    def get_code_list_by_market(self, market_type):   # "0" 코스피      "10" 코스닥
        code_list = self.dynamicCall("GetCodeListByMarket(QString)", market_type)
        code_list = code_list.split(';')[:-1]
        return code_list

    def get_master_code_name(self, code):
        code_name = self.dynamicCall("GetMasterCodeName(QString)", code)
        return code_name







    def set_price(self, code):

        # 일봉
        self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)
        self.dynamicCall("SetInputValue(QString, QString)", "수정주가구분", "1")
        self.dynamicCall("CommRqData(QString, QString, int, QString)", "opt10081_req", "opt10081", 0, "0001")
        self.tr_event_loop.exec_()

        ohlcv = self.tr_data
        df_ohlcv = pd.DataFrame(ohlcv, columns=['open', 'high', 'low', 'close', 'volume'], index=ohlcv['date'])



        # print(df_ohlcv)



        # df_ohlcv = df_ohlcv[:300]

        # 5일 이동평균선
        df_ohlcv['a5'] = 0
        for i in range(0, len(df_ohlcv['a5'])-5+1):
            df_ohlcv.loc[df_ohlcv.index[i], 'a5'] = df_ohlcv['close'][i:5+i].mean()

        # 20일 이동평균선
        df_ohlcv['a20'] = 0
        for i in range(0, len(df_ohlcv['a20'])-20+1):
            df_ohlcv.loc[df_ohlcv.index[i], 'a20'] = df_ohlcv['close'][i:20+i].mean()

        # 60일 이동평균선
        df_ohlcv['a60'] = 0
        for i in range(0, len(df_ohlcv['a60'])-60+1):
            df_ohlcv.loc[df_ohlcv.index[i], 'a60'] = df_ohlcv['close'][i:60+i].mean()

        # 120일 이동평균선
        df_ohlcv['a120'] = 0
        for i in range(0, len(df_ohlcv['a120'])-120+1):
            df_ohlcv.loc[df_ohlcv.index[i], 'a120'] = df_ohlcv['close'][i:120+i].mean()


        # print(df_ohlcv)


        # RSI
        delta = df_ohlcv['close'] - df_ohlcv['close'].shift(-1)

        df_ohlcv['u'] = delta.apply(lambda x: x if x > 0 else 0)
        df_ohlcv['d'] = delta.apply(lambda x: x*(-1) if x < 0 else 0)

        df_ohlcv['au'] = pd.Series([0] * len(df_ohlcv), index=df_ohlcv.index)
        df_ohlcv['ad'] = pd.Series([0] * len(df_ohlcv), index=df_ohlcv.index)

        N = 14

        df_ohlcv.loc[df_ohlcv.index[len(df_ohlcv['au']) - N - 1], 'au'] = df_ohlcv['u'][len(df_ohlcv['u']) - N: len(df_ohlcv['u'])].mean()
        df_ohlcv.loc[df_ohlcv.index[len(df_ohlcv['ad']) - N - 1], 'ad'] = df_ohlcv['d'][len(df_ohlcv['d']) - N: len(df_ohlcv['d'])].mean()

        for i in range(2, len(df_ohlcv['au']) - N + 1):
            current_index = df_ohlcv.index[len(df_ohlcv['au']) - N - i]
            next_index = df_ohlcv.index[len(df_ohlcv['au']) - N - i + 1]
            df_ohlcv.loc[current_index, 'au'] = ((df_ohlcv.loc[next_index, 'au'] * (N - 1)) + df_ohlcv['u'].iloc[len(df_ohlcv['au']) - N - i]) / N

        for i in range(2, len(df_ohlcv['ad']) - N + 1):
            current_index = df_ohlcv.index[len(df_ohlcv['ad']) - N - i]
            next_index = df_ohlcv.index[len(df_ohlcv['ad']) - N - i + 1]
            df_ohlcv.loc[current_index, 'ad'] = ((df_ohlcv.loc[next_index, 'ad'] * (N - 1)) + df_ohlcv['d'].iloc[len(df_ohlcv['ad']) - N - i]) / N

        df_ohlcv['rsi'] = (df_ohlcv['au'] * 100) / (df_ohlcv['au'] + df_ohlcv['ad'])

        df_ohlcv['rsi9'] = 0
        for i in range(0, len(df_ohlcv['rsi9'])-9+1):
            df_ohlcv.loc[df_ohlcv.index[i], 'rsi9'] = df_ohlcv['rsi'][i:9+i].mean()


        # MACD (EMA12-EMA26)
        df_ohlcv['ema12'] = pd.Series([0] * len(df_ohlcv), index=df_ohlcv.index)
        N = 12
        df_ohlcv.loc[df_ohlcv.index[len(df_ohlcv)-N], 'ema12'] = df_ohlcv['close'].iloc[len(df_ohlcv['close']) - N: len(df_ohlcv['close'])].mean()
        for i in range(1, len(df_ohlcv['ema12'])-N+1):
            df_ohlcv.loc[df_ohlcv.index[len(df_ohlcv)-N-i], 'ema12'] = (df_ohlcv['close'].iloc[len(df_ohlcv['ema12'])-N-i] * (2/(N+1))) + (df_ohlcv['ema12'].iloc[len(df_ohlcv['ema12'])-N-i+1] * (1-(2/(N+1))))

        df_ohlcv['ema26'] = pd.Series([0] * len(df_ohlcv), index=df_ohlcv.index)
        N = 26
        df_ohlcv.loc[df_ohlcv.index[len(df_ohlcv)-N], 'ema26'] = df_ohlcv['close'].iloc[len(df_ohlcv['close']) - N: len(df_ohlcv['close'])].mean()
        for i in range(1, len(df_ohlcv['ema26'])-N+1):
            df_ohlcv.loc[df_ohlcv.index[len(df_ohlcv)-N-i], 'ema26'] = (df_ohlcv['close'].iloc[len(df_ohlcv['ema26'])-N-i] * (2/(N+1))) + (df_ohlcv['ema26'].iloc[len(df_ohlcv['ema26'])-N-i+1] * (1-(2/(N+1))))

        df_ohlcv['macd'] = df_ohlcv['ema12'] - df_ohlcv['ema26']


        # MACD9
        df_ohlcv['macd9'] = pd.Series([0] * len(df_ohlcv), index=df_ohlcv.index)
        N = 9
        df_ohlcv.loc[df_ohlcv.index[len(df_ohlcv)-N], 'macd9'] = df_ohlcv['macd'].iloc[len(df_ohlcv['macd']) - N: len(df_ohlcv['macd'])].mean()
        for i in range(1, len(df_ohlcv['macd9'])-N+1):
            df_ohlcv.loc[df_ohlcv.index[len(df_ohlcv)-N-i], 'macd9'] = (df_ohlcv['macd'].iloc[len(df_ohlcv['macd9'])-N-i] * (2/(N+1))) + (df_ohlcv['macd9'].iloc[len(df_ohlcv['macd'])-N-i+1] * (1-(2/(N+1))))
        

        # 볼린저밴드
        stddev_20 = df_ohlcv['close'][::-1].rolling(window=20).std()
        df_ohlcv['bol_u'] = df_ohlcv['a20'] + stddev_20*2
        df_ohlcv['bol_l'] = df_ohlcv['a20'] - stddev_20*2
        bol_mean = (df_ohlcv['bol_u']-df_ohlcv['bol_l']).mean()
        df_ohlcv['bol_size'] = (df_ohlcv['bol_u'] - df_ohlcv['bol_l']).apply(lambda x: 'Big' if x > bol_mean*(1.5) else 'Small')
        df_ohlcv['bol_dolpa'] = [
            '상향돌파' if close > bol_u else ('하향돌파' if close < bol_l else '보통')
            for close, bol_u, bol_l in zip(df_ohlcv['close'], df_ohlcv['bol_u'], df_ohlcv['bol_l'])
        ]

        # 일목균형표
        high_26 = df_ohlcv['high'][::-1].rolling(window=26).max()[::-1]
        low_26 = df_ohlcv['low'][::-1].rolling(window=26).min()[::-1]
        kijun = (high_26 + low_26) / 2

        high_9 = df_ohlcv['high'][::-1].rolling(window=9).max()[::-1]
        low_9 = df_ohlcv['low'][::-1].rolling(window=9).min()[::-1]
        tenkan = (high_9 + low_9) / 2

        df_ohlcv['ilmok_a'] = ((kijun+tenkan) / 2).shift(-26+1)


        high_52 = df_ohlcv['high'][::-1].rolling(window=52).max()[::-1]
        low_52 = df_ohlcv['low'][::-1].rolling(window=52).min()[::-1]
        df_ohlcv['ilmok_b'] = ((high_52 + low_52) / 2).shift(-26+1)

        df_ohlcv['ilmok_dolpa'] = "?"
        df_ohlcv['ilmok_dolpa'] = np.where(
            (df_ohlcv['high'] > df_ohlcv['ilmok_a']) & (df_ohlcv['high'] > df_ohlcv['ilmok_b']),
            "상향돌파",
            np.where(
                (df_ohlcv['low'] < df_ohlcv['ilmok_a']) & (df_ohlcv['low'] < df_ohlcv['ilmok_b']),
                "하향돌파",
                np.where(
                    ((df_ohlcv['low'] > df_ohlcv['ilmok_a']) & (df_ohlcv['low'] < df_ohlcv['ilmok_b'])) | ((df_ohlcv['low'] < df_ohlcv['ilmok_a']) & (df_ohlcv['low'] > df_ohlcv['ilmok_b'])) | ((df_ohlcv['high'] > df_ohlcv['ilmok_a']) & (df_ohlcv['high'] < df_ohlcv['ilmok_b'])) | ((df_ohlcv['high'] < df_ohlcv['ilmok_a']) & (df_ohlcv['high'] > df_ohlcv['ilmok_b'])),
                    "구름내부",
                    "?"
                )
            )
        )

        df_ohlcv['ilmok_yang'] = [
            '양운' if a > b else '음운'
            for a, b in zip(df_ohlcv['ilmok_a'], df_ohlcv['ilmok_b'])
        ]

        # 개인, 외국인, 기관 수급
        list_day = []
        for i in range(0, min(len(df_ohlcv), 300), 100):  # 최대 300까지만
        # for i in range(0, 100*3, 100):
            list_day.append(df_ohlcv.iloc[i].name)

        dic_day = { 'date': [] }

        for i in range(3):  # 0부터 5까지 (총 6회)
            date_range = df_ohlcv.index[i * 100:(i + 1) * 100].tolist()
            dic_day['date'].extend(date_range)  # 리스트에 추가

        investor_data_list = []

        investor_data_dict = {'date': [], '개인': [], '외국인': [], '기관': [], '연기금': []}
        for date in list_day:
            self.dynamicCall("SetInputValue(QString, QString)", "일자", date)  # YYYYMMDD 형식의 날짜
            self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)  # 종목 코드
            self.dynamicCall("SetInputValue(QString, QString)", "금액수량구분", "2")  # 수량 기준 요청
            self.dynamicCall("SetInputValue(QString, QString)", "매매구분", "0")  # 순매수
            self.dynamicCall("SetInputValue(QString, QString)", "단위구분", "1")  # 단주
            self.dynamicCall("CommRqData(QString, QString, int, QString)", "opt10059_req", "opt10059", 0, "1001")


            self.tr_event_loop.exec_()

            개인_data = self.tr_data.get('개인', 0)  # '개인' 키로 데이터 추출
            외국인_data = self.tr_data.get('외국인', 0)  # '기관' 키로 데이터 추출
            기관_data = self.tr_data.get('기관', 0)  # '기관' 키로 데이터 추출
            연기금_data = self.tr_data.get('연기금', 0)  # '연기금' 키로 데이터 추출

            investor_data_dict['개인'].extend(개인_data)  # 개인 데이터 추가
            investor_data_dict['외국인'].extend(외국인_data)  # 개인 데이터 추가
            investor_data_dict['기관'].extend(기관_data)  # 기관 데이터 추가
            investor_data_dict['연기금'].extend(연기금_data)  # 연기금 데이터 추가

        investor_data_dict['date'].extend(dic_day['date'])  # 날짜 추가

        df_investor = pd.DataFrame(investor_data_dict)
        df_investor.set_index('date', inplace=True)
        df_ohlcv = pd.concat([df_ohlcv, df_investor], axis=1)

        insert_df_to_db(code, df_ohlcv)

        return





    def set_price_1day(self, code, recent_day, df_recent):

        df_1day = get_db_1day(code)
        df_1day = pd.concat([df_recent, df_1day])

        # 결과 확인
        df_1day.loc[df_1day.index[0], 'a5'] = df_1day['close'].iloc[:5].mean()
        df_1day.loc[df_1day.index[0], 'a20'] = df_1day['close'].iloc[:20].mean()
        df_1day.loc[df_1day.index[0], 'a60'] = df_1day['close'].iloc[:60].mean()
        df_1day.loc[df_1day.index[0], 'a120'] = df_1day['close'].iloc[:120].mean()

        # RSI
        delta = df_1day['close'][0] - df_1day['close'][1]
        df_1day.loc[df_1day.index[0], 'u'] = max(delta, 0)
        df_1day.loc[df_1day.index[0], 'd'] = max(-delta, 0)

        N = 14
        df_1day.loc[df_1day.index[0], 'au'] = ((df_1day.loc[df_1day.index[1], 'au'] * (N - 1)) + df_1day['u'].iloc[0]) / N
        df_1day.loc[df_1day.index[0], 'ad'] = ((df_1day.loc[df_1day.index[1], 'ad'] * (N - 1)) + df_1day['d'].iloc[0]) / N
        df_1day.loc[df_1day.index[0], 'rsi'] = (df_1day['au'][0] * 100) / (df_1day['au'][0] + df_1day['ad'][0])

        N = 9
        df_1day.loc[df_1day.index[0], 'rsi9'] = df_1day['rsi'][:9].mean()



        # MACD (EMA12-EMA26)
        N = 12
        df_1day.loc[df_1day.index[0], 'ema12'] = (df_1day['close'].iloc[0] * (2 / (N + 1))) + (df_1day['ema12'].iloc[1] * (1 - (2 / (N + 1))))
        N = 26
        df_1day.loc[df_1day.index[0], 'ema26'] = (df_1day['close'].iloc[0] * (2 / (N + 1))) + (df_1day['ema26'].iloc[1] * (1 - (2 / (N + 1))))
        df_1day.loc[df_1day.index[0], 'macd'] = df_1day['ema12'][0] - df_1day['ema26'][0]

        # MACD9 계산
        N = 9
        df_1day.loc[df_1day.index[0], 'macd9'] = df_1day.loc[df_1day.index[0], 'macd'] * (2/(N+1)) + df_1day['macd9'].iloc[1] * (1 - 2/(N+1))





        # 볼린저밴드
        stddev_20 = df_1day['close'][::-1].rolling(window=20).std()

        df_1day.loc[df_1day.index[0], 'bol_u'] = df_1day.loc[df_1day.index[0], 'a20'] + stddev_20[len(stddev_20)-1] * 2
        df_1day.loc[df_1day.index[0], 'bol_l'] = df_1day.loc[df_1day.index[0], 'a20'] - stddev_20[len(stddev_20)-1] * 2

        bol_mean = (df_1day['bol_u'][0] - df_1day['bol_l'][0]).mean()

        if (df_1day['bol_u'][0] - df_1day['bol_l'][0]) > bol_mean * (1.5):
            df_1day.loc[df_1day.index[0], 'bol_size'] = "Big"
        else:
            df_1day.loc[df_1day.index[0], 'bol_size'] = "small"

        if df_1day['close'][0] > df_1day['bol_u'][0]:
            df_1day.loc[df_1day.index[0], 'bol_dolpa'] = "상향돌파"
        elif df_1day['close'][0] < df_1day['bol_l'][0]:
            df_1day.loc[df_1day.index[0], 'bol_dolpa'] = "하향돌파"
        else:
            df_1day.loc[df_1day.index[0], 'bol_dolpa'] = "보통"

        # 일목균형표
        high_26 = df_1day['high'][::-1].rolling(window=26).max()[::-1][26-1]
        low_26 = df_1day['low'][::-1].rolling(window=26).min()[::-1][26-1]
        kijun = (high_26 + low_26) / 2

        high_9 = df_1day['high'][::-1].rolling(window=9).max()[::-1][26-1]
        low_9 = df_1day['low'][::-1].rolling(window=9).min()[::-1][26-1]
        tenkan = (high_9 + low_9) / 2
        df_1day.loc[df_1day.index[0], 'ilmok_a'] = (kijun + tenkan) / 2

        high_52 = df_1day['high'][::-1].rolling(window=52).max()[::-1][26-1]
        low_52 = df_1day['low'][::-1].rolling(window=52).min()[::-1][26-1]
        df_1day.loc[df_1day.index[0], 'ilmok_b'] = (high_52 + low_52) / 2


        if (df_1day['high'][0] > df_1day['ilmok_a'][0]) & (df_1day['high'][0] > df_1day['ilmok_b'][0]):
            df_1day.loc[df_1day.index[0], 'ilmok_dolpa'] = "상향돌파"
        elif (df_1day['low'][0] < df_1day['ilmok_a'][0]) & (df_1day['low'][0] < df_1day['ilmok_b'][0]):
            df_1day.loc[df_1day.index[0], 'ilmok_dolpa'] = "하향돌파"
        elif ((df_1day['low'][0] > df_1day['ilmok_a'][0]) & (df_1day['low'][0] < df_1day['ilmok_b'][0])) | ((df_1day['low'][0] < df_1day['ilmok_a'][0]) & (df_1day['low'][0] > df_1day['ilmok_b'][0])) | ((df_1day['high'][0] > df_1day['ilmok_a'][0]) & (df_1day['high'][0] < df_1day['ilmok_b'][0])) | ((df_1day['high'][0] < df_1day['ilmok_a'][0]) & (df_1day['high'][0] > df_1day['ilmok_b'][0])):
            df_1day.loc[df_1day.index[0], 'ilmok_dolpa'] = "구름내부"
        else:
            df_1day.loc[df_1day.index[0], 'ilmok_dolpa'] = "?"

        if df_1day['ilmok_a'][0] > df_1day['ilmok_b'][0]:
            df_1day.loc[df_1day.index[0], 'ilmok_yang'] = "양운"
        else:
            df_1day.loc[df_1day.index[0], 'ilmok_yang'] = "음운"


        '''
        self.dynamicCall("SetInputValue(QString, QString)", "일자", recent_day)  # YYYYMMDD 형식의 날짜
        self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)  # 종목 코드
        self.dynamicCall("SetInputValue(QString, QString)", "금액수량구분", "2")  # 수량 기준 요청
        self.dynamicCall("SetInputValue(QString, QString)", "매매구분", "0")  # 순매수
        self.dynamicCall("SetInputValue(QString, QString)", "단위구분", "1")  # 단주
        self.dynamicCall("CommRqData(QString, QString, int, QString)", "opt10059_req", "opt10059", 0, "1001")

        self.tr_event_loop.exec_()

        df_1day.loc[df_1day.index[0], '개인'] = self.tr_data.get('개인', 0)[0]
        df_1day.loc[df_1day.index[0], '외국인'] = self.tr_data.get('외국인', 0)[0]
        df_1day.loc[df_1day.index[0], '기관'] = self.tr_data.get('기관', 0)[0]
        df_1day.loc[df_1day.index[0], '연기금'] = self.tr_data.get('연기금', 0)[0]
        '''



        df_1day.loc[df_1day.index[0], '개인'] = 0
        df_1day.loc[df_1day.index[0], '외국인'] = 0
        df_1day.loc[df_1day.index[0], '기관'] = 0
        df_1day.loc[df_1day.index[0], '연기금'] = 0



        with sqlite3.connect('stock.db') as con:
            df_1day.to_sql(code, con, if_exists="replace", index=True, index_label="date")
        return




















    def set_days(self, code):

        self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)
        self.dynamicCall("SetInputValue(QString, QString)", "수정주가구분", "1")
        self.dynamicCall("CommRqData(QString, QStrimg, int, QString)", "opt10081_req", "opt10081", 0, "0001")
        self.tr_event_loop.exec_()
        ohlcv = self.tr_data
        df_ohlcv = pd.DataFrame(ohlcv, columns=['open', 'high', 'low', 'close', 'volume'], index=ohlcv['date'])

        recent_list = [date for date in df_ohlcv.index.tolist() if date > min(get_db_day(code), datetime.now().strftime("%Y%m%d"))]

        if len(recent_list) == 0:
            return


        if datetime.now().strftime("%Y%m%d") == recent_list[0] and recent_list[0] == get_db_recent_day():
            print("DB 최근 1Day 삭제")
            delete_db_1day(code, datetime.now().strftime("%Y%m%d"))



        df_ohlcv = df_ohlcv[:len(recent_list)]
        df_db = get_db(code)

        missing_columns = [col for col in df_db.columns if col not in df_ohlcv.columns]   # a5, a20, a60, ~ ,연기금
        for col in missing_columns:
            df_ohlcv[col] = pd.NA

        df_combined = pd.concat([df_ohlcv, df_db], axis=0)


        for i in range(len(recent_list)):   # 5일 이동평균선
            df_combined.loc[df_combined.index[len(recent_list)-i-1],'a5'] = df_combined['close'][(len(recent_list)-i-1):(len(recent_list)-i-1)+5].mean()

        for i in range(len(recent_list)):   # 20일 이동평균선
            df_combined.loc[df_combined.index[len(recent_list)-i-1],'a20'] = df_combined['close'][(len(recent_list)-i-1):(len(recent_list)-i-1)+20].mean()

        for i in range(len(recent_list)):   # 60일 이동평균선
            df_combined.loc[df_combined.index[len(recent_list)-i-1],'a60'] = df_combined['close'][(len(recent_list)-i-1):(len(recent_list)-i-1)+60].mean()

        for i in range(len(recent_list)):   # 120일 이동평균선
            df_combined.loc[df_combined.index[len(recent_list)-i-1],'a120'] = df_combined['close'][(len(recent_list)-i-1):(len(recent_list)-i-1)+120].mean()





        # RSI
        N = 14
        list_delta = [
            df_combined['close'][i] - df_combined['close'][i+1]
            for i in range(300-1)
        ]
        df_delta = pd.DataFrame(list_delta, index=df_combined.index[:len(list_delta)], columns=['delta'])


        df_combined['u'] = df_delta['delta'].apply(lambda x: x if x > 0 else 0)
        df_combined['d'] = df_delta['delta'].apply(lambda x: x*(-1) if x < 0 else 0)

        for i in range(len(recent_list)+1):
            df_combined.loc[df_combined.index[len(recent_list) - i], "au"] = ((df_combined['au'][len(recent_list) - i +1] * (N-1)) + df_combined['u'].iloc[len(recent_list) - i]) / N
        for i in range(len(recent_list)+1):
            df_combined.loc[df_combined.index[len(recent_list) - i], "ad"] = ((df_combined['ad'][len(recent_list) - i +1] * (N-1)) + df_combined['d'].iloc[len(recent_list) - i]) / N


        df_combined['ad'] = pd.to_numeric(df_combined['ad'], errors='coerce')
        df_combined['rsi'] = 0

        # 조건에 따라 rsi 계산
        for i in range(len(df_combined)):
            if (df_combined['au'][i] + df_combined['ad'][i]) > 1:
                df_combined.loc[df_combined.index[i], 'rsi'] = (df_combined['au'].iloc[i] * 100) / (df_combined['au'][i]+df_combined['ad'][i])
            else:
                df_combined.loc[df_combined.index[i], 'rsi'] = 0

        # RSI 9
        for i in range(0, len(df_combined['rsi9'])-9+1):
            df_combined.loc[df_combined.index[i], 'rsi9'] = df_combined['rsi'][i:9+i].mean()



        # MACD (EMA12-EMA26)
        N = 12
        for i in range(len(recent_list)):
            df_combined.loc[df_combined.index[len(recent_list)-1 - i], "ema12"] = (df_combined['close'][len(recent_list)-1 - i] * (2/(N+1))) + (df_combined['ema12'][len(recent_list)-1 - i+1] * (1-(2/(N+1))))
        N = 26
        for i in range(len(recent_list)):
            df_combined.loc[df_combined.index[len(recent_list)-1 - i], "ema26"] = (df_combined['close'][len(recent_list)-1 - i] * (2/(N+1))) + (df_combined['ema26'][len(recent_list)-1 - i+1] * (1-(2/(N+1))))

        df_combined['macd'] = df_combined['ema12'] - df_combined['ema26']




        # 볼린저밴드
        for i in range(len(recent_list)):
            stddev_20 = df_combined['close'][len(recent_list)-1-i:len(recent_list)-1-i+20].std()
            df_combined.loc[df_combined.index[len(recent_list) - 1 - i], 'bol_u'] = df_combined['a20'].loc[df_combined.index[len(recent_list) - 1 - i]] + stddev_20 * 2
            df_combined.loc[df_combined.index[len(recent_list) - 1 - i], 'bol_l'] = df_combined['a20'].loc[df_combined.index[len(recent_list) - 1 - i]] - stddev_20 * 2
            bol_mean = (df_combined['bol_u'][len(recent_list) - 1 - i] - df_combined['bol_l'][len(recent_list) - 1 - i]).mean()

            diff = df_combined['bol_u'][len(recent_list) - 1 - i] - df_combined['bol_l'][len(recent_list) - 1 - i]
            df_combined.loc[df_combined.index[len(recent_list) - 1 - i], 'bol_size'] = 'Big' if diff > bol_mean * 1.5 else 'Small'

            if df_combined['close'][len(recent_list) - 1 - i] > df_combined['bol_u'][len(recent_list) - 1 - i]:
                df_combined.loc[df_combined.index[len(recent_list) - 1 - i], 'bol_dolpa'] = "상향돌파"
            elif df_combined['close'][len(recent_list) - 1 - i] < df_combined['bol_l'][len(recent_list) - 1 - i]:
                df_combined.loc[df_combined.index[len(recent_list) - 1 - i], 'bol_dolpa'] = "하향돌파"
            else:
                df_combined.loc[df_combined.index[len(recent_list) - 1 - i], 'bol_dolpa'] = "보통"





        # 일목균형표
        for i in range(len(recent_list),0,-1):
            high_26 = df_combined['high'].iloc[i-2+26:i-2+26+26].max()  # i일 기준으로 최근 26일 중 가장 큰 high 값
            low_26 = df_combined['low'].iloc[i-2+26:i-2+26+26].min()
            kijun = (high_26 + low_26) / 2


            high_9 = df_combined['high'].iloc[i-2+26:i-2+26+9].max()  # i일 기준으로 최근 26일 중 가장 큰 high 값
            low_9 = df_combined['low'].iloc[i-2+26:i-2+26+9].min()
            tenkan = (high_9 + low_9) / 2

            df_combined.loc[df_combined.index[i-1], 'ilmok_a'] = ((kijun+tenkan) / 2)


            high_52 = df_combined['high'].iloc[i - 2 + 26:i - 2 + 26 + 52].max()  # i일 기준으로 최근 26일 중 가장 큰 high 값
            low_52 = df_combined['low'].iloc[i - 2 + 26:i - 2 + 26 + 52].min()  # i일 기준으로 최근 26일 중 가장 큰 high 값
            df_combined.loc[df_combined.index[i - 1], 'ilmok_b'] = ((high_52 + low_52) / 2)

            df_combined.loc[df_combined.index[i - 1], 'ilmok_dolpa'] = "?"

            df_combined.loc[df_combined.index[i - 1], 'ilmok_dolpa'] = str(np.where(
                (df_combined['high'][i - 1] > df_combined['ilmok_a'][i - 1]) & (df_combined['high'][i - 1] > df_combined['ilmok_b'][i - 1]),
                "상향돌파",
                np.where(
                    (df_combined['low'][i - 1] < df_combined['ilmok_a'][i - 1]) & (df_combined['low'][i - 1] < df_combined['ilmok_b'][i - 1]),
                    "하향돌파",
                    np.where(
                        ((df_combined['low'][i - 1] > df_combined['ilmok_a'][i - 1]) & (
                                    df_combined['low'][i - 1] < df_combined['ilmok_b'][i - 1])) | (
                                    (df_combined['low'][i - 1] < df_combined['ilmok_a'][i - 1]) & (
                                        df_combined['low'][i - 1] > df_combined['ilmok_b'][i - 1])) | (
                                    (df_combined['high'][i - 1] > df_combined['ilmok_a'][i - 1]) & (
                                        df_combined['high'][i - 1] < df_combined['ilmok_b'][i - 1])) | (
                                    (df_combined['high'][i - 1] < df_combined['ilmok_a'][i - 1]) & (
                                        df_combined['high'][i - 1] > df_combined['ilmok_b'][i - 1])),
                        "구름내부",
                        "?"
                    )
                )
            ))

            if df_combined['ilmok_a'][i - 1] > df_combined['ilmok_b'][i - 1]:
                df_combined.loc[df_combined.index[i-1], 'ilmok_yang'] = "양운"
            else:
                df_combined.loc[df_combined.index[i-1], 'ilmok_yang'] = "음운"




        # 개인, 외국인, 기관 수급
        recent_list.reverse()

        i=0
        for date in recent_list:
            self.dynamicCall("SetInputValue(QString, QString)", "일자", date)  # YYYYMMDD 형식의 날짜
            self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)  # 종목 코드
            self.dynamicCall("SetInputValue(QString, QString)", "금액수량구분", "2")  # 수량 기준 요청
            self.dynamicCall("SetInputValue(QString, QString)", "매매구분", "0")  # 순매수
            self.dynamicCall("SetInputValue(QString, QString)", "단위구분", "1")  # 단주
            self.dynamicCall("CommRqData(QString, QString, int, QString)", "opt10059_req", "opt10059", 0, "1001")
            self.tr_event_loop.exec_()

            df_combined.loc[df_combined.index[len(recent_list) - 1 - i], "개인"] = self.tr_data.get('개인', 0)[0]
            df_combined.loc[df_combined.index[len(recent_list) - 1 - i], "외국인"] = self.tr_data.get('외국인', 0)[0]
            df_combined.loc[df_combined.index[len(recent_list) - 1 - i], "기관"] = self.tr_data.get('기관', 0)[0]
            df_combined.loc[df_combined.index[len(recent_list) - 1 - i], "연기금"] = self.tr_data.get('연기금', 0)[0]
            i = i+1

        insert_df_to_db(code, df_combined)
        return

















    def get_deposit(self):
        self.dynamicCall("SetInputValue(QString, QString)", "계좌번호", self.account_number)
        self.dynamicCall("SetInputValue(QString, QString)", "비밀번호입력매체구분", "00")
        self.dynamicCall("SetInputValue(QString, QString)", "조회구분", "2")
        self.dynamicCall("CommRqData(QString, QString, int, QString)", "opw00001_req", "opw00001", 0, "0002")
        self.tr_event_loop.exec_()
        return self.tr_data

    def send_order(self, rqname, screen_no, order_type, code, order_quantity, order_price, order_classification, origin_order_number=""):
        order_result = self.dynamicCall("SendOrder(QString, QString, QString, int, QString, int, int, QString, QString", [rqname, screen_no, self.account_number, order_type, code, order_quantity, order_price, order_classification, origin_order_number])
        return order_result



    def get_order(self):
        self.dynamicCall("SetInputValue(QString, QString)", "계좌번호", self.account_number)
        self.dynamicCall("SetInputValue(QString, QString)", "전체종목구분", "0")
        self.dynamicCall("SetInputValue(QString, QString)", "체결구분", "0")   # 0:전체, 1:미체결, 2:체결
        self.dynamicCall("SetInputValue(QString, QString)", "매매구분", "0")   # 0:전체, 1:매도, 2: 매수
        self.dynamicCall("CommRqData(QString, QString, int, QString)", "opt10075_req", "opt10075", 0, "0002")
        self.tr_event_loop.exec_()
        return self.tr_data


    def get_balance(self):
        self.dynamicCall("SetInputValue(QString, QString)", "계좌번호", self.account_number)
        self.dynamicCall("SetInputValue(QString, QString)", "비밀번호입력매체구분", "00")
        self.dynamicCall("SetInputValue(QString, QString)", "조회구분", "1")
        self.dynamicCall("CommRqData(QString, QString, int, QString)", "opw00018_req", "opw00018", 0, "0002")
        self.tr_event_loop.exec_()
        return self.tr_data


    def set_real_reg(self, str_screen_no, str_code_list, str_fid_list, str_opt_type):
        self.dynamicCall("SetRealReg(QString, QString, QString, QString)", "계좌번호", str_screen_no, str_code_list, str_fid_list, str_opt_type)
        time.sleep(0.5)













