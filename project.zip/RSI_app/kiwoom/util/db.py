import sqlite3
import pandas as pd
import os



base_dir = os.path.dirname(os.path.abspath(__file__))  # util/
db_path = os.path.abspath(os.path.join(base_dir, '..', 'stock.db'))

def get_ilbong_data(key: str):
    with sqlite3.connect(db_path) as conn:
        cur = conn.cursor()

        # 코드 판별
        if key.isdigit() and len(key) == 6:
            code = key
        else:
            cur.execute("SELECT 코드 FROM KOSPI_ALL WHERE 종목명 = ?", (key,))
            row = cur.fetchone()
            if row is None:
                raise ValueError(f"종목명을 찾을 수 없습니다: {key}")
            code = row[0]

        # 일봉 데이터 조회
        query = f"""
        SELECT
            date,
            (SELECT 종목명 FROM KOSPI_ALL WHERE 코드 = ?) AS 종목명,
            open, high, low, close, volume,
            a5, a20, a60, a120,
            rsi, rsi9, ema26, macd, macd9,
            bol_u, bol_l, bol_size, bol_dolpa,
            ilmok_a, ilmok_b, ilmok_dolpa, ilmok_yang,
            개인, 외국인, 기관, 연기금
        FROM "{code}"
        """
        df = pd.read_sql_query(query, conn, params=(code,))
        return df

def get_basic_data(key: str):
    with sqlite3.connect(db_path) as conn:
        cur = conn.cursor()

        # 코드 판별
        if key.isdigit() and len(key) == 6:
            code = key
        else:
            cur.execute("SELECT 코드 FROM KOSPI_ALL WHERE 종목명 = ?", (key,))
            row = cur.fetchone()
            if row is None:
                raise ValueError(f"종목명을 찾을 수 없습니다: {key}")
            code = row[0]

        # 일봉 데이터 조회
        query = f"""
        SELECT
            코드, 종목명, 시가총액 as 시총, 매출, 영업이익, 배당금, 외국인, PER, 시장, 순위
        FROM KOSPI_ALL
        WHERE 코드 = "{code}"
        """
        df = pd.read_sql_query(query, conn)
        return df






def insert_df_to_db(table, df):
    with sqlite3.connect(db_path) as conn:
        temp_table = f"{table}_temp"
        df.to_sql(temp_table, conn, if_exists="replace", index=True, index_label="date")

        cur = conn.cursor()

        # 기존 테이블 없으면 생성
        cur.execute(f'SELECT name FROM sqlite_master WHERE type="table" AND name="{table}"')
        if not cur.fetchone():
            df.head(0).to_sql(table, conn, if_exists="replace", index=True, index_label="date")
            cur.execute(f'CREATE UNIQUE INDEX IF NOT EXISTS idx_{table}_date ON "{table}" (date)')

        # 기존 테이블에서 TEMP에 없는 날짜만 가져와 TEMP에 추가
        col_names = list(df.columns)
        col_str = ", ".join(col_names)
        cur.execute(f'''
            INSERT INTO "{temp_table}" (date, {col_str})
            SELECT date, {col_str} FROM "{table}"
            WHERE date NOT IN (SELECT date FROM "{temp_table}")
        ''')


        # 기존 테이블 전체 삭제
        cur.execute(f'DELETE FROM "{table}"')

        # TEMP 데이터를 다시 원본 테이블에 삽입
        cur.execute(f'''
            INSERT INTO "{table}" (date, {col_str})
            SELECT date, {col_str} FROM "{temp_table}"
        ''')

        # TEMP 삭제
        cur.execute(f'DROP TABLE IF EXISTS "{temp_table}"')
        conn.commit()



def get_kospi_codes():
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT 코드 FROM KOSPI")
        codes = [row[0] for row in cursor.fetchall()]
        return codes

        

def get_kospi300_code():
    
    with sqlite3.connect(db_path) as conn:
        df_db = pd.read_sql("SELECT 코드, 종목명, 현재가, 등락률, 시가총액, 시장, 순위 FROM KOSPI", conn)  # 쿼리 결과를 DataFrame에 저장
    # dict_kospi = dict(zip(df_db['코드'], df_db['종목명']))
    return df_db





def create_kospi(df, option="replace"):
    with sqlite3.connect(db_path) as con:
        cur = con.cursor()
        sql = f"DROP TABLE IF EXISTS KOSPI_ALL"
        cur.execute(sql)

        df.rename(columns={'index': 'date'}, inplace=True)

        df.to_sql('KOSPI_ALL', con, if_exists=option, index=False)


        # 섹터 칼럼 추가

        con.commit()

        return

def create_kospi300():
    with sqlite3.connect(db_path) as con:
        cur = con.cursor()

        cur.execute("DROP TABLE IF EXISTS KOSPI")

        sql = '''
        CREATE TABLE KOSPI AS
        SELECT * 
        FROM KOSPI_ALL
        WHERE (시장 = '코스피' AND 순위 <= 70)
           OR (시장 = '코스닥' AND 순위 <= 30)
        ORDER BY 시장 DESC, 순위 ASC;
        '''
        cur.execute(sql)

        # 섹터 칼럼 추가


        con.commit()
        df_kospi300 = pd.read_sql("SELECT * FROM KOSPI", con)


        return df_kospi300





def get_db_day(code):
    with sqlite3.connect(db_path) as con:
        str_db_day = con.execute("SELECT MAX(DATE) FROM '" + code + "'").fetchone()
        return str_db_day[0]



def get_db_1day(code):
    with sqlite3.connect(db_path) as con:
        # get_workday()
        # 쿼리를 실행하고 결과를 DataFrame에 저장
        query = "SELECT DATE, OPEN, HIGH, LOW, CLOSE, VOLUME, A5, A20, A60, A120, U, D, AU, AD, RSI, RSI9, EMA12, EMA26, MACD, MACD9, BOL_U, BOL_L, BOL_SIZE, BOL_DOLPA, ILMOK_A, ILMOK_B, ILMOK_DOLPA, ILMOK_YANG, 개인, 외국인, 기관, 연기금 FROM '" + code + "' WHERE DATE != STRFTIME('%Y%m%d', 'now')"
        df_1day = pd.read_sql(query, con)
        df_1day.set_index('date', inplace=True)


    # print(df_1day['date'].iloc[0])
    return df_1day










def delete_db_1day(code, date): # DB 최근일 삭제
    with sqlite3.connect(db_path) as conn:
        conn.execute(f"""DELETE FROM '{code}' WHERE DATE = '{date}'""")
        conn.commit()

def delete_db_days(code, date1, date2): # DB 최근일 삭제
    with sqlite3.connect(db_path) as con:
        con.execute(f"""DELETE FROM '{code}' WHERE DATE BETWEEN '{date1}' AND '{date2}'""")
        con.commit()

def drop_db(code):
    with sqlite3.connect(db_path) as con:
        con.execute(f"""DROP TABLE '{code}'""")
        con.commit()



def get_db_recent_day(): # DB 삼성전자 최근일 리턴
    with sqlite3.connect(db_path) as con:
        query = """SELECT MAX(DATE) AS DATE FROM '005930'"""
        result = pd.read_sql(query, con)
        db_recent_day = result['DATE'].iloc[0]
    return db_recent_day


def get_db(code):
    con = sqlite3.connect(db_path)
    query = f"""
    SELECT date, open, high, low, close, volume, a5, a20, a60, a120, 
           au, ad, rsi, rsi9, ema12, ema26, macd, bol_u, bol_l, 
           bol_size, bol_dolpa, ilmok_a, ilmok_b, ilmok_dolpa, ilmok_yang, 
           개인, 외국인, 기관, 연기금 
    FROM '{code}'
    """
    df_db = pd.read_sql(query, con, index_col='date')
    con.close()


    return df_db










