
import sys
import os
from datetime import datetime

# 'RSI_project' 경로를 sys.path에 추가 (한 번만)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# 절대 import 사용
from RSI_app.kiwoom.api.Kiwoom import *
from RSI_app.kiwoom.util.db import *
from RSI_app.kiwoom.util.const import *
from RSI_app.kiwoom.util.start_kospi import *



def get_time():
    return datetime.now().strftime("%H:%M:%S")

def get_day():
    return datetime.now().strftime("%Y%m%d")



def insert_all():
    global kiwoom

    deposit = kiwoom.get_deposit()   # 예수금
    df_code = get_kospi300_code() # ['005930', '삼성전자']

    print(get_time())

    i = 0
    for code, name in zip(df_code['코드'], df_code['종목명']):
        i += 1
        print(str(i), code, name)
        kiwoom.set_price(code)
    print(get_time())
    # kiwoom.get_price('005930')



def insert_1day():
    global kiwoom

    df_code = get_kospi300_code() # ['005930', '삼성전자']

    recent_day = get_recent_day()

    print('1일 일봉 입력 시작 ' + get_time())
    
    i = 0
    for code, name in zip(df_code['코드'], df_code['종목명']):
        i += 1
        print(str(i), code, name)
        delete_db_1day(code, recent_day)
        kiwoom.set_price_1day(code, recent_day, get_ilbong_1day(code))
    print('1일 일봉 입력 완료 ' + get_time())



def get_ilbong(code):
    return get_ilbong_data(code)



def drop_all():
    global kiwoom

    df_code = get_kospi300_code() # ['005930', '삼성전자']

    i = 0
    for code, name in zip(df_code['코드'], df_code['종목명']):
        i += 1
        print(str(i), code, name, ' 삭제')
        drop_db(code)











import pandas as pd
from RSI_app.kiwoom.main import get_kospi300_code, get_ilbong_data









def get_rsi(high = 'high'):
    df_codes = get_kospi300_code()
    codes = df_codes['코드'].tolist()

    list_rsi = []

    for code in codes:
        df = get_ilbong_data(code)  # 일봉 df
        if df.empty:
            continue

        df = df.sort_values('date')  # 일자로 정렬
        latest_rsi = df.iloc[-1]['rsi']
        





        if high == 'high':
            if latest_rsi >= 70:
                list_rsi.append({
                    'code': code,
                    'name': df_codes.loc[df_codes['코드'] == code, '종목명'].values[0],
                    'date': df['date'].tolist(),
                    'rsi': df['rsi'].tolist()
                })


        if high == 'low':
            if latest_rsi <= 30:
                list_rsi.append({
                    'code': code,
                    'name': df_codes.loc[df_codes['코드'] == code, '종목명'].values[0],
                    'date': df['date'].tolist(),
                    'rsi': df['rsi'].tolist()
                })
                

        if high == 'middle':
            if 30 <= latest_rsi <= 70:
                list_rsi.append({
                    'code': code,
                    'name': df_codes.loc[df_codes['코드'] == code, '종목명'].values[0],
                    'date': df['date'].tolist(),
                    'rsi': df['rsi'].tolist()
                })


    print(list_rsi)
    return list_rsi








def get_macd(high = 'high'):
    df_codes = get_kospi300_code()
    codes = df_codes['코드'].tolist()

    list_macd = []

    for code in codes:
        df = get_ilbong_data(code)  # 일봉 df


        '''
        if high == 'high':
            df = get_macd_data('high')
        '''


        
        if df.empty:
            continue

        df = df.sort_values('date')  # 일자로 정렬
        df = df[len(df)-80:]
        latest_macd = df.iloc[-1]['macd']
        





        if high == 'high':
            if latest_macd >= 2000:
                list_macd.append({
                    'code': code,
                    'name': df_codes.loc[df_codes['코드'] == code, '종목명'].values[0],
                    'date': df['date'].tolist(),
                    'macd': df['macd'].tolist(),
                    'macd9': df['macd9'].tolist()
                })


        if high == 'low':
            if latest_macd <= 1000:
                list_macd.append({
                    'code': code,
                    'name': df_codes.loc[df_codes['코드'] == code, '종목명'].values[0],
                    'date': df['date'].tolist(),
                    'macd': df['macd'].tolist(),
                    'macd9': df['macd9'].tolist()                    
                })
                

        if high == 'middle':
            if 2000 <= latest_macd <= 2000:
                list_macd.append({
                    'code': code,
                    'name': df_codes.loc[df_codes['코드'] == code, '종목명'].values[0],
                    'date': df['date'].tolist(),
                    'macd': df['macd'].tolist(),
                    'macd9': df['macd9'].tolist()
                    
                })


    print(list_macd)
    return list_macd











if __name__ == "__main__":


    """

    df_db = get_db('005930')
    # print(df_db)
    print(df_db[['open', 'low', 'high', 'close', 'rsi']])
    print(df_code.iloc[0:8])

    """







    app = QApplication(sys.argv)




    global kiwoom
    kiwoom = Kiwoom()

    # get_kospi()
    # insert_all()
    insert_1day()


    # kiwoom.set_price_1day('005930', get_recent_day(), get_ilbong_1day('005930'))

    

    time.sleep(1000)



    # print(get_kospi300_code())


    # insert_all()
    


    # get_rsi('high')

    # get_macd('middle')




    '''
    print('삼성')
    kiwoom.set_price('005930')
    print('머니')
    kiwoom.set_price('488770')
    print('종료')
    '''





    
    # insert_1day()
    # drop_all()
    # df = get_ilbong('005930')
    # print(df)




    


    # delete_db_1day('005930', '20250605')
    print(8)

    



    '''
    deposit = kiwoom.get_deposit()   # 예수금

    print(get_time())
    for code, name in zip(df_code['코드'], df_code['종목명']):

            print(code, name)
            kiwoom.get_price(code)
    print(get_time())
    # kiwoom.get_price('005930')
    '''


    app.exec_()





















    
    '''

    app = QApplication(sys.argv)
    kiwoom = Kiwoom()


    # list_code = ["005930", "068270"]
    # dict_kospi = {"005930": "삼성전자"}
    # dict_kospi = {"459580": "코덱스"}
    # dict_kospi = {"450080": "에코프로머티", "005830": "DB손해보험", "068270": "SK하이닉스"}
    # dict_kospi = {"005930": "삼성전자", "068270": "SK하이닉스"}
    


    print(8)
    print(dict_kospi)

    # drop_kospi300()



    # delete_db_1day("005930", "20241031") # datetime.now().strftime("%Y%m%d")



    print("일봉 시작 [" + get_time() + "]")
    i=0
    for code, name in dict_kospi.items():
        i = i+1
        print(str(i) + " " + name)
        if code in ["450080"]:   # 에코프로머티
            print("생략")
            continue


        kiwoom.get_price(code)

        # drop_db(code)
        # delete_db_days(code, "20241101", "20241101")
        # kiwoom.get_price_1day(code)


        # kiwoom.set_days(code)





    print("일봉 완료 [" + get_time() + "]")




    deposit = kiwoom.get_deposit()
    print(7)
    print(deposit)
    print(8)

    # kiwoom.get_investor_data("20241017", "005930")
    # data = kiwoom.get_investor_trend("005930", "20230101")
    # drop_kospi300()


    fids = get_fid("체결시간")
    codes = "005930;007700;000660;"
    kiwoom.set_real_reg("1000", codes, fids, "0")
    '''

    





    """
    position = kiwoom.get_balance()   # 잔고 종목
    print(position)
    """

    """
    orders = kiwoom.get_order()
    print(orders)
    """

    """
    # order_result = kiwoom.send_order('send_buy_order', '1001', 1, '007700', 1, 35000, '00')
    order_result = kiwoom.send_order('send_buy_order', '1001', 1, '007700', 1, 37600, '00')
    print(order_result)
    """



    # deposit = kiwoom.get_deposit()   # 예수금



    '''

    kiwoom.get_code_list_by_market("0")


    kospi_code_list = kiwoom.get_code_list_by_market("0")
    print(kospi_code_list)
    for code in kospi_code_list:
        code_name = kiwoom.get_master_code_name(code)
        print(code, code_name)

    kosdaq_code_list = kiwoom.get_code_list_by_market("10")
    print(kosdaq_code_list)
    for code in kosdaq_code_list:
        code_name = kiwoom.get_master_code_name(code)
        print(code, code_name)
    '''



