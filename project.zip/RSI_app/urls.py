from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('kospi/', views.partial_kospi, name='_partial_kospi'), # KOSPI 조각 뷰
    path('detail/', views.partial_detail, name='_partial_detail'), # Detail 조각 뷰

    path('rsi_chart/', views.rsi_chart, name='rsi_chart'),
    path('macd_chart/', views.macd_chart, name='macd_chart'),
]
